"""Shared transport, conservative backoff, and public-page browser access.
Only enable browser access to sites for which automated access is authorized.
"""
import os,re,time,threading,json,ipaddress,socket
from contextlib import contextmanager
from urllib.parse import urlparse
from email.utils import parsedate_to_datetime
import requests
import activity
import research_debug as debug

class ProviderError(RuntimeError):pass
class Deferred(ProviderError):pass
class Gate:
    def __init__(self):self.lock=threading.Lock();self.states={}
    def check(self,name,interval=0):
        with self.lock:
            s=self.states.setdefault(name,{'calls':0,'failures':0,'next':0,'last_ok':None,'error':None})
            remaining=max(0,s['next']-time.time())
            if not remaining:s['calls']+=1;s['next']=time.time()+interval
        if remaining:
            activity.emit('provider cooldown',message=f'{name} · {round(remaining)}s');raise Deferred(name+' cooling down')
        activity.emit('provider request',message=name)
    def good(self,name):
        with self.lock:self.states[name].update(last_ok=time.time(),failures=0,error=None)
        activity.emit('provider response',message=name+' succeeded')
    def fail(self,name,reason,retry_after=0):
        with self.lock:
            s=self.states[name];s['failures']+=1;s['error']=reason;s['next']=max(s['next'],time.time()+max(retry_after,min(900,2**min(s['failures'],9))))
        activity.emit('provider error',message=name+' · '+reason)
    def snapshot(self):
        with self.lock:return {k:dict(v) for k,v in self.states.items()}
GATE=Gate()

def retry_after(value):
    try:return max(0,float(value))
    except (TypeError,ValueError):
        try:return max(0,parsedate_to_datetime(value).timestamp()-time.time())
        except Exception:return 0

def request_json(method,url,provider,**kwargs):
    """Do not leak secrets in exception messages or retry access restrictions."""
    for i in range(3):
        GATE.check(provider)
        try:r=requests.request(method,url,timeout=(10,60),allow_redirects=False,**kwargs)
        except requests.RequestException as e:
            GATE.fail(provider,type(e).__name__)
            if i==2:raise ProviderError(provider+' transport error') from None
            time.sleep(2**(i+1));continue
        if r.status_code in (401,403,429):
            GATE.fail(provider,'HTTP '+str(r.status_code),max(60,retry_after(r.headers.get('Retry-After'))));raise Deferred(provider+' HTTP '+str(r.status_code))
        if r.status_code in (500,502,503,504):
            delay=max(2**(i+1),retry_after(r.headers.get('Retry-After')));GATE.fail(provider,'HTTP '+str(r.status_code),delay)
            if i==2 or delay>10:raise Deferred(provider+' HTTP '+str(r.status_code))
            time.sleep(delay);continue
        if not 200<=r.status_code<300:GATE.fail(provider,'HTTP '+str(r.status_code));raise ProviderError(provider+' HTTP '+str(r.status_code))
        try:data=r.json()
        except ValueError:GATE.fail(provider,'Invalid JSON');raise ProviderError(provider+' invalid JSON') from None
        GATE.good(provider);return data

# One general browser slot, separate from eBay's own serialized session.
# Scanner waiting takes precedence over background tasks at page boundaries.
BROWSER=threading.Lock()

def allowed(url):
    return public_url(url)

def public_url(url):
    try:
        u=urlparse(str(url));host=(u.hostname or '').rstrip('.').lower()
        if not (u.scheme=='https' and '.' in host and not host.endswith(('.local','.internal','.localhost','.ts.net','.lan','.home.arpa')) and not u.username and not u.password and u.port in (443,None)):return False
        try:ipaddress.ip_address(host);return False
        except ValueError:pass
        return not re.fullmatch(r'[\d.]+',host)
    except ValueError:return False

def network_allowed(url):
    if not public_url(url):return False
    try:
        host=urlparse(url).hostname
        addresses=socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)
        return bool(addresses) and all(ipaddress.ip_address(x[4][0]).is_global for x in addresses)
    except (OSError,ValueError):return False

def guard(page):
    # Reject private destinations, unsafe methods, downloads and unnecessary resources.
    cache={}
    def route_handler(route):
        req=route.request;host=urlparse(req.url).hostname
        if req.method not in ('GET','HEAD') or not public_url(req.url) or req.resource_type in ('media','font'):
            route.abort();return
        if host not in cache:cache[host]=network_allowed(req.url)
        if not cache[host]:route.abort();return
        route.continue_()
    page.route('**/*',route_handler)
    if hasattr(page,'route_web_socket'):page.route_web_socket('**/*',lambda ws:ws.close())

def browser_page(url):
    if not network_allowed(url):raise ProviderError('Public HTTPS destination could not be resolved safely')
    from playwright.sync_api import sync_playwright
    host=urlparse(url).hostname
    with BROWSER:
        GATE.check('browser:'+host,3);started=time.monotonic();debug.event('navigation started',url)
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(headless=debug.mode()!='visible')
                try:
                    context=browser.new_context(accept_downloads=False,service_workers='block');page=context.new_page();guard(page)
                    response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
                    if not response or not network_allowed(page.url):raise ProviderError('Unexpected redirect')
                    body=page.locator('body').inner_text(timeout=8000)
                    if response.status in (401,403,429) or re.search(r'captcha|verify you are human|access denied|pardon our interruption',page.title()+' '+body[:2000],re.I):raise Deferred('Access restricted; stop and review authorization')
                    if response.status>=400:raise ProviderError('HTTP '+str(response.status))
                    # Allow client-rendered catalog links to populate, within a bounded wait.
                    page.wait_for_timeout(1500)
                    result={'url':page.url,'title':page.title(),'html':page.content(),'text':page.locator('body').inner_text(timeout=8000)[:100000],'links':page.locator('a[href]').evaluate_all('els=>els.slice(0,5000).map(e=>({url:e.href,title:(e.innerText||e.title||" ").trim().slice(0,250)}))')}
                    debug.event('navigation complete',page.url,status=response.status,seconds=round(time.monotonic()-started,2),links=len(result['links']));debug.capture(page)
                finally:browser.close()
            GATE.good('browser:'+host);return result
        except Exception as e:
            debug.event('navigation failed',url,error=type(e).__name__,seconds=round(time.monotonic()-started,2));GATE.fail('browser:'+host,type(e).__name__,3600 if isinstance(e,Deferred) else 30);raise ProviderError('Browser '+host+' failed: '+type(e).__name__) from None

def request_text(url,provider,redirect_hosts=(),**kw):
    """Follow only bounded HTTPS redirects to explicitly trusted feed hosts.
    Never forward credentials, downgrade HTTPS, or follow arbitrary locations.
    """
    from urllib.parse import urljoin
    GATE.check(provider)
    hosts={urlparse(url).hostname,*redirect_hosts}
    current=url;seen=set();failed=False
    if set(kw)-{'headers'} or set(k.lower() for k in kw.get('headers',{}))-{'user-agent','accept'}:raise ProviderError('Feed requests cannot carry credentials')
    try:
        for hop in range(6):
            if not public_url(current) or urlparse(current).hostname not in hosts or current in seen:
                raise ProviderError('Unsafe or looping feed redirect')
            seen.add(current)
            with requests.get(current,timeout=(10,30),allow_redirects=False,stream=True,**kw) as r:
                if r.status_code in (301,302,303,307,308):
                    location=r.headers.get('Location')
                    if not location:raise ProviderError('Redirect missing Location')
                    current=urljoin(current,location)
                    activity.emit('feed redirect',message=provider+' · '+str(r.status_code)+' · '+str(urlparse(current).hostname))
                    continue
                if not 200<=r.status_code<300:
                    failed=True;GATE.fail(provider,'HTTP '+str(r.status_code),max(300 if r.status_code in (401,403,429) else 0,retry_after(r.headers.get('Retry-After'))))
                    raise Deferred(provider+' HTTP '+str(r.status_code)) if r.status_code in (401,403,429) else ProviderError(provider+' HTTP '+str(r.status_code))
                chunks=[];size=0
                for chunk in r.iter_content(65536):
                    size+=len(chunk)
                    if size>8*1024*1024:raise ProviderError('Feed exceeds size limit')
                    chunks.append(chunk)
                GATE.good(provider);return b''.join(chunks)
        raise ProviderError('Too many feed redirects')
    except requests.RequestException as e:
        GATE.fail(provider,type(e).__name__);raise ProviderError(provider+' transport error: '+type(e).__name__) from None
    except ProviderError as e:
        if not failed:GATE.fail(provider,str(e))
        raise
