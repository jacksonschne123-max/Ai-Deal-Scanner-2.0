"""Bounded, evidence-preserving discovery queries; never invent identifiers."""
import re, json, math, time
from urllib.parse import urlparse, urlencode
import ebay_sales, intelligence, providers, activity

PROMO=re.compile(r'\s+(?:just hit|hits? (?:a |an |its )?(?:new |black friday |all.time )?(?:low|record)|(?:is |are )?(?:now |down )?at (?:an? |its )?(?:all.time|black friday|record)|down at|for just|on sale|(?:overhauls|upgrades) your|(?:now |today )?only\s*\$|save\s+\$|at\s*$|for\s*$).*$',re.I)

def clean(name):
    n=re.sub(r'\s+', ' ', str(name or '')).strip()
    n=PROMO.sub('',n);n=re.sub(r'\s+(?:just hit|for just|down at|at an all.time low|at its lowest price).*$', '', n, flags=re.I);n=re.sub(r'\s+\$[\d,.]+.*$','',n)
    return n.strip(' -:·,')[:180]

def title_query(p):
    n=clean(p.get('name'))
    if len(re.findall(r'\w+',n))<2 or re.match(r'^(?:unknown|massive|turn your|relive|save|deal|assorted|miscellaneous)\b',n,re.I):return ''
    return n

def queries(p):
    """Prefer identifiers, then a full title, then a bounded shorter descriptive query."""
    out=[];q=ebay_sales.identity(p);n=title_query(p)
    for x in (q,n):
        if x and x not in out:out.append(x)
    if n:
        short=re.sub(r'\s+(?:robotic pool cleaner|wireless lavalier microphone system|wireless microphone system|robot vacuum cleaner|wireless headphones|wireless earbuds)\s*$', '', n, flags=re.I)
        # Shortening is exploratory; preserve identity/variant text and avoid generic one-word queries.
        if short!=n and len(short.split())>=3 and short not in out:out.append(short)
    return out

def query(p):
    return next(iter(queries(p)), '')

def metadata(html,p):
    """Only a unique compatible structured Product may supply identifiers."""
    parser=intelligence.JsonLD();parser.feed(html or '');found=[]
    q=query(p)
    for x in intelligence.walk(parser.items):
        types=x.get('@type',[]);types=[types] if isinstance(types,str) else types
        if not isinstance(types,list) or 'Product' not in types:continue
        name=str(x.get('name') or '');brand=x.get('brand') or '';brand=brand.get('name','') if isinstance(brand,dict) else str(brand)
        model=x.get('mpn') or x.get('model') or '';model=model if isinstance(model,str) else ''
        upcs={str(x.get(k) or '') for k in ('gtin','gtin8','gtin12','gtin13','gtin14','upc')};upcs={u for u in upcs if ebay_sales.valid_upc(u)}
        if len(upcs)>1:continue
        u=next(iter(upcs),'');text=' '.join((name,brand,model,u))
        if not q or not ebay_sales.matches(text,q):continue
        if not ebay_sales.identity(p) and re.search(r'\b(?:bundle|parts|compatible|case only|box only|refurbished)\b',name,re.I):continue
        found.append((name,brand,model,u))
    unique=set(found)
    if len(unique)!=1:return {}
    name,brand,model,u=unique.pop();out={k:v for k,v in [('name',name),('brand',brand),('model',model),('upc',u)] if v}
    if not out:return {}
    out['identity_evidence']='Unique matching retailer Product metadata';return out

def amazon_reference(p,loader):
    """Use exact structured offer data, not snippets or a search result's first price."""
    q=query(p)
    if not q:return {}
    u=p.get('retailer_url') or p.get('url') or ''
    host=urlparse(u).hostname
    if host not in ('amazon.com','www.amazon.com') or not re.search(r'/(?:dp|gp/product)/[A-Z0-9]{10}(?:/|$)',urlparse(u).path,re.I):
        search='https://www.amazon.com/s?'+urlencode({'k':q});page=loader(search)
        urls=[]
        for link in page.get('links',[]):
            u=link.get('url','');parsed=urlparse(u);m=re.search(r'/(?:dp|gp/product)/([A-Z0-9]{10})(?:/|$)',parsed.path,re.I)
            if parsed.hostname in ('amazon.com','www.amazon.com') and parsed.scheme=='https' and m and ebay_sales.matches(link.get('title',''),q):
                canonical='https://www.amazon.com/dp/'+m[1].upper()
                if canonical not in urls:urls.append(canonical)
        if len(urls)!=1:return {}
        u=urls[0]
    page=loader(u);final=page.get('url','')
    if urlparse(final).hostname not in ('amazon.com','www.amazon.com'):return {}
    # Explicit new condition only; generic offers can be used or mixed-condition.
    parser=intelligence.JsonLD();parser.feed(page.get('html',''));prices=[]
    for x in intelligence.walk(parser.items):
        types=x.get('@type',[]);types=[types] if isinstance(types,str) else types
        if not isinstance(types,list) or 'Product' not in types:continue
        text=' '.join(str(x.get(k,'')) for k in ('name','brand','model','mpn','gtin','gtin8','gtin12','gtin13','gtin14'))
        if not ebay_sales.matches(text,q):continue
        offers=x.get('offers',[]);offers=offers if isinstance(offers,list) else [offers]
        for o in offers:
            if not isinstance(o,dict) or o.get('priceCurrency')!='USD' or str(o.get('itemCondition','')).split('/')[-1]!='NewCondition' or str(o.get('availability','')).split('/')[-1]!='InStock':continue
            try:price=float(o['price'])
            except (ValueError,TypeError,KeyError):continue
            if math.isfinite(price) and price>0:prices.append(price)
    if not prices or len(set(prices))!=1:return {}
    return dict(amazon_price=prices[0],amazon_url=final,amazon_checked_at=time.time(),amazon_evidence=('Exact identifier' if ebay_sales.identity(p) else 'Title match; variant unverified')+'; new in-stock structured offer')
