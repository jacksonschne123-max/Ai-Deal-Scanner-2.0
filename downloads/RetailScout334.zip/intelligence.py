"""Conservative evidence gates, local directory, and retailer JSON-LD extraction."""
import re,time,json,math,statistics,threading,os
from html.parser import HTMLParser
from urllib.parse import urlparse,urlencode
SOURCES=[('ATX Knoxville','https://atxknoxville.hibid.com/','auction'),('HiBid','https://hibid.com/','auction'),('GovDeals','https://www.govdeals.com/','surplus'),('UT Surplus','https://warehousing.utk.edu/auctions-2/','surplus'),('Knoxville City Surplus','https://www.knoxvilletn.gov/989/City-Surplus','surplus'),('Powell Auction','https://www.powellauction.com/','auction'),('JD’s Realty','https://www.jdsauctions.com/','estate'),('Bargain Brothers','https://bargainbrotherstn.com/','warehouse'),('Lotvara Knoxville directory','https://www.lotvara.com/tn/knoxville/','warehouse'),('GovAuctions Knoxville directory','https://govauctions.app/cities/tennessee/knoxville','surplus')]
class JsonLD(HTMLParser):
    def __init__(self): super().__init__();self.active=False;self.buf='';self.items=[]
    def handle_starttag(self,tag,attrs):
        if tag=='script' and dict(attrs).get('type')=='application/ld+json': self.active=True;self.buf=''
    def handle_data(self,data):
        if self.active:self.buf+=data
    def handle_endtag(self,tag):
        if tag=='script' and self.active:
            self.active=False
            try:self.items.append(json.loads(self.buf))
            except ValueError:pass

def walk(v):
    if isinstance(v,list):
        for x in v:yield from walk(x)
    if isinstance(v,dict):
        yield v
        for x in v.values():yield from walk(x)

def retail_offer(html,p):
    import ebay_sales
    parser=JsonLD();parser.feed(html);q=ebay_sales.identity(p)
    if not q:return {}
    found=[]
    for x in walk(parser.items):
        if 'Product' not in ([x.get('@type')] if isinstance(x.get('@type'),str) else x.get('@type') or []):continue
        identity=' '.join(str(x.get(k,'')) for k in ('name','gtin','gtin12','gtin13','gtin14','mpn','model','brand'))
        if not ebay_sales.matches(identity,q):continue
        offers=x.get('offers',[])
        for o in offers if isinstance(offers,list) else [offers]:
            if not isinstance(o,dict) or o.get('priceCurrency')!='USD':continue
            try:price=float(o['price'])
            except (ValueError,KeyError,TypeError):continue
            if not math.isfinite(price) or price<=0:continue
            stock=str(o.get('availability','')).split('/')[-1]
            # InStock alone is not proof of a particular fulfillment method.
            delivery=str(o.get('availableDeliveryMethod',''));mode='Online available' if o.get('shippingDetails') or any(k in delivery for k in ('DeliveryModeMail','DeliveryModeDirectDownload','DeliveryModeOwnFleet','DeliveryModeFreight')) else 'Pickup available' if 'DeliveryModePickUp' in delivery and o.get('availableAtOrFrom') else 'Listed in stock — fulfillment unknown'
            found.append((price,stock,mode))
    if not found or len(set(found))!=1:return {}
    price,stock,mode=found[0];return {'cost':price,'stock':{'InStock':mode,'OutOfStock':'Unavailable','SoldOut':'Unavailable'}.get(stock,'Unverified'),'price_verified':True,'verified_at':time.time(),'verification_method':'Exact identity USD product structured data; checkout not tested'}

def gate(p):
    if p.get('stock')=='Unavailable':return 'Rejected — unavailable'
    if p.get('posted') and time.time()-p['posted']>72*3600:return 'Rejected — stale lead'
    if not p.get('price_verified') or not p.get('verified_at') or time.time()-p['verified_at']>900:return 'Potential lead — verify retail offer'
    if p.get('stock') not in ('Online available','Pickup available'):return 'Potential lead — stock unknown'
    if p.get('profit') is None or (p.get('sample') or 0)<10 or not p.get('complete') or p.get('source') not in ('eBay sold (browser)','eBay sold (provider)') or not p.get('researched_at') or time.time()-p['researched_at']>3600:return 'Potential lead — insufficient sold evidence'
    if p.get('active_low') is None:return 'Potential lead — competing prices unknown'
    if p.get('profit',0)<=0 or p.get('break_even') is None or p.get('active_low',0)<p['break_even']:return 'Rejected — economics'
    if p.get('exploratory') or p.get('identity_method')!='UPC':return 'Potential lead — verify exact variant'
    return 'Positive estimate — verify checkout, eligibility and condition'

def max_bid(resale,fee=.15,shipping=6,profit=20,premium=.15,tax=.0925,travel=0,risk=0):
    if not all(math.isfinite(x) and x>=0 for x in (resale,fee,shipping,profit,premium,tax,travel,risk)) or fee>=1:raise ValueError('Invalid bid assumptions')
    return math.floor(max(0,(resale*(1-fee)-shipping-profit-travel-risk)/((1+premium)*(1+tax)))*100+1e-9)/100

def rank(p):return (p.get('assessment','').startswith('Positive estimate'),not p.get('assessment','').startswith('Rejected'),p.get('profit') if p.get('profit') is not None else -1e9)

def source_priority(name,stats):
    """Smoothed ranking, preventing a single historical hit from dominating discovery."""
    s=stats.get(name,{})
    return (s.get('verified_positive',0)+1)/(s.get('leads',0)+10)

def compare_exact(item,others):
    import ebay_sales
    key=ebay_sales.identity(item);now=time.time()
    if not key:return []
    offers=[]
    for p in others:
        if ebay_sales.identity(p)!=key or p.get('url')==item.get('url') or not p.get('price_verified') or not p.get('verified_at') or now-p['verified_at']>900 or p.get('stock') not in ('Online available','Pickup available') or p.get('cost') is None:continue
        offers.append({k:p.get(k) for k in ('store','cost','url','stock','verified_at')})
    return sorted(offers,key=lambda p:p['cost'])[:10]
