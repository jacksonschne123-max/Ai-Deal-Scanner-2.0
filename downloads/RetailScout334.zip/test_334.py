import os,time,json,tempfile,unittest
from unittest.mock import patch
import identity_research as i, ebay_sales as e, server as s, intelligence

def product(name='Beatbot AquaSense 2 Ultra Robotic Pool Cleaner',**kw):
    return '<script type="application/ld+json">'+json.dumps(dict({'@type':'Product','name':name,'brand':'Beatbot','mpn':'AS200','gtin12':'123456789012'},**kw))+'</script>'
class IdentityFallback(unittest.TestCase):
    def test_headlines(self):
        self.assertEqual(i.clean('Apple Watch Series 12 just hit Black Friday all-time low at'),'Apple Watch Series 12')
        self.assertEqual(i.clean('Apple iPhone 256GB unlocked for just'),'Apple iPhone 256GB unlocked')
        self.assertEqual(i.query({'name':'Hollyland LARK A2 Wireless Lavalier Microphone System'}),'Hollyland LARK A2 Wireless Lavalier Microphone System')
        self.assertEqual(i.query({'name':'Turn your phone into a retro Game Boy for just'}),'')
    def test_metadata(self):
        self.assertEqual(i.metadata(product(),{'name':'Beatbot AquaSense 2 Ultra'})['upc'],'123456789012')
        self.assertEqual(i.metadata(product('Different item'),{'name':'Beatbot AquaSense 2 Ultra'}),{})
        self.assertEqual(i.metadata(product()+product(gtin12='123456789029'),{'name':'Beatbot AquaSense 2 Ultra'}),{})
    def test_barcode_priority(self):self.assertEqual(i.query({'name':'Beatbot AquaSense','upc':'123456789012'}),'123456789012')
    def test_browser_title(self):
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',0),patch.object(e,'browse',return_value=([],False,None)) as b:
            result=e.lookup({'name':'Pocket Radar Smart Coach'},d+'/db');b.assert_called_once_with('Pocket Radar Smart Coach');self.assertTrue(result['exploratory'])
    def test_amazon_fallback_title(self):
        url='https://www.amazon.com/dp/B012345678';offer={'priceCurrency':'USD','price':100,'itemCondition':'https://schema.org/NewCondition','availability':'https://schema.org/InStock'}
        page={'url':url,'html':product(offers=offer)}
        result=i.amazon_reference({'name':'Beatbot AquaSense 2 Ultra','url':url},lambda _:page);self.assertEqual(result['amazon_price'],100);self.assertIn('unverified',result['amazon_evidence'])
        offer['itemCondition']='https://schema.org/UsedCondition';self.assertEqual(i.amazon_reference({'name':'Beatbot AquaSense 2 Ultra','url':url},lambda _:{'url':url,'html':product(offers=offer)}),{})
    def test_fallback_not_profit(self):
        with patch.object(s,'pricing',return_value={'resale':None,'amazon_price':100,'valuation_basis':'Amazon asking price — preliminary only'}):
            p=s.process({'name':'Widget ABC','cost':30},prepared=True);self.assertIsNone(p['profit']);self.assertEqual(p['amazon_reference_gap'],70);self.assertEqual(p['amazon_discount_pct'],70)
    def test_pricing_routes_title(self):
        with patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1','SCOUT_SOLD_URL':'','SCOUT_AMAZON_URL':'','SCOUT_AMAZON_BROWSER':'1'}),patch.object(e,'lookup',return_value={'resale':None}) as b,patch.object(i,'amazon_reference',return_value={'amazon_price':100}) as a:
            p=s.pricing({'name':'Pocket Radar Smart Coach'});b.assert_called_once();a.assert_called_once();self.assertTrue(p['deferred']);self.assertEqual(p['amazon_price'],100);self.assertIsNone(p['resale'])

    def test_alternate_query_after_empty_upc(self):
        with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',0),patch.object(e,'browse',return_value=([],False,None)) as b:
            p={'name':'Beatbot AquaSense 2 Ultra Robotic Pool Cleaner','upc':'123456789012'}
            e.lookup(p,d+'/db');e.last=0
            r=e.lookup(p,d+'/db');self.assertEqual(b.call_args.args[0],p['name']);self.assertTrue(r['exploratory'])
    def test_short_query_preserves_model(self):
        self.assertIn('Beatbot AquaSense 2 Ultra',i.queries({'name':'Beatbot AquaSense 2 Ultra Robotic Pool Cleaner'}))
