import os,re,hashlib,xml.etree.ElementTree as ET
from urllib.parse import urlparse
from html.parser import HTMLParser
from email.utils import parsedate_to_datetime
import time,requests
import providers
FEEDS=['https://slickdeals.net/rss.php','https://slickdeals.net/newsearch.php?mode=popdeals&searcharea=deals&searchin=first&rss=1']
def parse_rss(data):
    for x in ET.fromstring(data).findall('.//item'):
        title=x.findtext('title') or ''; url=x.findtext('link') or ''; date=x.findtext('pubDate')
        prices=re.findall(r'\$\s*(\d[\d,]*(?:\.\d{2})?)(?![\d.])',title)
        if len(prices)!=1 or re.search(r'\b(?:from|starting|cashback|gift card|subscription|after rebate|statement credit|up to|each|select| ymmv)\b|\d+\s*%',title,re.I): continue
        if urlparse(url).scheme!='https': continue
        try: posted=parsedate_to_datetime(date).timestamp()
        except (ValueError,TypeError,AttributeError): continue
        if not 0<=time.time()-posted<=259200: continue
        cost=float(prices[0].replace(',','')); name=re.sub(r'\s*\$\s*[\d,.]+.*$','',title).strip(' -:')
        if cost<=0 or not name: continue
        from providers import allowed
        direct=[]
        for u in re.findall(r'https://[^\s\"<>]+',x.findtext('description') or ''):
            u=u.replace('&amp;','&')
            if allowed(u) and 'slickdeals.net' not in (urlparse(u).hostname or '') and u not in direct:direct.append(u)
        retailer_url=direct[0] if len(direct)==1 else None
        yield dict(retailer_url=retailer_url,name=name,cost=cost,url=url,lead_url=url,store='Slickdeals community lead',stock='Unverified',posted=posted,deal_id=x.findtext('guid') or url,price_verified=False)
def rss(url):
    return list(parse_rss(providers.request_text(url,'Slickdeals RSS',headers={'User-Agent':'RetailScout/3.3 RSS reader'})))
def bestbuy(key):
    data=providers.request_json('GET','https://api.bestbuy.com/v1/products(onSale=true&onlineAvailability=true)','Best Buy API',params={'apiKey':key,'format':'json','show':'sku,name,upc,salePrice,url,onlineAvailability','pageSize':50})
    for x in data.get('products',[]):
        if x.get('onlineAvailability') is True and x.get('salePrice') is not None:
            yield dict(name=x['name'],upc=x.get('upc'),cost=x['salePrice'],url=x['url'],store='Best Buy',stock='Online available',posted=time.time(),deal_id=str(x['sku']),price_verified=True)
def classify(item):
    if item.get('profit') is None: return 'Needs resale evidence'
    if item.get('profit')<=0: return 'Not profitable at estimated costs'
    if not item.get('price_verified'): return 'Potential lead — verify retail offer'
    if item.get('source') not in ('eBay sold (provider)','eBay sold (browser)') or item.get('sample',0)<3: return 'Potential lead — insufficient sold evidence'
    return 'Positive estimate — verify eligibility, stock and condition'
def fingerprint(p):
    return hashlib.sha256((str(p.get('store'))+'|'+str(p.get('deal_id') or p.get('url') or p.get('name'))).encode()).hexdigest()

def product_candidates(page,store,limit=25):
    """Discover structured products on an explicitly configured retailer page."""
    from intelligence import JsonLD,walk
    from providers import public_url,allowed
    parser=JsonLD();parser.feed(page.get('html',''));seen=set();out=[]
    for x in walk(parser.items):
        t=x.get('@type');types=[t] if isinstance(t,str) else t or []
        if 'Product' not in types or not isinstance(x.get('name'),str):continue
        brand=x.get('brand');brand=brand.get('name') if isinstance(brand,dict) else brand
        url=x.get('url') or page.get('url')
        if not public_url(url) or not allowed(url) or url in seen:continue
        seen.add(url);out.append(dict(name=x['name'],brand=brand,model=x.get('mpn') or x.get('model'),upc=x.get('gtin12') or x.get('gtin13') or x.get('gtin14'),url=url,store=store,posted=time.time(),deal_id=url))
        if len(out)>=limit:break
    return out
