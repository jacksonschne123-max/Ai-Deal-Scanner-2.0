# Retail Scout 3.3.0-preview — Windows backend update

This is a development release candidate, not a fully live-validated buying system. All included tests run offline with synthetic data. Actual Gemini, eBay, retailer and auction provider access, selectors, terms, API limits and price accuracy must be validated on your PC. No automated buying or bidding. See FEATURES.md for all 74 requirements and gaps.

## Update your working 3.2 installation

1. Stop the running server with Ctrl+C; close the backend terminal. Keep the original `config.bat`, working `start.bat`, `.venv`, Tailscale and `scout.db` in place.
2. Download and verify the 3.3 ZIP checksum from the published GitHub instructions. Extract to a *separate* staging directory, not directly over 3.2.
3. In PowerShell run the existing installation's `.venv\Scripts\python.exe -m pip install -r <stage>\requirements-test.txt` (only missing packages should install; httpx is needed by the tests). Install Chromium if not already installed: `python -m playwright install chromium` using the same venv.
4. Run `<existing venv python> <stage>\install_update.py --target <existing install folder>`. The installer runs all offline and Chromium fixture tests first, backs up existing code and default scout.db, then copies only the explicit program files. The existing config, launcher, Python environment and database remain in place. If a test fails, no program files are replaced. If using a custom SCOUT_DB path, make a separate backup before updating. Windows 5.1 itself was not available for testing here.
5. Double-click your existing start.bat. Open http://127.0.0.1:8765 and connect with your existing token. Your private Tailscale URL continues serving the updated interface. Keep PC awake; do not expose the port publicly.

Rollback: stop the backend. Run the staged `install_update.py --target <existing folder> --rollback <existing folder>\backups\pre-3.3-...` using the existing venv Python. This restores code only. A pre-update database snapshot is also saved locally; restoring it separately would discard newer records, so do not overwrite the database casually. Never upload your backup directory or config.bat.

## First-run checklist

- Diagnostics: verify 3.3.0-preview, configured flags, pending enrichment, provider failures and last successful calls. Configuration is not proof of a successful API request.
- Scanner: submit a photo, then manual research with a verified UPC. Confirm the individual completed sales, dates, currency, exact variant and sample. Try a brand/model without UPC. Sparse/partial data stays visibly uncertain.
- DealWatch: refresh and review leads. Positive estimates require recent USD acquisition evidence, explicit fulfillment evidence, dated 30-day sold observations (at least 10), complete coverage indicator, exact UPC candidate and active competing price. Amazon asking price is never used as resale. Structured stock is not checkout verification. Older 3.2 deal estimates are downgraded; existing data is kept.
- Local Auctions: press Find local opportunities. There is no scheduled auction crawl. Without authorized browser hosts or feed endpoints, results are directory entries only, not current auctions. Deep mode is bounded; missing pickup locations and terms remain unknown. A 50-mile search is not exhaustive.
- Stock Watch: save an exact UPC/model, authorized direct retailer URL and target price; target or restock events appear in Diagnostics. No push notifications yet.

## Optional settings — append to existing config.bat

Use `config.3.3.example.bat` as reference; do not replace your working configuration. `SCOUT_EBAY_BROWSER=1` remains opt-in for your authorized testing scope. `SCOUT_EBAY_MAX_PAGES=10` default (1–30) bounds sold pages; page-cap or missing markup means partial coverage. The eBay browser stops on 401/403/429 or challenges; persistent suspension is shown in Diagnostics. Do not bypass it. After resolving authorization, the PC owner can remove the ebay_control row while the server is stopped, using SQLite, only if permitted. No retries that evade an access restriction.

`SCOUT_BROWSER_HOSTS` is a comma-separated list of exact public hostnames where automated access is authorized. Example syntax only: `set "SCOUT_BROWSER_HOSTS=retailer.example,auction.example"`. Add real hosts only when you have permission. It is empty by default. This controls rendered retailer/auction pages, not the separate eBay opt-in. New source domains discovered via Gemini are NOT automatically authorized. `SCOUT_GROUNDING=1` optionally uses Gemini Google Search for missing identifiers; `SCOUT_AUCTION_DISCOVERY=1` adds grounded local source candidates when a deep auction job is requested. Both may incur additional API charges. No key is embedded in the program.

Financial defaults: 15% fee, $6 estimated shipping, tax 9.25%, cashback from your existing config (adjust to actual). Manual research allows shipping override; auction form accepts shipping, buyer premium, tax, travel, risk and required profit. Calculated max bid is illustrative and rounded down; not an automatic bid. Selling fees, shipping and condition must be verified. No automatic coupon stack validation.

## Providers and source contracts

`SCOUT_SOLD_URL` and `SCOUT_AMAZON_URL` are optional authorized HTTPS provider endpoints, not built-in paid services. `SCOUT_PROVIDER_KEY` optional Bearer token. Sold GET parameters `upc`, `query`; response `{"sales":[{"price":30,"exact_match":true,"sold":true,"currency":"USD","condition":"New","date":<Unix seconds>,"url":"https://www.ebay.com/itm/123","title":"Exact product"}],"complete_30d":true,"active_low":35,"active_exact_match":true}`. Undated/incorrect-condition sales are rejected; only explicit exact-match and sold data qualify. At least three observations needed for an estimate; 10 and complete coverage needed for a positive evidence gate. Provider flags are its claims, not independently proven. Amazon response `{"price":30,"exact_match":true,"currency":"USD","url":"https://www.amazon.com/dp/..."}` remains separate. If no Amazon provider, only a search link is displayed. Provider integration requires validation with real authorized service credentials.

Sources tab:
- Authorized JSON product feed: trusted HTTPS GET `{"products":[{"name":"Widget","upc":"...","brand":"...","model":"...","cost":10,"url":"https://...","posted":<Unix seconds>}]}`. Feed price not trusted until direct verification.
- Retailer product/clearance page: exact approved URL; structured Product/Offer JSON-LD discovery/verification. No general-purpose retailer crawler or retailer-specific adapter beyond optional Best Buy API. Some sites have no usable markup.
- Local auction/surplus/estate/warehouse/discount: only accessed on request. Optional `feed_url` with `{"lots":[{"name":"Widget","url":"https://...","brand":"...","model":"...","upc":"...","cost":10,"lat":35.96,"lon":-83.92,"pickup_address":"...","close_at":<Unix seconds>,"buyer_premium":0.15,"condition":"..."}]}`. Feed values are source claims; verify on the site. National directories without location remain unknown. Browser parser recognizes catalog and lot link patterns, structured product metadata and explicit labels; HiBid/ATX/GovDeals selectors are not live-validated.

## What the learning engine does

Verified exact-identity corrections persist. Agreement across distinct confirmed examples creates a vote-support score; conflicting confirmations are flagged. A small instance-based text similarity model suggests prior verified products when identifiers are missing. It never upgrades a product merely because it was scanned repeatedly, and similarity is not a calibrated probability. No vision model retraining, automated buying, offline direct Gemini mode, system tray, or Windows startup/crash supervisor yet.

## Test scope

`python -m unittest -v` using the venv, with installed Chromium and httpx. Browser tests use real Chromium rendering of fixture HTML, mocked navigation and a FastAPI TestClient bridge; no external-site requests. Linux test results in TEST-RESULTS.txt. Windows-specific installation, Tailscale and all live providers still require acceptance testing. See FEATURES.md.

## 3.3.1 live operations update

The DealWatch tab and new Activity tab poll authenticated `/api/activity` every five seconds. Discovery finishes before evaluation so the scheduled-item denominator is known. Discovered leads can exceed scheduled leads because of the existing per-source limit. Processed excludes errors and stale skips; percentage counts all scheduled items that reached an outcome. A finished 100% cycle does not mean every possible deal online was searched. ETA is an observed-rate estimate for scheduled items, excluding subsequent stock/recheck work; it is unknown until enough progress exists. Counts describe repeated observations/evaluations, not unique products or confirmed sales. Daily counters use the PC local date; lifetime starts with this update.

Start/pause/resume/stop affect DealWatch, not the backend. Pause is cooperative at source/product boundaries; an in-flight request can finish. Stop abandons the rest of the current batch; Start initiates a new cycle. Mode and scanner-first/balanced priority persist in SQLite. Scanner-first is a cooperative scheduling preference, not preemption or Windows OS process priority. Local auctions remain on demand and are not started by DealWatch controls. Stock checks and scheduled rechecks run in the existing DealWatch worker; they honor its checkpoints. Provider cooldowns and browser occupancy are actual observations. The eBay countdown reflects the existing minimum interval, not a guarantee that the next request will succeed. CPU is system utilization measured between samples; RAM and process counts use psutil. The first CPU sample or unavailable resources can show unknown. The resource reading is not a GPU utilization monitor.

Activity records are structured, sanitized operational events rather than arbitrary raw stdout, shell access, request bodies, or page HTML. The latest 100 events appear in the UI and up to 10,000 are retained/exported. Persistent aggregates have no historical backfill. Exported reports can still contain product names and operational details; review before sharing. All monitoring and controls require the existing access token; keep Tailscale private. The browser/PC must stay on for remote access. The dashboard heartbeat is the last successful response and does not prove each worker is healthy. It is not a notification service.

To update: stop the backend, install requirements-test.txt using the existing venv, then run install_update.py --target YOUR_EXISTING_FOLDER. The updater preserves config.bat, start.bat and SQLite data. The tests use an isolated default database. No new settings or API keys are required. Real Windows/Tailscale/provider acceptance testing is still needed; this release does not fix external data availability or complete the original partially implemented source integrations.
