"""On-demand discovery. Source directory is not a live auction inventory."""
import re,time,math,json,os
from urllib.parse import urlparse
from datetime import datetime,timezone
from intelligence import SOURCES,JsonLD,walk,max_bid
from providers import public_url,allowed,browser_page,ProviderError
CENTER=(35.9606,-83.9207)
# Source addresses are intentionally not used as lot pickup locations.
def directory(custom=()):
    return [dict(name=n,url=u,category=k,region='Knoxville area' if n not in ('HiBid','GovDeals') else 'National; local location must be verified') for n,u,k in SOURCES]+[x for x in custom if x.get('category') in ('auction','surplus','estate','warehouse','discount') and public_url(x.get('url'))]

def distance(lat,lon,center=CENTER):
    a,b=map(math.radians,center);c,d=map(math.radians,(float(lat),float(lon)));v=math.sin((c-a)/2)**2+math.cos(a)*math.cos(c)*math.sin((d-b)/2)**2
    return 3958.76*2*math.asin(min(1,math.sqrt(v)))

def nearby(item,radius):
    try:
        lat=float(item['lat']);lon=float(item['lon'])
        if not -90<=lat<=90 or not -180<=lon<=180:return None
        return round(distance(lat,lon),1)
    except (ValueError,TypeError,KeyError):return None

def discover_links(page,source):
    host=urlparse(source['url']).hostname; seen=set();out=[]
    for l in page.get('links',[]):
        url=l.get('url','');title=l.get('title','')
        if not public_url(url) or not title or url in seen:continue
        h=urlparse(url).hostname or ''
        if not (h==host or h.endswith('.'+host) or host and host.endswith('.'+h)):continue
        if not re.search(r'/lot/|/catalog/|/auction[s]?/|/event[s]?/|/listing[s]?/|/asset[s]?/|/product[s]?/',urlparse(url).path,re.I):continue
        seen.add(url);out.append(dict(name=title,url=url,source=source['name'],category=source['category'],stock='Unverified',kind='lot' if '/lot/' in url else 'catalog',discovered_at=time.time()))
    return out

def parse_lot(page,source):
    """Read structured product facts only. Asking price is not automatically a bid."""
    parser=JsonLD();parser.feed(page.get('html',''));out=[]
    for v in walk(parser.items):
        types=v.get('@type',[]);types=[types] if isinstance(types,str) else types or []
        if 'Product' not in types:continue
        item={'name':v.get('name') or page.get('title'),'url':page['url'],'source':source['name'],'category':source['category'],'stock':'Unverified','brand':v.get('brand',{}).get('name') if isinstance(v.get('brand'),dict) else v.get('brand'),'model':v.get('mpn') or v.get('model'),'upc':v.get('gtin12') or v.get('gtin13') or v.get('gtin14'),'condition':str(v.get('itemCondition','unknown')),'kind':'lot','discovered_at':time.time()}
        # Only dedicated bid fields or explicitly labeled rendered bid are used.
        text=page.get('text','');b=re.search(r'\b(?:current|high|winning) bid\s*[:\n ]+\$\s*([\d,]+(?:\.\d{2})?)',text,re.I)
        if b:item['cost']=float(b[1].replace(',',''));item['price_type']='current bid (not final)'
        item.update(lot_terms(page))
        out.append(item)
    if not out and page.get('title'):
        text=page.get('text','');bid=re.search(r'\b(?:current|high|winning) bid\s*[:\n ]+\$\s*([\d,]+(?:\.\d{2})?)',text,re.I)
        if bid:out.append(dict(name=page['title'],url=page['url'],source=source['name'],category=source['category'],kind='lot',stock='Unverified',cost=float(bid[1].replace(',','')),price_type='current bid (not final)',**lot_terms(page)))
    return out

def assess(item,settings):
    p=dict(item);p['distance_miles']=nearby(p,settings['radius']);p['radius_status']='Unknown pickup location' if p['distance_miles'] is None else 'Within radius' if p['distance_miles']<=settings['radius'] else 'Outside radius'
    if p.get('resale') is not None and p.get('median') is not None and (p.get('sample') or 0)>=3:
        p['max_bid']=max_bid(float(p.get('p25') or p['median']),shipping=settings['shipping'],profit=settings['profit'],premium=p['buyer_premium'] if isinstance(p.get('buyer_premium'),(int,float)) and 0<=p['buyer_premium']<=1 else settings['premium'],tax=settings['tax'],travel=settings['travel'],risk=settings['risk'])
        p['bid_assumptions']={k:settings[k] for k in ('shipping','profit','premium','tax','travel','risk')}
    p['assessment']='Research lead — verify live bid, condition, pickup and terms'
    if isinstance(p.get('close_at'),(int,float)) and p['close_at']<time.time():p['assessment']='Rejected — auction ended'
    if p.get('max_bid') is not None and p.get('cost') is not None and p['cost']>p['max_bid']:p['assessment']='Rejected — bid exceeds target'
    if p.get('kind')=='directory':p['assessment']='Directory entry — not a verified auction'
    return p

def run(settings,custom,emit,progress,cancel,price,wait_priority,feed=None,page_loader=None):
    """Bounded per-request work; no periodic scheduler calls this function."""
    page_loader=page_loader or browser_page
    sources=[s for s in directory(custom) if s['category'] in settings['categories']];seen=set();budget=settings['max_pages'];count=0
    def stopped():return cancel() or budget<=0
    def save(p):
        nonlocal count
        if p.get('url') in seen:return
        seen.add(p.get('url'));p=assess(p,settings)
        if p['radius_status']!='Outside radius':emit(p);count+=1
    for source in sources:
        if cancel():break
        progress(source['name'],count)
        if feed and source.get('feed_url'):
            try:
                for p in feed(source['feed_url']).get('lots',[]):
                    if cancel():break
                    if isinstance(p,dict) and public_url(p.get('url')):
                        try:
                            p=dict(p);p.update({'source':source['name'],'category':source['category'],'kind':'lot','price_type':'current bid (not final)'})
                            if settings['depth']=='deep' and wait_priority():p.update(price(p))
                            save(p)
                        except Exception as e:progress(source['name']+' lot '+type(e).__name__,count)
            except Exception as e:progress(source['name']+' feed '+type(e).__name__,count)
        if stopped() or not allowed(source['url']):
            save(dict(name=source['name'],url=source['url'],source=source['name'],category=source['category'],kind='directory',stock='Not inspected',note='Browser authorization/remaining budget required'));continue
        if not wait_priority():break
        try:budget-=1;page=page_loader(source['url'])
        except ProviderError as e:progress(str(e),count);save(dict(name=source['name'],url=source['url'],source=source['name'],category=source['category'],kind='directory',stock='Source unavailable',note=str(e)));continue
        queue=discover_links(page,source)
        if not queue:save(dict(name=source['name'],url=source['url'],source=source['name'],category=source['category'],kind='directory',stock='No catalog links detected',note='Parser did not find a catalog; not proof that there are no auctions'))
        visited={source['url']}
        while queue and not cancel() and len(visited)<2000:
            p=queue.pop(0)
            if p['url'] in visited:continue
            visited.add(p['url'])
            if settings['depth']=='deep' and not stopped() and allowed(p['url']) and wait_priority():
                try:
                    time.sleep(3);budget-=1;detail=page_loader(p['url'])
                    if p['kind']=='catalog':queue.extend(discover_links(detail,source)[:500])
                    else:
                        lots=parse_lot(detail,source)
                        if lots:p.update(lots[0]);p.update(price(p));p['page_checked_at']=detail.get('checked_at');p['page_cached']=detail.get('cached',False)
                except Exception as e:p['note']=type(e).__name__
            save(p)
    return count

def lot_terms(page):
    """Extract clearly labeled terms and structured location. No guessed pickup location."""
    text=page.get('text','');out={'pickup_address':None,'close_at':None,'buyer_premium':None,'terms_checked_at':time.time()}
    m=re.search(r"(?:buyer['’]s? premium|buyers premium)\s*[:\n ]+(\d+(?:\.\d+)?)\s*%",text,re.I)
    if m and 0<=float(m[1])<=100:out['buyer_premium']=float(m[1])/100
    m=re.search(r'pickup address\s*[:\n ]+([^\n]{8,200})',text,re.I)
    if m:out['pickup_address']=m[1].strip()
    parser=JsonLD();parser.feed(page.get('html',''))
    for obj in walk(parser.items):
        typ=obj.get('@type');types=[typ] if isinstance(typ,str) else typ or []
        if 'Event' not in types and 'AuctionEvent' not in types:continue
        stamp=obj.get('endDate')
        if isinstance(stamp,str):
            try:
                d=datetime.fromisoformat(stamp.replace('Z','+00:00'))
                if d.tzinfo:out['close_at']=d.timestamp()
            except ValueError:pass
        # Event location is not assumed to be pickup location. Only explicit pickup data from feed.
    return out
