"""Instance-based text learning from explicitly confirmed identities only.
Similarity and vote support are not calibrated probabilities or vision training.
"""
import re,math,collections
from ebay_sales import identity

def features(text):
    s=' '.join(re.findall(r'[a-z0-9]+',str(text).lower()))
    return collections.Counter([*s.split(),*('g:'+s[i:i+3] for i in range(max(0,len(s)-2)))])

def similarity(a,b):
    a,b=features(a),features(b);den=math.sqrt(sum(v*v for v in a.values())*sum(v*v for v in b.values()))
    return sum(v*b.get(k,0) for k,v in a.items())/den if den else 0

def candidates(product,examples):
    text=' '.join(str(product.get(k) or '') for k in ('name','brand','model','evidence'))
    best={}
    for e in examples:
        key=identity(e)
        if e.get('verified') is not True or not key:continue
        score=max(similarity(text,e.get('alias','')),similarity(text,e.get('name','')))
        if score<.65:continue
        if key not in best or score>best[key]['similarity']:
            best[key]={'name':e['name'],'upc':e.get('upc'),'brand':e.get('brand'),'model':e.get('model'),'similarity':round(score,3),'note':'Prior confirmed text match; user verification required'}
    return sorted(best.values(),key=lambda p:p['similarity'],reverse=True)[:3]
