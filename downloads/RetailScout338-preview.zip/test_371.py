import unittest,tempfile
from unittest.mock import Mock,patch
import amazon_research as a
import amazon_offline_probe as off
class Repair(unittest.TestCase):
 def test_classification(self):
    for status in (401,403,429,503):self.assertIn(str(status),a.classify(status,'https://www.amazon.com/s'))
    self.assertIsNone(a.classify(200,'https://www.amazon.com/s'))
    self.assertIn('CAPTCHA',a.classify(200,'https://www.amazon.com/s',True))
 def test_trace(self):
    page=Mock(url='https://www.amazon.com/s?k=private');page.goto.return_value=Mock(status=429,headers={'retry-after':'120'});trace=[]
    with patch.object(a.providers,'network_allowed',return_value=True),self.assertRaises(a.NavigationStop):a.navigate(page,page.url,trace)
    self.assertEqual(trace[0]['http_status'],429);self.assertEqual(trace[0]['retry_after_seconds'],120);self.assertNotIn('private',str(trace))
 def test_saved_html(self):
    from playwright.sync_api import sync_playwright
    from test_browser import chromium
    with sync_playwright() as pw:
        b=chromium(pw)
        try:
            page=b.new_page();page.route('**/*',lambda r:r.abort());r=off.replay(page,'<script>throw 1</script><h1 id="productTitle">Bosch GT3000 8 pc set</h1><div id="corePrice_feature_div"><span class="a-price"><span class="a-offscreen">$25.99</span></span></div>',{'name':'Bosch GT3000 8 piece'},'https://www.amazon.com/dp/B001GNC8RS');self.assertEqual(r['result']['amazon_price'],25.99)
        finally:b.close()
 def test_suspend_reason(self):
    with tempfile.TemporaryDirectory() as d:
        a.suspend(d+'/db','existing restriction');r=a.research({'name':'Bosch GT3000'},d+'/db');self.assertFalse(r['amazon_network_attempted']);self.assertEqual(r['amazon_stop_reason'],'existing restriction')
