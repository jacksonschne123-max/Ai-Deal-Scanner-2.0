# 3.3.5 additions and limitations
See README.md for this release's implemented features and remaining limitations. The older feature inventory below describes earlier releases and is not a claim of completion of the entire roadmap.

# 3.3 roadmap audit (74 items)

**Legend:** I = implementation exercised in offline/unit or browser-fixture tests; P = partial, configurable foundation, or only generic adapter (not a complete live feature); N = not implemented. No row is a claim of live external-service validation. The test suite uses synthetic data; 74 requirements do not imply 74 one-to-one tests.

| # | Requirement | Status / scope |
|---|---|---|
| 1 | Missing UPC backup | I: brand/model identifier with checksum-aware UPC |
| 2 | Gemini search grounding/image recognition | P: existing vision + opt-in grounding, mocked response |
| 3 | Manufacturer model matching | I: token-boundary matching; ambiguous variants remain candidates |
| 4 | Identity confidence | P: AI confidence, verified vote support and text similarity, not calibrated vision confidence |
| 5 | UPC backup note | I: visible identity note |
| 6 | eBay pagination | I: next link/date cutoff, actual DOM fixture |
| 7 | Full 30-day window | I: cutoff + bounded page cap; incomplete if cap/markup prevents coverage |
| 8 | Median | I: primary sale statistic |
| 9 | Mean | I: secondary statistic |
| 10 | 25th percentile | I: conservative financial estimate |
| 11 | 7/30-day sales trends | I: week versus earlier portion of window |
| 12 | Individual sold evidence | I: dates, links, counts |
| 13 | Filtering incorrect variants/condition/bundles | P: strict UPC/model/condition/keywords; no exhaustive variant classifier |
| 14 | Amazon comparison | P: optional provider + search link; no provider account bundled |
| 15 | Direct retailer URL | P: authorized configured URLs / explicit RSS links only |
| 16 | Independent price check | P: rendered structured product offer / optional Best Buy API; no checkout check |
| 17 | Prefer leads in last 24h | I: recent-first sorting within a source |
| 18 | Reject over 72h | I: stale lead gate |
| 19 | USD / country verification | P: USD required, explicit US eBay domain; retailer country/checkout not independently verified |
| 20 | Knoxville preference | P: local directory and radius, no local retail nationwide geocoding |
| 21 | Stock verification | P: structured offer stock, live site tests pending |
| 22 | Local inventory | P: explicit pickup offer only; no chain-specific store inventory adapters |
| 23 | Rank verified first | I: evidence-gated ordering, separate rejected/unknown filters |
| 24 | Automatic price rechecks | P: due times 5/15/60m, bounded scheduler, rate limits may delay |
| 25 | Net profit | I: fees, shipping, tax, cashback, coupon, travel/risk assumptions |
| 26 | SQLite cleanup | I: context-managed connections and close test |
| 27 | Retry temporary failures | I: bounded backoff and persistent scan enrichment |
| 28 | 503 backoff | I: honors retry-after and provider cooldown |
| 29 | Persistent queue | I: scan/auction/enrichment tables and recovery |
| 30 | Browser crash recovery | P: browser closes per task, errors cached briefly, retry; no process supervisor |
| 31 | Short failure cache | I: 120s versus 15m successful cache |
| 32 | Individual failure isolation | I: scan/lead/lot failure handling |
| 33 | Diagnostics | I: provider status, uptime, events, counters and suspension |
| 34 | Regression tests | I: included suite |
| 35 | Exclude unsold completed | I: explicit sold label/flag and date required |
| 36 | Competing active eBay price | I: exact query/new condition fixture; live selectors pending |
| 37 | Cross-retailer comparison | P: known exact offers from configured sources only |
| 38 | Reject competing price below break-even | I: evidence gate |
| 39 | Stale/conflicting prices | I: timestamp gate, conflicting structured offers rejected |
| 40 | Shipping versus pickup | P: explicit fulfillment fields, no checkout/actual local inventory |
| 41 | Independent clearance discovery | P: configured clearance pages and JSON-LD; optional Best Buy API |
| 42 | Reverse sourcing | P: exact previously researched high-demand targets prioritized in configured feeds; no whole-market demand discovery |
| 43 | Permanent retailer price history | I: verified observations in SQLite |
| 44 | Price drop detection | I: compare last verified observation |
| 45 | Configurable Knoxville stores | P: authorized source URLs and pickup filters; no chain-specific store selectors |
| 46 | Prioritize recent | I: recent-first and due-time order |
| 47 | Source profitability metrics | I: lead counts/positive estimated profit, not realized profit |
| 48 | Prioritize successful sources | I: smoothed ranking based on verified-positive estimates |
| 49 | Local business directory | I: preconfigured and custom sources |
| 50 | HiBid | P: directory/link traversal; no live-validated dedicated integration |
| 51 | GovDeals | P: directory/link traversal; no live-validated dedicated integration |
| 52 | UT surplus | P: directory/link traversal; no live-validated dedicated integration |
| 53 | Estate auctions | P: directory and configurable sources; no exhaustive inventory |
| 54 | Independent warehouses | P: directory and configurable sources |
| 55 | Public announcements | P: opt-in grounded candidate discovery and approved URLs/feeds, no social API |
| 56 | Local versus national filters | P: radius on known auction coordinates and DealWatch pickup filter; unknown locations remain unknown |
| 57 | Independent business filter | P: local source category selectors, not automatic business classification |
| 58 | Exact source/pickup address | P: direct links and explicit pickup field when present; otherwise unknown |
| 59 | Radius | I: Haversine filter on explicit coordinates |
| 60 | Maximum bid | I: conservative formula with assumption disclosure |
| 61 | Closing time | P: explicit structured event end date or feed; live parser not validated |
| 62 | Buyer's premium | P: explicit label or feed, editable assumption otherwise |
| 63 | Condition/return risk | P: condition evidence and manual reserve; no automatic condition grading |
| 64 | Travel/pickup costs | I: editable cost assumption |
| 65 | Local Auction Hunter | I: dedicated tab and persistent request queue |
| 66 | On-demand only | I: no periodic local auction polling |
| 67 | Discover new local sites | P: opt-in Gemini grounded discovery, not automatic host authorization |
| 68 | Quick/deep modes | I: catalog versus bounded lot inspection |
| 69 | Independent browser research queue | I: auction queue, serialized general browser slot |
| 70 | Shared rate-limit management | P: shared HTTP gate, browser per-host gate, eBay persistent stop; no external quota introspection |
| 71 | Dynamic priorities | P: scanner priority between tasks; cannot interrupt in-flight browser operation |
| 72 | Pause/cancel | I: persistent states; pause waits for in-flight page, resume may revisit cached pages |
| 73 | Cached auction research | I: persistent 5-minute page cache and saved results |
| 74 | Release resources | I: browser close and completed job idle; fixture-tested logic, not long-run Windows test |

Additional items: responsive UI, manual scan, batch photo queue, snapshot camera retained; optional verified text learner; Stock Watch target/restock events. No native iOS/offline direct Gemini mode, real-time object tracking, automatic Windows startup/crash supervisor, system tray, push notifications, actual automatic coupon stacking, comprehensive seller eligibility, vision model retraining, or proof of one profitable real purchase. Existing inventory, sales, wholesale and discounts are recordkeeping. The live acceptance tests are still required.

## 3.3.1 monitoring additions

Implemented: live DealWatch cycle and stage counters; scheduled-item percentage; elapsed time, rate, estimated remaining time and next cycle; actual current product/source and sold-page events; timestamped structured Activity console; cooperative start/pause/resume/stop; persisted priority and mode; provider cooldown and error visibility; per-source, daily and lifetime evaluation totals; independent evidence-gap counts; CPU/RAM and browser process/slot monitoring; heartbeat and connection failure display; authenticated diagnostic download; persistent log history bounded to 10,000 rows. Scanner and auction events are separate from DealWatch counters. No arbitrary remote shell or raw terminal streaming. Counts begin with 3.3.1. Windows and live provider validation are pending.

## 3.3.2 discovery patch
Safe feed redirects; independent feed cooldowns; published FeedBurner endpoints; two additional RSS sources; custom RSS/Atom inputs; parsing diagnostics; duplicate URL suppression; persistent pending discovery; immediate unverified candidates; failed-versus-empty cycle status; shorter all-source-failure retry. Live feed retrieval remains unverified in this environment. Independent retailer discovery still requires configured authorized pages or API credentials. No access restriction bypass.

## 3.3.3 changes and remaining gaps

Implemented: dynamic public HTTPS access without hostname config, DNS/private-address checks, independent source errors, bounded catalog traversal with cross-HiBid/GovDeals links, 100/500 page budgets, source status separated from lot products, zero-lot jobs fail, explicit eBay/browser/Gemini telemetry, browser modes and opt-in snapshots, HTTP navigation timings, recent eBay cache/evidence and duration dashboard, diagnostic report additions. Existing auction cancellation and pause controls retained.

Partial or pending: live site-specific HiBid/ATX/GovDeals/UT/estate/warehouse adapters, current bid/condition and closing-date variants, exact pickup geocoding, exhaustive catalog pagination, durable per-lot traversal checkpoint, independent manual source probes, adaptive browser budget/speed, browser reuse/restart control, complete engine health cards, dedicated eBay persistent queue and retry controls, exact Amazon prices without provider. No live eBay/auction successful extraction established in build environment.

## 3.3.4 product intelligence
- Exploratory title queries no longer require UPC/MPN. Promotional suffixes removed; original title retained. Unique matching structured Product metadata can supply a checksum-valid UPC or manufacturer model. Existing grounded Gemini remains optional and model candidates are not treated as confirmed UPCs.
- Browser eBay results obtained by title remain exploratory; the verified-deal gate is unchanged. Amazon provider or public browser structured new USD in-stock offers can supply a preliminary reference; no Amazon-derived resale profit. Ambiguous or missing price remains unknown.
- DealWatch filters Amazon-only references and sorts profit, margin, ROI, reference gap and discount. Identity and Amazon activity filters added. Prior 3.3.3 unresolved deals are made due for bounded rechecks.
- Limitations: no full UPC search API, no guaranteed query shortening beyond heuristic cleaning, no independent identity cache beyond saved records and existing correction learning, bounded alternate queries, no exhaustive search, no third-party retailer price fallback, no Facebook engine. Live sites not validated. New/retail condition only. Amazon browser can fail if page metadata is absent or site restricts access.
