import activity
"""Authorized opt-in browser research. No challenge or rate-limit bypass."""
import os,re,time,sqlite3,json,threading,statistics
import providers
import research_debug as debug
from contextlib import closing
from urllib.parse import urlencode,urljoin,urlparse
from datetime import datetime,timezone
LOCK=threading.Lock(); last=0

def cooldown():
    return max(0,round(60-(time.monotonic()-last))) if last else 0

def valid_upc(u):
    return bool(re.fullmatch(r"\d{8}|\d{12,14}",u)) and sum(int(x)*(3 if i%2 else 1) for i,x in enumerate(reversed(u)))%10==0

def identity(p):
    u=str(p.get('upc') or '')
    if valid_upc(u): return u
    m=str(p.get('model') or '').strip()
    b=str(p.get('brand') or '').strip()
    return b+' '+m if b and len(m)>=4 and any(c.isdigit() for c in m) and len(b)<=80 and len(m)<=80 else ''

def matches(title,query):
    return bool(query) and all(re.search(r'(?<![\w])'+re.escape(t)+r'(?![\w])',title,re.I) for t in query.split())

def parse_cards(cards,query):
    out=[]; seen=set()
    for c in cards:
        title=c.get('title',''); link=c.get('link',''); price=c.get('price',''); date=c.get('date','')+' '+c.get('details',''); condition=c.get('condition','')
        if not matches(title+' '+c.get('details',''),query): continue
        if not re.fullmatch(r'New(?: with tags| in box)?',condition.strip(),re.I): continue
        if re.search(r'\b(?:lot|bundle|parts|broken|empty box|best offer|compatible with|case only|box only|for parts|refurbished)\b',title+' '+c.get('details',''),re.I): continue
        m=re.search(r'/itm/(?:[^/?]+/)?(\d+)',link); p=re.fullmatch(r'\$([\d,]+\.\d{2})',price.strip()); d=re.search(r'\bSold\s+([A-Za-z]{3} \d{1,2}, \d{4})',date,re.I)
        if not (m and p and d) or m[1] in seen: continue
        try: stamp=datetime.strptime(d[1],'%b %d, %Y').replace(tzinfo=timezone.utc).timestamp()
        except ValueError: continue
        if not 0<=time.time()-stamp<=30*86400: continue
        value=float(p[1].replace(',',''))
        if value<=0: continue
        seen.add(m[1]);out.append(dict(id=m[1],price=value,date=stamp,url='https://www.ebay.com/itm/'+m[1],title=title))
    return out

def summarize(sales,complete=False):
    now=time.time(); unique={str(s['id']):s for s in sales if 0<=now-s['date']<=30*86400 and s['price']>0}; sales=list(unique.values()); recent=sorted(s['price'] for s in sales); week=[s['price'] for s in sales if now-s['date']<=7*86400]; older=[s['price'] for s in sales if now-s['date']>7*86400]
    med=statistics.median(recent) if recent else None; q=None
    if recent:
        pos=(len(recent)-1)*.25; lo=int(pos); q=round(recent[lo]+(recent[min(lo+1,len(recent)-1)]-recent[lo])*(pos-lo),2)
    return dict(resale=round(med,2) if len(recent)>=3 else None,median=med,mean=round(statistics.mean(recent),2) if recent else None,p25=q,sample=len(recent),source='eBay sold (browser)',observed_7d=len(week),observed_30d=len(recent),median_7d=statistics.median(week) if week else None,trend_pct=round((statistics.median(week)/statistics.median(older)-1)*100,2) if week and older else None,sales=sales,complete=complete,coverage=('Date cutoff or end reached' if complete else 'Partial search')+'; observed listings only; shipping excluded')

def extract_cards(page):
    return page.locator('li.s-item, li.s-card').evaluate_all('''els=>els.map(e=>{const t=s=>e.querySelector(s)?.innerText||'';return {title:t('.s-item__title,.s-card__title'),price:t('.s-item__price,.s-card__price'),date:t('.s-item__title--tag,.s-item__caption,.s-card__caption'),condition:t('.SECONDARY_INFO,.s-card__subtitle'),details:e.innerText,link:e.querySelector('a[href*="/itm/"]')?.href||''}})''')

def crawl(page,query,delay=time.sleep,max_pages=None,private=False):
    url='https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':query,'LH_Sold':1,'LH_Complete':1,'LH_ItemCondition':1000,'_sop':13})
    all_cards=[]; complete=False; active=None
    def visit(url):
        started=time.monotonic();debug.event('eBay navigation started',url)
        try:response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
        except Exception:
            if urlparse(page.url).hostname in ('signin.ebay.com','accounts.google.com'):raise PermissionError('Authentication redirect; research suspended')
            raise
        debug.event('eBay response',url,status=response.status if response else None,seconds=round(time.monotonic()-started,2))
        if not response or response.status in (401,403,429) or re.search(r'captcha|security measure|verify you are human|access denied|pardon our interruption',page.title()+' '+page.locator('body').inner_text()[:3000],re.I): raise PermissionError('eBay access restricted; browser research suspended')
        if response.status>=400: raise RuntimeError('eBay HTTP '+str(response.status))
        if not page.url.startswith('https://www.ebay.com/sch/'): raise PermissionError('Unexpected eBay redirect; research suspended')
        if not private:debug.capture(page)
        return extract_cards(page)
    visited=set()
    for _ in range(max_pages or max(1,min(30,int(os.getenv('SCOUT_EBAY_MAX_PAGES','10'))))):
        if url in visited: break
        activity.emit('eBay sold page',engine='ebay',message=f'Page {len(visited)+1}',page=len(visited)+1);visited.add(url); cards=visit(url); all_cards+=cards
        dates=[]
        for card in cards:
            d=re.search(r'Sold\s+([A-Za-z]{3} \d{1,2}, \d{4})',card['date']+' '+card.get('details',''))
            if d:
                try: dates.append(datetime.strptime(d[1],'%b %d, %Y').replace(tzinfo=timezone.utc).timestamp())
                except ValueError: pass
        if dates and max(dates)<time.time()-30*86400: complete=True; break
        nxt=page.locator('a.pagination__next').first
        if not nxt.count():
            complete=bool(cards and dates) and bool(page.locator('.pagination__next[aria-disabled=true],button.pagination__next[disabled]').count()); break
        url=urljoin(page.url,nxt.get_attribute('href') or '')
        if not url.startswith('https://www.ebay.com/sch/'): break
        delay(3)
    delay(3)
    activity.emit('eBay competing prices',engine='ebay');cards=visit('https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':query,'LH_ItemCondition':1000,'_sop':15}))
    vals=[]
    for c in cards:
        m=re.fullmatch(r'\$([\d,]+\.\d{2})',c['price'].strip())
        if m and matches(c['title'],query) and re.fullmatch(r'New(?: with tags| in box)?',c['condition'].strip(),re.I) and not re.search(r'\b(bundle|lot|parts|compatible|only)\b',c['title'],re.I): vals.append(float(m[1].replace(',','')))
    if vals: active=min(vals)
    return all_cards,complete,active

def browse(query):
    from playwright.sync_api import sync_playwright
    with providers.BROWSER,sync_playwright() as p:
        import ebay_session
        if ebay_session.configured():
            context=ebay_session.launch(p,headless=debug.mode()!='visible')
            try:
                page=context.pages[0] if context.pages else context.new_page();providers.guard(page);return crawl(page,query,private=True)
            finally:context.close()
        browser=p.chromium.launch(headless=debug.mode()!='visible',**ebay_session.ENGINES[ebay_session.settings()])
        try:
            context=browser.new_context(accept_downloads=False,service_workers='block');page=context.new_page();providers.guard(page);return crawl(page,query)
        finally:browser.close()

def lookup(product,db):
    global last
    if os.getenv('SCOUT_EBAY_BROWSER')!='1': return None
    from identity_research import queries
    options=queries(product);q=options[0] if options else ""
    if not q:activity.emit('eBay skipped',engine='ebay',product=product.get('name'),message='No usable search query');return None
    with LOCK:
        with closing(sqlite3.connect(db,timeout=30)) as c, c:
            c.execute('CREATE TABLE IF NOT EXISTS ebay_cache (upc TEXT PRIMARY KEY, stamp REAL, data TEXT)');c.execute('CREATE TABLE IF NOT EXISTS ebay_control (id INTEGER PRIMARY KEY, reason TEXT)')
            if c.execute('SELECT reason FROM ebay_control WHERE id=1').fetchone():
                activity.emit('eBay suspended',engine='ebay',message='Authorized access test required');return None
            # Reuse successful observations; try an alternate query on a later request when the exact search found too few sales.
            attempts=[]
            for candidate in options:
                row=c.execute('SELECT stamp,data FROM ebay_cache WHERE upc=?',('334:'+candidate,)).fetchone()
                if not row:attempts.append((candidate,None,None));continue
                data=json.loads(row[1]);age=time.time()-row[0];ttl=900 if data.get('resale') is not None else 120
                if data.get('resale') is not None and age<ttl:
                    activity.emit('eBay cache hit',engine='ebay',product=product.get('name'));return dict(data,exploratory=candidate!=identity(product))
                attempts.append((candidate,data,age))
            # Actual zero/low-sample searches can advance to a different query; transport errors wait for retry.
            first=attempts[0];selected=first
            for attempt in attempts:
                candidate,data,age=attempt;selected=attempt
                if data is None or data.get('error') or age>=900 or data.get('cards_inspected') is None:break
            q,data,age=selected
            if data is not None and age<120:
                activity.emit('eBay cache hit',engine='ebay',product=product.get('name'));return dict(data,exploratory=q!=identity(product))
        if time.monotonic()-last<60: activity.emit('eBay cooldown',engine='ebay',message='Retry later');return {'resale':None,'source':'eBay rate-limited; retry later','deferred':True,'retry_after':60,'sample':0,'complete':False}
        last=time.monotonic();activity.emit('eBay search started',engine='ebay',product=product.get('name'),message=q)
        try:
            raw=browse(q); cards,complete,active=raw if isinstance(raw,tuple) else (raw,False,None)
            result=summarize(parse_cards(cards,q),complete);result['duration_seconds']=round(time.monotonic()-last,2);result['cards_inspected']=len(cards);activity.emit('eBay sales collected',engine='ebay',message=f"{result['sample']} matching sales; coverage {'complete' if complete else 'partial'}");result['active_low']=active;result['query']=q;result['exploratory']=q!=identity(product);result['researched_at']=time.time()
        except PermissionError as e:
            activity.emit('eBay suspended',engine='ebay',message='Access restricted; review authorization')
            with closing(sqlite3.connect(db,timeout=30)) as c,c: c.execute('INSERT OR REPLACE INTO ebay_control VALUES(1,?)',(str(e),))
            return None
        except Exception as e: activity.emit('eBay browser error',engine='ebay',message=type(e).__name__);result={'resale':None,'source':'eBay browser error','error':type(e).__name__,'deferred':True,'retry_after':120,'researched_at':time.time()}
        with closing(sqlite3.connect(db,timeout=30)) as c,c: c.execute('INSERT OR REPLACE INTO ebay_cache VALUES(?,?,?)',('334:'+q,time.time(),json.dumps(result)))
        return result
