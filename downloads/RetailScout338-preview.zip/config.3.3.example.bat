@echo off
rem OPTIONAL settings to append to your existing config.bat, not replace it.
rem Enable only if you accept Gemini search-grounding costs.
set "SCOUT_GROUNDING=0"
set "SCOUT_AUCTION_DISCOVERY=0"
rem Public HTTPS discovery is dynamic in 3.3.3. Respect site restrictions.
rem Default 10 pages, bounded 1-30. Coverage is marked partial if the cap is reached.
set "SCOUT_EBAY_MAX_PAGES=10"
set "SCOUT_FEE=0.15"
set "SCOUT_SHIPPING=6"
set "SCOUT_FEED_LIMIT=25"
rem Authorized provider endpoints and key, if you have them:
rem set "SCOUT_SOLD_URL=https://your-provider.example/sold"
rem set "SCOUT_AMAZON_URL=https://your-provider.example/amazon"
rem set "SCOUT_PROVIDER_KEY=your-private-provider-key"

rem 3.3.7 defaults to Amazon-first estimates; no paid APIs.
set "SCOUT_PRICING_MODE=amazon"
rem Only enable automated Amazon browsing if authorized.
set "SCOUT_AMAZON_AUTHORIZED=0"
set "SCOUT_AMAZON_ENGINE=chrome"
set "SCOUT_AMAZON_VISIBLE=1"

rem Optional approved US Selling Partner API application (separate from website browser).
rem Do not share these credentials or enable without authorization for this use.
rem set "SCOUT_SPAPI_AUTHORIZED=1"
rem set "SCOUT_SPAPI_CLIENT_ID=..."
rem set "SCOUT_SPAPI_CLIENT_SECRET=..."
rem set "SCOUT_SPAPI_REFRESH_TOKEN=..."
rem Maximum price cache age, 60-86400 seconds (not a current-price guarantee).
set "SCOUT_AMAZON_CACHE_SECONDS=86400"
