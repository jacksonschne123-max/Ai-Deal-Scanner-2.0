import os,time,unittest,tempfile,socket
from unittest.mock import patch
from fastapi.testclient import TestClient
import providers as p,auctions as a,server as s,activity,research_debug as d
class NewTests(unittest.TestCase):
 def test_dynamic_public(self):
    with patch.dict(os.environ,{'SCOUT_BROWSER_HOSTS':''}):self.assertTrue(p.allowed('https://new-auction.example/catalog/2'))
    for url in ('https://127.0.0.1','https://[::1]','https://foo.ts.net','https://foo.local','https://user:pass@public.example','http://public.example','https://public.example:8080'):
        self.assertFalse(p.allowed(url),url)
 def test_private_dns(self):
    with patch.object(p.socket,'getaddrinfo',return_value=[(2,1,6,'',('192.168.0.1',443))]):self.assertFalse(p.network_allowed('https://public.example'))
    with patch.object(p.socket,'getaddrinfo',return_value=[(2,1,6,'',('8.8.8.8',443))]):self.assertTrue(p.network_allowed('https://public.example'))
 def test_no_phantom_results(self):
    source={'name':'Directory','url':'https://auction.example/','category':'auction'};out=[]
    with patch.object(a,'directory',return_value=[source]):count=a.run(s.AuctionSettings().model_dump(),[],out.append,lambda *_:None,lambda:False,lambda _:self.fail('Directory priced'),lambda:True,page_loader=lambda _:{'links':[]})
    self.assertEqual(count,0);self.assertTrue(all(x['kind']=='directory' for x in out))
 def test_catalog_to_lot(self):
    source={'name':'Test','url':'https://auction.example/','category':'auction'};out=[]
    pages={source['url']:{'links':[{'url':'https://auction.example/catalog/1','title':'Catalog'}]},'https://auction.example/catalog/1':{'links':[{'url':'https://auction.example/lot/1','title':'Widget'}]},'https://auction.example/lot/1':{'url':'https://auction.example/lot/1','title':'Acme ABC123','text':'Current bid: $12.50','links':[]}}
    with patch.object(a,'directory',return_value=[source]),patch.object(a.time,'sleep'):count=a.run(s.AuctionSettings(depth='deep').model_dump(),[],out.append,lambda *_:None,lambda:False,lambda _: {'median':50},lambda:True,page_loader=pages.__getitem__)
    self.assertEqual(count,1);self.assertEqual([x['cost'] for x in out if x['kind']=='lot'],[12.5])
 def test_debug_auth_and_scope(self):
    with tempfile.TemporaryDirectory() as t,patch.object(s,'DB',t+'/db'),patch.object(s,'TOKEN','test-token'):
        s.init();c=TestClient(s.app);h={'x-scout-token':'test-token'};self.assertEqual(c.get('/api/browser-debug').status_code,401);self.assertEqual(c.get('/api/ebay-research').status_code,401)
        with activity.scope('dealwatch'):activity.emit('eBay sold page',engine='ebay',page=2)
        self.assertEqual(s.LIVE.history()[0]['engine'],'ebay');self.assertEqual(s.LIVE.snapshot()['page'],2)
        self.assertEqual(c.post('/api/browser-debug/remote',headers=h).json()['mode'],'remote');self.assertEqual(c.post('/api/browser-debug/invalid',headers=h).status_code,400);self.assertEqual(c.post('/api/browser-debug/headless',headers=h).status_code,200);self.assertIsNone(c.get('/api/browser-debug',headers=h).json()['screenshot']);self.assertEqual(c.get('/api/ebay-research',headers=h).json()['events'][0]['engine'],'ebay')
 def test_debug_url(self):self.assertNotIn('secret',d.safe_url('https://example.com/path?token=secret'))
