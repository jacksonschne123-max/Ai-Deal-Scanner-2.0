"""Offline contracts and regression tests. No external requests or personal keys."""
import os,time,tempfile,sqlite3,json,threading,unittest
from datetime import datetime,timezone,timedelta
from pathlib import Path
from unittest.mock import patch,Mock
from email.utils import formatdate
from fastapi.testclient import TestClient
import server as s, ebay_sales as e, intelligence as i, auctions as a, providers as p, dealwatch as d, learning as l
from test_server import UPC,sold

def product_html(price=25,currency='USD',availability='InStock',gtin=UPC,shipping=True,extra=None):
    v={'@type':'Product','name':'Widget','gtin12':gtin,'brand':'Acme','mpn':'ABC123','offers':{'@type':'Offer','price':price,'priceCurrency':currency,'availability':'https://schema.org/'+availability}}
    if shipping:v['offers']['shippingDetails']={'@type':'OfferShippingDetails'}
    if extra:v['offers'].update(extra)
    return '<script type="application/ld+json">'+json.dumps(v)+'</script>'
def eligible(**kw):
    v=dict(name='Widget',upc=UPC,identity_method='UPC',source='eBay sold (provider)',price_verified=True,verified_at=time.time(),posted=time.time(),stock='Online available',profit=15,roi=50,break_even=30,active_low=55,sample=10,complete=True,researched_at=time.time(),cost=20);v.update(kw);return v

def card(n,price=50,age=1,**kw):
    x=dict(title='Acme ABC123 '+UPC,price=f'${price:.2f}',date='Sold '+(datetime.now(timezone.utc)-timedelta(days=age)).strftime('%b %d, %Y'),condition='New',link='https://www.ebay.com/itm/'+str(n));x.update(kw);return x
class Evidence(unittest.TestCase):
 def test_upc_checksum(self):self.assertTrue(e.valid_upc(UPC));self.assertFalse(e.valid_upc('123456789013'));self.assertFalse(e.valid_upc('123'))
 def test_model_fallback(self):self.assertEqual(e.identity({'brand':'Acme','model':'ABC123'}),'Acme ABC123');self.assertEqual(e.identity({'name':'Unknown'}),'')
 def test_model_boundary(self):self.assertTrue(e.matches('Acme ABC123 new','Acme ABC123'));self.assertFalse(e.matches('Acme ABC1234','Acme ABC123'))
 def test_exclude_unsold_old_wrong_condition(self):
    cards=[card(1),card(1),card(2,age=31),card(3,date='Ended Nov 1, 2026'),card(4,condition='Used'),card(5,title='Bundle '+UPC),card(6,title='Different'),card(7,title='Case only '+UPC),card(8,price=0),card(9,date='Bad'),card(10,title='Best offer '+UPC),card(11,age=-5)]
    self.assertEqual([x['id'] for x in e.parse_cards(cards,UPC)],['1'])
 def test_median_mean_quantiles(self):
    rows=e.parse_cards([card(1,10),card(2,20),card(3,30),card(4,1000)],UPC);r=e.summarize(rows+rows,True);self.assertEqual(r['median'],25);self.assertEqual(r['p25'],17.5);self.assertEqual(r['mean'],265);self.assertEqual(r['sample'],4);self.assertTrue(r['complete'])
 def test_trend(self):
    r=e.summarize(e.parse_cards([card(1,20,1),card(2,30,4),card(3,10,15)],UPC));self.assertEqual(r['observed_7d'],2);self.assertEqual(r['trend_pct'],150)
 def test_sparse(self):self.assertIsNone(e.summarize(e.parse_cards([card(1)],UPC))['resale'])
 def test_retail_structured(self):
    r=i.retail_offer(product_html(),{'upc':UPC});self.assertEqual(r['cost'],25);self.assertEqual(r['stock'],'Online available');self.assertTrue(r['price_verified'])
 def test_wrong_currency(self):self.assertEqual(i.retail_offer(product_html(currency='AUD'),{'upc':UPC}),{})
 def test_conflicting_offer(self):self.assertEqual(i.retail_offer(product_html()+product_html(30),{'upc':UPC}),{})
 def test_wrong_identity(self):self.assertEqual(i.retail_offer(product_html(gtin='123456789029'),{'upc':UPC}),{})
 def test_out_of_stock(self):self.assertEqual(i.retail_offer(product_html(availability='OutOfStock'),{'upc':UPC})['stock'],'Unavailable')
 def test_unknown_fulfillment(self):self.assertIn('unknown',i.retail_offer(product_html(shipping=False),{'upc':UPC})['stock'])
 def test_pickup(self):self.assertEqual(i.retail_offer(product_html(shipping=False,extra={'availableDeliveryMethod':'https://schema.org/DeliveryModePickUp','availableAtOrFrom':{'name':'Local store'}}),{'upc':UPC})['stock'],'Pickup available')
 def test_eligibility(self):self.assertTrue(i.gate(eligible()).startswith('Positive'))
 def test_gate_stale(self):self.assertIn('stale',i.gate(eligible(posted=time.time()-73*3600)));self.assertIn('verify retail',i.gate(eligible(verified_at=time.time()-901)))
 def test_gate_unavailable(self):self.assertIn('Rejected',i.gate(eligible(stock='Unavailable')))
 def test_gate_partial_sample(self):self.assertIn('insufficient',i.gate(eligible(complete=False)));self.assertIn('insufficient',i.gate(eligible(sample=9)))
 def test_gate_amazon(self):self.assertIn('insufficient',i.gate(eligible(source='Amazon asking price')))
 def test_gate_active(self):self.assertIn('competing prices unknown',i.gate(eligible(active_low=None)));self.assertIn('Rejected',i.gate(eligible(active_low=29)))
 def test_gate_model(self):self.assertIn('exact variant',i.gate(eligible(identity_method='Model fallback')))
 def test_rank(self):self.assertGreater(i.rank(eligible(assessment='Positive estimate')),i.rank(eligible(profit=999,assessment='Potential lead')))
 def test_cross_retailer(self):
    v=eligible(url='https://one.example/p');other=eligible(url='https://two.example/p',cost=18);self.assertEqual(i.compare_exact(v,[v,other,eligible(url='https://three.example/p',upc='123456789029')])[0]['cost'],18)
 def test_bid(self):self.assertEqual(i.max_bid(80,shipping=10,profit=20,premium=.15,tax=.0925),30.24);self.assertRaises(ValueError,i.max_bid,80,fee=1)
 def test_source_priority(self):self.assertGreater(i.source_priority('good',{'good':{'leads':10,'verified_positive':5}}),i.source_priority('bad',{}))
 def test_learner(self):
    examples=[{'name':'Acme ABC123 headphones','upc':UPC,'verified':True,'alias':'Acme ABC123 headphones'},{'name':'Acme ABC123 headphones','upc':'123456789029','verified':False}];r=l.candidates({'name':'Acme ABC123 headphones'},examples);self.assertEqual(len(r),1);self.assertEqual(r[0]['upc'],UPC);self.assertGreater(r[0]['similarity'],.9)
class Transport(unittest.TestCase):
 def test_503_backoff(self):
    g=p.Gate();r=Mock(status_code=503,headers={'Retry-After':'120'});with_env=patch.object(p,'GATE',g)
    with with_env,patch.object(p.requests,'request',return_value=r) as req:
        with self.assertRaises(p.Deferred):p.request_json('GET','https://example.com','test')
        with self.assertRaises(p.Deferred):p.request_json('GET','https://example.com','test')
        self.assertEqual(req.call_count,1);self.assertIn('503',g.snapshot()['test']['error'])
 def test_retry_after(self):self.assertEqual(p.retry_after('15'),15);self.assertGreaterEqual(p.retry_after(formatdate(time.time()+30,usegmt=True)),28)
 def test_auth_stop(self):
    with patch.object(p,'GATE',p.Gate()),patch.object(p.requests,'request',return_value=Mock(status_code=403,headers={})) as req:
        with self.assertRaises(p.Deferred):p.request_json('GET','https://example.com','test')
        self.assertEqual(req.call_count,1)
 def test_allowlist(self):
    with patch.dict(os.environ,{'SCOUT_BROWSER_HOSTS':'retail.example'}):self.assertTrue(p.allowed('https://retail.example/p'));self.assertTrue(p.allowed('https://retail.example.evil.com/p'));self.assertFalse(p.allowed('http://retail.example/p'));self.assertFalse(p.public_url('https://127.0.0.1'));self.assertFalse(p.public_url('https://x.local'));self.assertFalse(p.public_url('https://user:pass@example.com'));self.assertFalse(p.allowed('https://retail.example:invalid'))
 def test_recovery_after_cooldown(self):
    g=p.Gate();g.check('test');g.fail('test','503',1);self.assertRaises(p.Deferred,g.check,'test');g.states['test']['next']=0;g.check('test');g.good('test');self.assertEqual(g.snapshot()['test']['failures'],0)
class Local(unittest.TestCase):
 def settings(self,**kw):return dict(s.AuctionSettings().model_dump(),**kw)
 def test_distance(self):self.assertAlmostEqual(a.distance(*a.CENTER),0);self.assertIsNone(a.nearby({},50));self.assertEqual(a.assess({'lat':35.96,'lon':-83.92},self.settings())['radius_status'],'Within radius')
 def test_terms(self):
    h='<script type="application/ld+json">{"@type":"Event","endDate":"2027-01-01T18:00:00-05:00"}</script>';r=a.lot_terms({'html':h,'text':"Buyer’s premium: 15%\nPickup address: 10 Example Road, Knoxville TN"});self.assertEqual(r['buyer_premium'],.15);self.assertIn('Knoxville',r['pickup_address']);self.assertIsInstance(r['close_at'],float)
 def test_links(self):
    src={'name':'test','url':'https://auction.example/','category':'auction'};r=a.discover_links({'links':[{'url':'https://auction.example/lot/1','title':'Widget'},{'url':'https://auction.example/lot/1','title':'Dup'},{'url':'https://evil.example/lot/2','title':'Bad'},{'url':'https://auction.example/about','title':'About'}]},src);self.assertEqual(len(r),1);self.assertEqual(r[0]['kind'],'lot')
 def test_lot_no_guess(self):
    src={'name':'test','category':'auction'};r=a.parse_lot({'html':product_html(),'text':'Current bid: $8.50','url':'https://auction.example/lot/1','title':'Widget'},src)[0];self.assertEqual(r['cost'],8.5);self.assertIsNone(r['buyer_premium']);self.assertEqual(r['upc'],UPC);self.assertIsNone(r['pickup_address'])
 def test_auction_ended(self):self.assertIn('ended',a.assess({'close_at':time.time()-1},self.settings())['assessment'])
 def test_no_browser_by_default(self):
    out=[]
    with patch.object(a,'allowed',return_value=False),patch.object(a,'browser_page') as page:a.run(self.settings(depth='deep'),[],out.append,lambda *_:None,lambda:False,lambda _: {},lambda:True);page.assert_not_called()
    self.assertTrue(out);self.assertTrue(all(x['kind']=='directory' for x in out))
 def test_quick_deep_budget_cancel(self):
    source={'name':'Test','url':'https://auction.example/','category':'auction'};home={'links':[{'url':'https://auction.example/catalog/1','title':'Catalog'}]};catalog={'links':[{'url':'https://auction.example/lot/1','title':'Widget'}]};lot={'url':'https://auction.example/lot/1','html':product_html(),'text':'Current bid: $8.00','title':'Widget'};out=[]
    with patch.object(a,'directory',return_value=[source]),patch.object(a,'allowed',return_value=True),patch.object(a.time,'sleep'),patch.object(a,'browser_page',side_effect=[home,catalog,lot]) as page:
        a.run(self.settings(depth='deep',max_pages=3),[],out.append,lambda *_:None,lambda:False,lambda _:{'median':60,'resale':60,'p25':50,'sample':10},lambda:True);self.assertEqual(page.call_count,3);self.assertTrue(any(x.get('max_bid') is not None for x in out))
    with patch.object(a,'directory',return_value=[source]),patch.object(a,'browser_page') as page:a.run(self.settings(),[],lambda _:None,lambda *_:None,lambda:True,lambda _: {},lambda:True);page.assert_not_called()
 def test_feed_radius(self):
    src={'name':'Test','url':'https://auction.example/','category':'auction','feed_url':'https://auction.example/feed'};out=[]
    with patch.object(a,'directory',return_value=[src]),patch.object(a,'allowed',return_value=False):a.run(self.settings(),[],out.append,lambda *_:None,lambda:False,lambda _: {},lambda:True,feed=lambda _:{'lots':[{'name':'Far','url':'https://auction.example/lot/1','lat':40,'lon':-90},{'name':'Near','url':'https://auction.example/lot/2','lat':35.96,'lon':-83.92}]})
    self.assertNotIn('Far',[x['name'] for x in out]);self.assertIn('Near',[x['name'] for x in out])
class Database(unittest.TestCase):
 def setUp(self):
    t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);db=patch.object(s,'DB',t.name+'/test.db');db.start();self.addCleanup(db.stop);env=patch.dict(os.environ,{'SCOUT_RSS':'0','SCOUT_EBAY_BROWSER':'0','SCOUT_GROUNDING':'0','SCOUT_SOLD_URL':'','SCOUT_AMAZON_URL':'','BESTBUY_API_KEY':'','SCOUT_BROWSER_HOSTS':''});env.start();self.addCleanup(env.stop);s.STOP.clear();s.init()
 def test_closed_connections(self):
    with s.conn() as c:c.execute('SELECT 1')
    with self.assertRaises(sqlite3.ProgrammingError):c.execute('SELECT 1')
 def test_restart(self):
    with s.conn() as c:c.execute("INSERT INTO jobs(image,status,created) VALUES('x','running',0)");c.execute("INSERT INTO research(settings,status,created,updated) VALUES('{}','running',0,0)")
    s.init();self.assertEqual(s.jobs()[0]['status'],'queued');self.assertEqual(s.auction_jobs()[0]['status'],'queued')
 def test_legacy(self):
    s.save('deal',{'name':'legacy','profit':100,'resale':200});s.init();r=s.rows('deal')[0];self.assertIsNone(r['profit']);self.assertIn('Legacy',r['assessment'])
 def test_history_and_dedup(self):
    x=eligible(fingerprint='x',version=s.VERSION);s.upsert_deal(x);s.upsert_deal(dict(x,cost=10));self.assertEqual(len(s.rows('deal')),1);self.assertEqual(len(s.history('x')),2);self.assertEqual(s.rows('deal')[0]['price_drop_pct'],50)
 def test_auction_queue(self):
    jid=s.start_auction(s.AuctionSettings())['id'];self.assertRaises(Exception,s.start_auction,s.AuctionSettings());s.auction_action(jid,'pause');self.assertEqual(s.auction_jobs()[0]['status'],'paused');s.auction_action(jid,'resume');self.assertEqual(s.auction_jobs()[0]['status'],'queued');s.auction_action(jid,'cancel');self.assertEqual(s.auction_jobs()[0]['status'],'cancelled')
 def test_pause_running(self):
    jid=s.start_auction(s.AuctionSettings())['id'];
    with s.conn() as c:c.execute("UPDATE research SET status='running' WHERE id=?",(jid,))
    s.auction_action(jid,'pause');self.assertEqual(s.auction_jobs()[0]['status'],'pausing');self.assertRaises(Exception,s.start_auction,s.AuctionSettings());s.auction_action(jid,'cancel');self.assertEqual(s.auction_jobs()[0]['status'],'cancelling')
 def test_auction_only_on_demand(self):
    s.save('source',{'name':'Local','category':'auction','url':'https://auction.example'});
    with patch.object(s,'fetch_json') as f,patch.object(a,'run') as run:s.monitor_once();f.assert_not_called();run.assert_not_called()
 def test_auction_worker(self):
    jid=s.start_auction(s.AuctionSettings())['id'];stop=threading.Event()
    def run(settings,custom,emit,progress,cancel,price,wait_priority,**kw):emit({'name':'test','url':'https://auction.example/lot/1'});progress('done',1);return 1
    with patch.object(a,'run',side_effect=run):
        t=threading.Thread(target=s.auction_worker,args=(stop,));t.start();deadline=time.monotonic()+5
        while time.monotonic()<deadline and s.auction_jobs()[0]['status']!='done':time.sleep(.02)
        stop.set();t.join(2)
    self.assertEqual(s.auction_jobs()[0]['status'],'done');self.assertEqual(s.rows('auction')[0]['research_id'],jid)
 def test_cache(self):
    with patch.dict(os.environ,{'SCOUT_BROWSER_HOSTS':'auction.example'}),patch.object(p,'browser_page',return_value={'html':'','text':'','links':[],'url':'https://auction.example'}) as f:
        self.assertFalse(s.auction_page('https://auction.example')['cached']);self.assertTrue(s.auction_page('https://auction.example')['cached']);self.assertEqual(f.call_count,1)
 def test_dated_provider(self):
    data={'sales':[sold(1),sold(1),sold(2,age=31),dict(sold(3),sold=False),dict(sold(4),currency='AUD'),dict(sold(5),condition='Used'),dict(sold(6),date=None),sold(7)]};self.assertEqual(e.summarize(s.clean_sales(data))['sample'],2)
 def test_failure_cache_and_retry(self):
    with patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',-100),patch.object(e,'browse',side_effect=RuntimeError('crash')) as f:
        r=e.lookup({'upc':UPC},s.DB);self.assertTrue(r['deferred']);e.lookup({'upc':UPC},s.DB);self.assertEqual(f.call_count,1)
 def test_correction_conflict(self):
    s.save('correction',{'name':'One','upc':UPC,'verified':True,'scan_id':1});s.save('correction',{'name':'Two','upc':UPC,'verified':True,'scan_id':2});r=s.learned({'name':'Original','upc':UPC});self.assertTrue(r['learning_conflict']);self.assertEqual(r['name'],'Original')
 def test_scan_isolation_and_enrichment(self):
    s.scan(s.Upload(image='data:image/jpeg;base64,YQ=='));stop=threading.Event()
    def proc(x):
        if x['name']=='bad':raise ValueError('bad')
        return dict(x,deferred=True,retry_after=60)
    with patch.object(s,'identify',return_value=[{'name':'bad'},{'name':'good'}]),patch.object(s,'process',side_effect=proc):
        t=threading.Thread(target=s.worker,args=(stop,));t.start();deadline=time.monotonic()+5
        while time.monotonic()<deadline and s.jobs()[0]['status']!='done':time.sleep(.02)
        stop.set();t.join(2)
    self.assertEqual(s.jobs()[0]['status'],'done');self.assertEqual(len(s.rows('scan')),2);self.assertEqual(s.status()['pending_enrichment'],1)
 def test_gemini_grounding(self):
    result={'candidates':[{'content':{'parts':[{'text':'{"name":"Acme ABC123","brand":"Acme","model":"ABC123"}'}]},'groundingMetadata':{'groundingChunks':[{'web':{'uri':'https://maker.example/product'}}]}}]}
    with patch.dict(os.environ,{'SCOUT_GROUNDING':'1','GEMINI_API_KEY':'test-not-real'}),patch.object(s,'gemini',return_value=result):r=s.prepare_identity({'name':'Widget'});self.assertEqual(r['identity_method'],'Model fallback');self.assertEqual(len(r['grounding_links']),1)
 def test_stock_watch(self):
    s.save('watch',{'name':'Widget','upc':UPC,'target_price':'20','url':'https://retail.example/product'});
    with patch.dict(os.environ,{'SCOUT_BROWSER_HOSTS':'retail.example'}),patch.object(s,'verify',return_value={'cost':15,'stock':'Online available','price_verified':True}):s.watch_once(s.STOP);s.watch_once(s.STOP)
    self.assertEqual(s.rows('watch')[0]['last_price'],15);self.assertEqual(len(s.rows('event')),1)
 def test_reverse_target(self):
    s.save('scan',eligible(median=50));self.assertEqual(s.reverse_targets()[0]['upc'],UPC)
 def test_retail_clearance(self):
    with patch.dict(os.environ,{'SCOUT_BROWSER_HOSTS':'retail.example'}):r=d.product_candidates({'html':product_html(),'url':'https://retail.example/product'},'Retailer');self.assertEqual(r[0]['upc'],UPC)
 def test_auction_source_discovery(self):
    fixture={'candidates':[{'content':{'parts':[{'text':'[{"name":"Auction","url":"https://auction.example/","category":"auction"}]'}]},'groundingMetadata':{'groundingChunks':[{'web':{'uri':'https://auction.example/'}}]}}]}
    with patch.object(s,'gemini',return_value=fixture):self.assertEqual(s.discover_sources(s.AuctionSettings().model_dump())[0]['name'],'Auction')
if __name__=='__main__':unittest.main()
