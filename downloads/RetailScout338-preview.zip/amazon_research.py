"""Amazon asking-price observations, never completed sales. Browser access is opt-in."""
import json,math,os,re,sqlite3,time,threading
from urllib.parse import urlparse,urlencode,urljoin
from contextlib import closing
import activity,identity_research as ids,ebay_sales,providers
import amazon_spapi as spapi
LOCK=threading.Lock()
HOSTS={'amazon.com','www.amazon.com'}

def canonical(url):
    try:
        p=urlparse(url or '');m=re.search(r'/(?:dp|gp/product)/([A-Z0-9]{10})(?:/|$)',p.path,re.I)
        return 'https://www.amazon.com/dp/'+m[1].upper() if p.scheme=='https' and p.hostname in HOSTS and not p.username and not p.password and p.port in (443,None) and m else ''
    except ValueError:return ''

def tokens(s):return re.findall(r'[a-z0-9]+',str(s).lower())
def matches(title,p):
    # Prefer manufacturer model AND product name; a UPC search alone is not a title match.
    q=ids.title_query(p) or ids.query(dict(p,upc=None))
    if not q:return False
    t=tokens(re.sub(r'\b(?:pc|pcs|pieces)\b','piece',title,flags=re.I));q=tokens(re.sub(r'\b(?:pc|pcs|pieces)\b','piece',q,flags=re.I))
    if not q or not all(x in t for x in q):return False
    if re.search(r'\b(?:replacement|compatible with|for use with|case only|filter basket|renewed|refurbished|parts only)\b',title,re.I) and not re.search(r'\b(?:replacement|compatible with|for use with|case only|filter basket|renewed|refurbished|parts only)\b',p.get('name',''),re.I):return False
    return True

def candidates(cards,p):
    out={}
    for card in cards:
        u=canonical(card.get('url'));title=card.get('title','')
        if u and matches(title,p):out[u]=title[:350]
    return [{'url':u,'title':t} for u,t in out.items()]

def usd(s):
    m=re.fullmatch(r'\s*(?:US)?\$\s*(\d[\d,]*\.\d{2})\s*',str(s or ''))
    v=float(m[1].replace(',','')) if m else 0
    return v if math.isfinite(v) and 0<v<1e7 else None

def evaluate(raw,p,url):
    u=canonical(url);title=str(raw.get('title') or '').strip();price=usd(raw.get('price'));stock=str(raw.get('availability') or '').split('{')[0].strip()[:200];condition=str(raw.get('condition') or '').strip()[:100]
    if raw.get('challenge'):return {'amazon_status':'restricted'}
    if not u or not title or not matches(title,p) or not price:return {'amazon_status':'unmatched or incomplete','amazon_candidate_title':title[:350]}
    if re.search(r'out of stock|unavailable|currently unavailable|used|renewed|refurbished',stock+' '+condition,re.I):return {'amazon_status':'unavailable or non-new'}
    demand=str(raw.get('demand') or '')[:150];m=re.search(r'([\d,.]+)\s*([KM]?)\+?\s*bought in past month',demand,re.I)
    try:count=int(float(m[1].replace(',',''))*{'K':1000,'M':1000000,'':1}[m[2].upper()]) if m else None
    except (ValueError,OverflowError):count=None
    return {'amazon_status':'price candidate','amazon_price':price,'amazon_asin':u.rsplit('/',1)[-1],'amazon_url':u,'amazon_title':title[:350],'amazon_stock':stock,'amazon_condition':condition,'amazon_demand':demand,'amazon_monthly_lower_bound':count,'amazon_rank':str(raw.get('rank') or '')[:200],'amazon_rating':str(raw.get('rating') or '')[:100],'amazon_reviews':str(raw.get('reviews') or '')[:100],'amazon_price_selector':str(raw.get('price_selector') or '')[:150],'amazon_checked_at':time.time(),'amazon_evidence':'Title/model candidate; verify exact variant, new condition, eligibility and stock; asking price only'}

SNAP=r'''() => {
const txt=s=>{let e=document.querySelector(s);return (e?.innerText||e?.textContent||'').trim().slice(0,500)};
let price='',price_selector='';for(let s of ['#corePrice_feature_div .priceToPay .a-offscreen','#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen','#corePrice_feature_div .a-price .a-offscreen','#priceblock_ourprice']){let e=document.querySelector(s);if(e?.textContent?.trim()){price=e.textContent.trim();price_selector=s;break}}
let detail=txt('#detailBullets_feature_div')+' '+txt('#productDetails_detailBullets_sections1');
return {title:txt('#productTitle')||txt('#title h1')||txt('h1#title'),price,price_selector,availability:txt('#availability span')||txt('#availability'),condition:txt('#buybox .a-condition')||txt('#condition'),demand:txt('#social-proofing-faceout-title-tk_bought')||txt('#social-proofing-faceout-title'),rank:detail.match(/Best Sellers Rank[^\n]{0,180}/i)?.[0]||'',rating:txt('#acrPopover'),reviews:txt('#acrCustomerReviewText'),challenge:!!document.querySelector('#captchacharacters,form[action*="validateCaptcha"]')||/robot check|captcha|access denied/i.test(document.title)};
}'''
CARDS=r'''() => [...document.querySelectorAll('[data-component-type="s-search-result"]')].slice(0,40).map(c=>({title:c.querySelector('h2')?.textContent?.trim()||'',url:(c.querySelector('h2 a, a:has(h2)')||c.querySelector('a[href*="/dp/"]'))?.href||''}))'''

def init(c):
    c.execute('CREATE TABLE IF NOT EXISTS amazon_observations(id INTEGER PRIMARY KEY, identity TEXT, asin TEXT, stamp REAL, data TEXT)')
    c.execute('CREATE INDEX IF NOT EXISTS amazon_identity ON amazon_observations(identity,stamp)')
    c.execute('CREATE TABLE IF NOT EXISTS amazon_restriction(id INTEGER PRIMARY KEY, reason TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS amazon_api_restriction(id INTEGER PRIMARY KEY, reason TEXT)')
def key(p):return json.dumps([ids.query(p).lower(),ids.title_query(p).lower()],ensure_ascii=False)
def cached(db,p):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:
        init(c);r=c.execute('SELECT data FROM amazon_observations WHERE identity=? AND stamp>? ORDER BY stamp DESC LIMIT 1',(key(p),time.time()-max(60,min(86400,int(os.getenv('SCOUT_AMAZON_CACHE_SECONDS','86400')))))).fetchone()
        if not r:
            u=canonical(p.get('retailer_url') or p.get('url'))
            if u:
                r=c.execute('SELECT data FROM amazon_observations WHERE asin=? AND stamp>? ORDER BY stamp DESC LIMIT 1',(u.rsplit('/',1)[-1],time.time()-max(60,min(86400,int(os.getenv('SCOUT_AMAZON_CACHE_SECONDS','86400')))))).fetchone()
    result=json.loads(r[0]) if r else None
    direct=canonical(p.get('retailer_url') or p.get('url'))
    if result and direct and result.get('amazon_asin')!=direct.rsplit('/',1)[-1]:return None
    if result and ebay_sales.valid_upc(str(p.get('upc') or '')) and result.get('amazon_upc')!=str(p['upc']):return None
    return result if result and matches(result.get('amazon_title',''),p) else None

def store(db,p,r):
    if not r.get('amazon_price'):return r
    with closing(sqlite3.connect(db,timeout=30)) as c,c:
        init(c);duplicate=c.execute('SELECT data FROM amazon_observations WHERE identity=? AND asin=? AND stamp=?',(key(p),r['amazon_asin'],r['amazon_checked_at'])).fetchone()
        if duplicate and json.loads(duplicate[0]).get('amazon_price')==r['amazon_price']:return r
        prev=c.execute('SELECT data FROM amazon_observations WHERE asin=? ORDER BY stamp DESC LIMIT 1',(r['amazon_asin'],)).fetchone()
        if prev:
            old=json.loads(prev[0]).get('amazon_price');r['amazon_price_change_pct']=round(100*(r['amazon_price']/old-1),2) if old else None
        c.execute('INSERT INTO amazon_observations(identity,asin,stamp,data) VALUES(?,?,?,?)',(key(p),r['amazon_asin'],r['amazon_checked_at'],json.dumps(r)))
    return r

def blocked(db):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:init(c);r=c.execute('SELECT reason FROM amazon_restriction WHERE id=1').fetchone();return r[0] if r else None

def api_blocked(db):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:init(c);r=c.execute('SELECT reason FROM amazon_api_restriction WHERE id=1').fetchone();return r[0] if r else None

def suspend_api(db,reason):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:init(c);c.execute('INSERT OR REPLACE INTO amazon_api_restriction VALUES(1,?)',(reason,))

def suspend(db,reason):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:init(c);c.execute('INSERT OR REPLACE INTO amazon_restriction VALUES(1,?)',(reason,))

class NavigationStop(PermissionError):
    def __init__(self, reason, detail):
        super().__init__(reason);self.detail=detail

def classify(status,url,challenge=False):
    if status==403:return 'HTTP 403 forbidden'
    if status==401:return 'HTTP 401 authentication required'
    if status==429:return 'HTTP 429 rate limited; review Retry-After'
    if status==503:return 'HTTP 503 service unavailable; review before resuming'
    if challenge:return 'CAPTCHA or access challenge'
    if '/ap/signin' in url:return 'Sign-in required'
    if urlparse(url).hostname not in HOSTS:return 'Unexpected destination'
    return None

def safe_location(url):
    u=urlparse(url or '');c=canonical(url);return (u.hostname or '')+(' '+urlparse(c).path if c else ' '+u.path if u.path in ('/s','/ap/signin','/errors/validateCaptcha') else '')

def navigate(page,url,trace=None):
    if not providers.network_allowed(url):raise RuntimeError('DNS or unsafe URL')
    event={'requested':safe_location(url)}
    if trace is not None:trace.append(event)
    try:r=page.goto(url,wait_until='domcontentloaded',timeout=25000)
    except Exception as e:
        event.update(error=type(e).__name__,destination=safe_location(page.url));raise
    if not r:raise RuntimeError('No response')
    event.update(http_status=r.status,destination=safe_location(page.url))
    reason=classify(r.status,page.url)
    if not reason and r.status<400:reason=classify(r.status,page.url,page.evaluate(SNAP).get('challenge'))
    if reason:
        event['stop_reason']=reason
        event['retry_after_seconds']=providers.retry_after(r.headers.get('retry-after'))
        raise NavigationStop(reason,event)
    if r.status>=400:raise RuntimeError('HTTP '+str(r.status))
    return r.status

def research(p,db):
    q=ids.query(p)
    if not q:return {'amazon_status':'no usable query'}
    r=cached(db,p)
    if r:return dict(r,amazon_cached=True)
    if spapi.enabled():
        if api_blocked(db):return {'amazon_status':'SP-API suspended — manual review required','amazon_stop_reason':api_blocked(db),'amazon_network_attempted':False}
        r=spapi.research(p)
        if r.get('amazon_status') in ('SP-API HTTP 401','SP-API HTTP 403'):suspend_api(db,r['amazon_status'])
        return store(db,p,r)
    if blocked(db):
        activity.emit('Amazon research deferred',engine='amazon',product=p.get('name'),message='Existing suspension; no network request')
        return {'amazon_status':'suspended — manual review required','amazon_stop_reason':blocked(db),'amazon_network_attempted':False}
    if os.getenv('SCOUT_AMAZON_AUTHORIZED')!='1':return {'amazon_status':'automated access not enabled; manual import available'}
    from playwright.sync_api import sync_playwright
    with LOCK:
        if blocked(db):return {'amazon_status':'suspended — manual review required','amazon_stop_reason':blocked(db),'amazon_network_attempted':False}
        r=cached(db,p)
        if r:return dict(r,amazon_cached=True)
        trace=[];start=time.monotonic();name=p.get('name','');activity.emit('Amazon search started',engine='amazon',product=name,message=q)
        try:
            providers.GATE.check('Amazon research',5)
            with sync_playwright() as pw:
                engine=os.getenv('SCOUT_AMAZON_ENGINE','chrome');kw={'headless':os.getenv('SCOUT_AMAZON_VISIBLE','1')!='1','chromium_sandbox':True}
                if engine in ('chrome','msedge'):kw['channel']=engine
                browser=pw.chromium.launch(**kw)
                try:
                    ctx=browser.new_context(accept_downloads=False,service_workers='block');page=ctx.new_page();providers.guard(page)
                    u=canonical(p.get('retailer_url') or p.get('url'))
                    if not u:
                        navigate(page,'https://www.amazon.com/s?'+urlencode({'k':q}),trace)
                        page.wait_for_selector('[data-component-type="s-search-result"]',timeout=10000)
                        cards=page.evaluate(CARDS);cs=candidates(cards,p)
                        if len(cs)!=1:
                            activity.emit('Amazon candidate selection',engine='amazon',product=name,message=f'{len(cards)} raw cards; {len(cs)} matches');providers.GATE.good('Amazon research');return {'amazon_status':'ambiguous or no exact candidate','amazon_candidates':cs[:10],'amazon_navigation':trace,'amazon_raw_card_count':len(cards)}
                        u=cs[0]['url']
                    navigate(page,u,trace);page.wait_for_selector('#productTitle, #title h1, h1#title',timeout=12000)
                    try:page.wait_for_selector('#corePrice_feature_div .a-offscreen, #corePriceDisplay_desktop_feature_div .a-offscreen, #priceblock_ourprice',state='attached',timeout=8000)
                    except Exception:pass
                    raw=page.evaluate(SNAP);r=evaluate(raw,p,page.url);r['amazon_navigation']=trace;r['amazon_extraction']={k:raw.get(k) for k in ('title','price','price_selector','availability','condition','demand','challenge')}
                    if r.get('amazon_status')=='restricted':raise NavigationStop('CAPTCHA or access challenge',{'destination':safe_location(page.url)})
                finally:browser.close()
            providers.GATE.good('Amazon research');r['amazon_origin']='live_browser';r['amazon_duration_seconds']=round(time.monotonic()-start,2);activity.emit('Amazon price result',engine='amazon',product=name,message=str(r.get('amazon_price') or r.get('amazon_status')));return store(db,p,r)
        except PermissionError as e:
            activity.emit('Amazon navigation stopped',engine='amazon',product=name,message=json.dumps(trace));suspend(db,str(e));providers.GATE.fail('Amazon research',str(e),max(3600,getattr(e,'detail',{}).get('retry_after_seconds',0)));return {'amazon_status':'suspended — manual review required','amazon_stop_reason':str(e),'amazon_navigation':trace}
        except providers.Deferred:return {'amazon_status':'cooldown'}
        except Exception as e:
            activity.emit('Amazon navigation failed',engine='amazon',product=name,message=json.dumps(trace));providers.GATE.fail('Amazon research',type(e).__name__,30);return {'amazon_status':'error: '+type(e).__name__,'amazon_navigation':trace}

def history(db):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:init(c);return [json.loads(x[0]) for x in c.execute('SELECT data FROM amazon_observations ORDER BY stamp DESC LIMIT 100')]
