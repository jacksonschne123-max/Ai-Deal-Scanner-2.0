"""On-demand discovery. Source directory is not a live auction inventory."""
import re,time,math,json,os
from collections import deque
from urllib.parse import urlparse
from datetime import datetime,timezone
from intelligence import SOURCES,JsonLD,walk,max_bid
from providers import public_url,allowed,browser_page,ProviderError
CENTER=(35.9606,-83.9207)
# Source addresses are intentionally not used as lot pickup locations.
def directory(custom=()):
    return [dict(name=n,url=u,category=k,region='Knoxville area' if n not in ('HiBid','GovDeals') else 'National; local location must be verified') for n,u,k in SOURCES]+[x for x in custom if x.get('category') in ('auction','surplus','estate','warehouse','discount') and public_url(x.get('url'))]

def distance(lat,lon,center=CENTER):
    a,b=map(math.radians,center);c,d=map(math.radians,(float(lat),float(lon)));v=math.sin((c-a)/2)**2+math.cos(a)*math.cos(c)*math.sin((d-b)/2)**2
    return 3958.76*2*math.asin(min(1,math.sqrt(v)))

def nearby(item,radius):
    try:
        lat=float(item['lat']);lon=float(item['lon'])
        if not -90<=lat<=90 or not -180<=lon<=180:return None
        return round(distance(lat,lon),1)
    except (ValueError,TypeError,KeyError):return None

def unsuitable(url,title=''):
    path=urlparse(url).path.lower()
    return bool(re.search(r'/auctions/past(?:/|\s|$)|\b(?:real[- ]estate|ammunition|firearms?|ammo|vehicle[- ]sale|classic[- ]car|waukomis|wilmington[- ]nc|tampa)\b',path+' '+title,re.I))

def discover_links(page,source):
    host=urlparse(source['url']).hostname; seen=set();out=[]
    for l in page.get('links',[]):
        url=l.get('url','');title=l.get('title','')
        if not public_url(url) or not title or url in seen or unsuitable(url,title):continue
        h=urlparse(url).hostname or ''
        if not (h==host or h.endswith('.'+host) or host and host.endswith('.'+h) or h.endswith('.hibid.com') or h in ('hibid.com','www.govdeals.com','govdeals.com')):continue
        if not re.search(r'/(?:lot|catalog|auctions?|events?|listings?|assets?|products?)/',urlparse(url).path,re.I) and not re.search(r'(?:[?&](?:page|pagenumber)=|next page)',url+' '+title,re.I):continue
        seen.add(url);out.append(dict(name=title,url=url,source=source['name'],category=source['category'],stock='Unverified',kind='lot' if re.search(r'/(?:lot|asset|product)/',urlparse(url).path,re.I) else 'catalog',discovered_at=time.time()))
    return out

def parse_lot(page,source):
    """Read structured product facts only. Asking price is not automatically a bid."""
    parser=JsonLD();parser.feed(page.get('html',''));out=[]
    for v in walk(parser.items):
        types=v.get('@type',[]);types=[types] if isinstance(types,str) else types or []
        if 'Product' not in types:continue
        item={'name':v.get('name') or page.get('title'),'url':page['url'],'source':source['name'],'category':source['category'],'stock':'Unverified','brand':v.get('brand',{}).get('name') if isinstance(v.get('brand'),dict) else v.get('brand'),'model':v.get('mpn') or v.get('model'),'upc':v.get('gtin12') or v.get('gtin13') or v.get('gtin14'),'condition':str(v.get('itemCondition','unknown')),'kind':'lot','discovered_at':time.time()}
        # Only dedicated bid fields or explicitly labeled rendered bid are used.
        text=page.get('text','');b=re.search(r'\b(?:current|high|winning) bid\s*[:\n ]+(?:USD\s*)?\$\s*([\d,]+(?:\.\d{1,2})?)',text,re.I)
        if b:item['cost']=float(b[1].replace(',',''));item['price_type']='current bid (not final)'
        item.update(lot_terms(page))
        out.append(item)
    if not out and page.get('title') and re.search(r'/(?:lot|asset|product)/',page.get('url',''),re.I):
        text=page.get('text','');bid=re.search(r'\b(?:current|high|winning) bid\s*[:\n ]+(?:USD\s*)?\$\s*([\d,]+(?:\.\d{1,2})?)',text,re.I)
        if bid:out.append(dict(name=page['title'],url=page['url'],source=source['name'],category=source['category'],kind='lot',stock='Unverified',cost=float(bid[1].replace(',','')),price_type='current bid (not final)',**lot_terms(page)))
    return out

def assess(item,settings):
    p=dict(item);p['distance_miles']=nearby(p,settings['radius']);p['radius_status']='Unknown pickup location' if p['distance_miles'] is None else 'Within radius' if p['distance_miles']<=settings['radius'] else 'Outside radius'
    if p.get('resale') is not None and p.get('median') is not None and (p.get('sample') or 0)>=3:
        p['max_bid']=max_bid(float(p.get('p25') or p['median']),shipping=settings['shipping'],profit=settings['profit'],premium=p['buyer_premium'] if isinstance(p.get('buyer_premium'),(int,float)) and 0<=p['buyer_premium']<=1 else settings['premium'],tax=settings['tax'],travel=settings['travel'],risk=settings['risk'])
        p['bid_assumptions']={k:settings[k] for k in ('shipping','profit','premium','tax','travel','risk')}
    p['assessment']='Research lead — verify live bid, condition, pickup and terms'
    if isinstance(p.get('close_at'),(int,float)) and p['close_at']<time.time():p['assessment']='Rejected — auction ended'
    if p.get('max_bid') is not None and p.get('cost') is not None and p['cost']>p['max_bid']:p['assessment']='Rejected — bid exceeds target'
    if p.get('kind')=='directory':p['assessment']='Directory entry — not a verified auction'
    return p

def run(settings,custom,emit,progress,cancel,price,wait_priority,feed=None,page_loader=None):
    """Round-robin source traversal; only actual inspected lots count as results."""
    page_loader=page_loader or browser_page
    sources=[s for s in directory(custom) if s['category'] in settings['categories']]
    seen=set();visited=set();budget=settings['max_pages'];count=0
    queue=deque((s,s['url'],'source',None) for s in sources)
    def save(p):
        nonlocal count
        if p.get('url') in seen:return
        seen.add(p.get('url'));p=assess(p,settings)
        if p['radius_status']!='Outside radius' and not (p.get('close_at') and p['close_at']<time.time()):emit(p);count+=1
    def source_note(source,message):
        progress(source['name']+' · '+message,count)
        emit(dict(name=source['name'],source=source['name'],url=source['url'],category=source['category'],kind='directory',stock='Source status',note=message,assessment='Source status — not a product'))
    while queue and not cancel():
        source,url,kind,lead=queue.popleft()
        if url in visited or unsuitable(url, (lead or {}).get('name','')):continue
        visited.add(url)
        if kind=='source' and feed and source.get('feed_url'):
            try:
                for p in feed(source['feed_url']).get('lots',[]):
                    if cancel():break
                    if isinstance(p,dict) and p.get('name') and public_url(p.get('url')):
                        p=dict(p,source=source['name'],category=source['category'],kind='lot')
                        if nearby(p,settings['radius']) is not None and nearby(p,settings['radius'])>settings['radius']:continue
                        if settings['depth']=='deep' and wait_priority():p.update(price(p))
                        save(p)
            except Exception as e:source_note(source,'Feed '+type(e).__name__)
        if budget<=0:
            source_note(source,'Page budget exhausted; remaining links not inspected');break
        if not allowed(url):source_note(source,'Unsafe or unsupported URL');continue
        if not wait_priority():break
        progress(source['name']+' · '+kind,count);budget-=1
        try:
            page=page_loader(url)
            terms=lot_terms(page)
            if terms.get('close_at') and terms['close_at']<time.time():source_note(source,'Expired catalog or lot skipped');continue
            if kind=='lot':
                lots=parse_lot(page,source)
                if not lots:source_note(source,'Lot parser found no product evidence');continue
                for p in lots:
                    if nearby(p,settings['radius']) is not None and nearby(p,settings['radius'])>settings['radius']:continue
                    if settings['depth']=='deep' and wait_priority():
                        try:p.update(price(p))
                        except Exception as e:p['note']='Resale research '+type(e).__name__
                    p['page_checked_at']=page.get('checked_at',time.time());save(p)
                continue
            links=discover_links(page,source)
            source_note(source,f'{len(links)} catalog/lot links detected; {budget} pages remaining')
            queue.extend((source,p['url'],p['kind'],p) for p in links[:500] if p['url'] not in visited)
        except Exception as e:source_note(source,'Inspection failed: '+str(e)[:150] if isinstance(e,ProviderError) else 'Inspection failed: '+type(e).__name__)
        if queue and not cancel():time.sleep(3)
    progress('Finished · '+str(count)+' inspected product lots',count)
    return count

def lot_terms(page):
    """Extract clearly labeled terms and structured location. No guessed pickup location."""
    text=page.get('text','');out={'pickup_address':None,'close_at':None,'buyer_premium':None,'terms_checked_at':time.time()}
    m=re.search(r"(?:buyer['’]s? premium|buyers premium)\s*[:\n ]+(\d+(?:\.\d+)?)\s*%",text,re.I)
    if m and 0<=float(m[1])<=100:out['buyer_premium']=float(m[1])/100
    m=re.search(r'pickup address\s*[:\n ]+([^\n]{8,200})',text,re.I)
    if m:out['pickup_address']=m[1].strip()
    parser=JsonLD();parser.feed(page.get('html',''))
    for obj in walk(parser.items):
        typ=obj.get('@type');types=[typ] if isinstance(typ,str) else typ or []
        if 'Event' not in types and 'AuctionEvent' not in types:continue
        stamp=obj.get('endDate')
        if isinstance(stamp,str):
            try:
                d=datetime.fromisoformat(stamp.replace('Z','+00:00'))
                if d.tzinfo:out['close_at']=d.timestamp()
            except ValueError:pass
        # Event location is not assumed to be pickup location. Only explicit pickup data from feed.
    return out
