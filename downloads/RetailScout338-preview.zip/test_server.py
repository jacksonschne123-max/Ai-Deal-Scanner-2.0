import os,tempfile,unittest,time
from unittest.mock import patch
from fastapi.testclient import TestClient
import server as s
UPC='123456789012'

def sold(i,price=20,age=1,**kw):
    return dict(price=price,exact_match=True,sold=True,currency='USD',condition='New',date=time.time()-age*86400,url='https://www.ebay.com/itm/'+str(i),title='Widget '+UPC,**kw)
class Tests(unittest.TestCase):
 def setUp(self):
    self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.env=patch.dict(os.environ,{'SCOUT_RSS':'0','SCOUT_EBAY_BROWSER':'0','SCOUT_GROUNDING':'0','SCOUT_SOLD_URL':'','SCOUT_AMAZON_URL':'','SCOUT_AMAZON_BROWSER':'0','SCOUT_CASHBACK':'0','SCOUT_TAX':'0.0925','BESTBUY_API_KEY':''});self.env.start();self.addCleanup(self.env.stop);self.db=patch.object(s,'DB',self.tmp.name+'/test.db');self.db.start();self.addCleanup(self.db.stop);s.init()
 def test_profit(self):
    self.assertEqual(s.economics(10,30)['profit'],9.5);self.assertEqual(s.economics(10,5)['color'],'yellow');self.assertEqual(s.economics(None,30)['color'],'red')
 def test_costs(self):
    r=s.economics(20,80,fee=.15,shipping=10,tax=.1,premium=.15,travel=2,risk=3,cashback=.02,coupon=5);self.assertAlmostEqual(r['profit'],80*.85-10-(15*1.15*1.1*.98+5),2);self.assertRaises(ValueError,s.economics,10,20,fee=1)
 def test_priority(self):
    with patch.dict(os.environ,{'SCOUT_SOLD_URL':'https://sold.example'}),patch.object(s,'fetch_json',return_value={'sales':[sold(i,p) for i,p in enumerate((20,30,100),1)],'complete_30d':True,'active_low':35,'active_exact_match':True}) as f:
        r=s.pricing({'upc':UPC});self.assertEqual(r['resale'],30);self.assertEqual(r['median'],30);self.assertEqual(r['p25'],25);self.assertEqual(r['sample'],3);self.assertEqual(f.call_count,1)
 def test_fallback(self):
    with patch.dict(os.environ,{'SCOUT_SOLD_URL':'https://sold.example','SCOUT_AMAZON_URL':'https://amazon.example'}),patch.object(s,'fetch_json',side_effect=[{'sales':[]},{'price':12,'exact_match':True,'currency':'USD','condition':'new'}]):
        r=s.pricing({'upc':UPC});self.assertIsNone(r['resale']);self.assertEqual(r['amazon_price'],12)
 def test_api(self):
    with patch.object(s,'TOKEN','secret'):
        c=TestClient(s.app);h={'x-scout-token':'secret'};self.assertEqual(c.get('/api/status').status_code,401);self.assertEqual(c.get('/api/status',headers=h).status_code,200);self.assertEqual(c.post('/api/scan',headers=h,json={'image':'bad'}).status_code,400);self.assertEqual(c.post('/api/scan',headers=h,json={'image':'data:image/jpeg;base64,YQ=='}).status_code,200);self.assertEqual(c.get('/api/jobs',headers=h).json()[0]['status'],'queued');self.assertEqual(c.post('/api/records/correction',headers=h,json={'upc':'123','name':'Wrong'}).status_code,400);self.assertEqual(c.post('/api/records/correction',headers=h,json={'upc':UPC,'name':'Verified','verified':True}).status_code,200)
        with patch.object(s,'pricing',return_value={'resale':None,'source':'Unavailable'}):self.assertEqual(s.process({'upc':UPC,'name':'Wrong'})['name'],'Verified')
if __name__=='__main__':unittest.main()
