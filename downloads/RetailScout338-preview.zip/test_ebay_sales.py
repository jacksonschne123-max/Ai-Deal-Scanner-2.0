import unittest,time,tempfile,os
from unittest.mock import patch
from datetime import datetime,timezone
import ebay_sales as e
class Ebay(unittest.TestCase):
 def card(self,i=1): return dict(title='Widget 123456789012',price='$50.00',date='Sold '+datetime.now(timezone.utc).strftime('%b %d, %Y'),condition='New',link='https://www.ebay.com/itm/'+str(i))
 def test_exact(self): self.assertEqual(len(e.parse_cards([self.card(),self.card(),dict(self.card(2),condition='Used'),dict(self.card(3),title='Other')],'123456789012')),1)
 def test_median(self): self.assertEqual(e.summarize(e.parse_cards([self.card(i) for i in range(1,4)],'123456789012'))['resale'],50)
 def test_sparse(self): self.assertIsNone(e.summarize([])['resale'])
 def test_cache(self):
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',-100),patch.object(e,'browse',return_value=[self.card(i) for i in range(1,4)]) as b:
   db=t+'/db';p={'upc':'123456789012'};self.assertEqual(e.lookup(p,db)['resale'],50);self.assertEqual(e.lookup(p,db)['resale'],50);self.assertEqual(b.call_count,1)
 def test_block(self):
  with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',-100),patch.object(e,'browse',side_effect=PermissionError('blocked')) as b:
   self.assertIsNone(e.lookup({'upc':'123456789012'},t+'/db'));self.assertIsNone(e.lookup({'upc':'123456789029'},t+'/db'));self.assertEqual(b.call_count,1)
