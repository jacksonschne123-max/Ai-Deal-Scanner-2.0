"""Optional US Selling Partner API adapter. Requires separate Amazon approval.
No browser fallback, no purchases, no seller identifiers or credentials in logs.
"""
import os,time,threading,re,math
import requests
import providers
MARKET='ATVPDKIKX0DER';BASE='https://sellingpartnerapi-na.amazon.com';LOCK=threading.Lock();TOKEN=None;UNTIL=0
KEYS=('SCOUT_SPAPI_CLIENT_ID','SCOUT_SPAPI_CLIENT_SECRET','SCOUT_SPAPI_REFRESH_TOKEN')
def enabled():return os.getenv('SCOUT_SPAPI_AUTHORIZED')=='1' and all(os.getenv(k) for k in KEYS)
def call(method,url,stage,**kw):
    providers.GATE.check(stage,2.1)
    try:r=requests.request(method,url,timeout=(8,25),allow_redirects=False,**kw)
    except requests.RequestException as e:
        providers.GATE.fail(stage,type(e).__name__,60);raise providers.Deferred('SP-API transport error') from None
    if r.status_code!=200:
        providers.GATE.fail(stage,'HTTP '+str(r.status_code),max(3600 if r.status_code in (401,403) else 60,providers.retry_after(r.headers.get('Retry-After'))));raise providers.Deferred('SP-API HTTP '+str(r.status_code))
    try:data=r.json()
    except ValueError:
        providers.GATE.fail(stage,'Invalid JSON',60);raise providers.Deferred('SP-API invalid JSON') from None
    providers.GATE.good(stage);return data

def token():
    global TOKEN,UNTIL
    if TOKEN and time.time()<UNTIL:return TOKEN
    d=call('POST','https://api.amazon.com/auth/o2/token','SP-API authorization',data={'grant_type':'refresh_token','client_id':os.environ[KEYS[0]],'client_secret':os.environ[KEYS[1]],'refresh_token':os.environ[KEYS[2]]})
    TOKEN=d['access_token'];UNTIL=time.time()+max(0,min(3600,int(d.get('expires_in',3600)))-120);return TOKEN

def get(path,params,stage):return call('GET',BASE+path,stage,params=params,headers={'x-amz-access-token':token(),'User-Agent':'RetailScout/3.3.8 (Language=Python)'})
def title(item):
    return next((str(s.get('itemName') or '') for s in item.get('summaries',[]) if s.get('marketplaceId')==MARKET),'')
def select(items,p,known=''):
    import amazon_research as ar,ebay_sales
    found={}
    for item in items:
        asin=str(item.get('asin',''));t=title(item)
        if not re.fullmatch('[A-Z0-9]{10}',asin) or known and asin!=known or not ar.matches(t,p):continue
        upc=str(p.get('upc') or '')
        if ebay_sales.valid_upc(upc):
            ids=[str(x.get('identifier')) for group in item.get('identifiers',[]) if group.get('marketplaceId')==MARKET for x in group.get('identifiers',[])]
            if upc not in ids:continue
        found[asin]=t
    return next(iter(found.items())) if len(found)==1 else None

def offer_price(response,asin):
    d=response.get('payload',{});identity=d.get('Identifier',{})
    if d.get('status')!='Success' or d.get('ASIN')!=asin or identity.get('MarketplaceId')!=MARKET or str(identity.get('ItemCondition','')).lower()!='new':return None
    prices=[]
    for offer in d.get('Offers',[]):
        if str(offer.get('SubCondition','')).lower()!='new':continue
        listing=offer.get('ListingPrice',{});shipping=offer.get('Shipping',{})
        try:
            if listing.get('CurrencyCode')!='USD' or shipping.get('CurrencyCode')!='USD':continue
            a,b=float(listing['Amount']),float(shipping['Amount'])
            if math.isfinite(a+b) and 0<a<1e7 and b==0:prices.append(a)
        except (ValueError,TypeError,KeyError):continue
    return min(prices) if prices else None

def research(p):
    import amazon_research as ar,identity_research as ids,ebay_sales
    if not enabled():return {'amazon_status':'SP-API not configured'}
    with LOCK:
        try:
            u=ar.canonical(p.get('retailer_url') or p.get('url'));known=u.rsplit('/',1)[-1] if u else ''
            params={'marketplaceIds':MARKET,'includedData':'summaries,identifiers'}
            if known:items=[get('/catalog/2022-04-01/items/'+known,params,'SP-API catalog')]
            else:
                upc=str(p.get('upc') or '')
                if ebay_sales.valid_upc(upc) and len(upc) in (12,13):params.update(identifiers=upc,identifiersType='UPC' if len(upc)==12 else 'EAN')
                else:params['keywords']=ids.query(p)
                if not (params.get('keywords') or params.get('identifiers')):return {'amazon_status':'SP-API no query'}
                d=get('/catalog/2022-04-01/items',params,'SP-API catalog');items=d.get('items',[])
                if d.get('pagination',{}).get('nextToken'):return {'amazon_status':'SP-API ambiguous catalog results'}
            chosen=select(items,p,known)
            if not chosen:return {'amazon_status':'SP-API no unique matching item'}
            asin,t=chosen;d=get('/products/pricing/v0/items/'+asin+'/offers',{'MarketplaceId':MARKET,'ItemCondition':'New','CustomerType':'Consumer'},'SP-API offers');price=offer_price(d,asin)
            if price is None:return {'amazon_status':'SP-API no eligible new USD offer with free shipping'}
            r=ar.evaluate({'title':t,'price':f'${price:.2f}','condition':'New'},p,'https://www.amazon.com/dp/'+asin)
            if r.get('amazon_price') and ebay_sales.valid_upc(str(p.get('upc') or '')):r['amazon_upc']=str(p['upc'])
            r.update(amazon_origin='authorized_spapi',amazon_evidence='SP-API new consumer offer; free shipping; asking price only; verify variant, eligibility and stock')
            return r
        except providers.Deferred as e:return {'amazon_status':str(e)}
        except (ValueError,TypeError,KeyError,AttributeError) as e:return {'amazon_status':'SP-API invalid response: '+type(e).__name__}
