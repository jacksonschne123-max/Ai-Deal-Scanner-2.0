"""Import user-reviewed offline price candidates, preserving observation timestamps."""
import argparse,json,time,math,sqlite3
from pathlib import Path
import amazon_research as ar

def import_report(db,report):
    if report.get('mode')!='offline replay; zero Amazon requests':raise ValueError('Expected offline replay report')
    rows=report.get('results');out=[]
    if not isinstance(rows,list) or len(rows)>100:raise ValueError('Invalid report size')
    for row in rows:
        try:
            p={'name':row['requested']};raw=row['extraction'];original=row['result'];stamp=float(original['amazon_checked_at'])
            if not math.isfinite(stamp) or not 0<stamp<=time.time()+60:raise ValueError('Invalid timestamp')
            r=ar.evaluate(raw,p,row['url'])
            if not r.get('amazon_price') or r['amazon_price']!=original.get('amazon_price') or r['amazon_asin']!=original.get('amazon_asin'):raise ValueError('Evidence mismatch')
            r.update(amazon_checked_at=min(stamp,time.time()),amazon_origin='offline_import',amazon_evidence='User-provided saved page; capture time not independently verified; asking price only')
            ar.store(db,p,r);out.append({'name':p['name'],'status':'imported','price':r['amazon_price'],'asin':r['amazon_asin']})
        except (KeyError,TypeError,ValueError,AttributeError) as e:out.append({'status':'rejected','reason':type(e).__name__})
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path,required=True);p.add_argument('--db',default='scout.db');p.add_argument('--output',type=Path,default=Path('amazon-338-import-results.json'));a=p.parse_args()
    if not Path(a.db).is_file():raise SystemExit('Existing database not found')
    if a.input.stat().st_size>2_000_000:raise SystemExit('Report too large')
    report=json.loads(a.input.read_text(encoding='utf-8-sig'));items=import_report(a.db,report)
    # Check stored evidence, never invoke live lookup when the cache is unavailable.
    for row in items:
        if row['status']=='imported':
            c=ar.cached(a.db,{'name':row['name']});row['cache_price']=c.get('amazon_price') if c else None
    output={'mode':'offline import; zero Amazon requests','results':items,'browser_suspension':ar.blocked(a.db),'api_suspension':ar.api_blocked(a.db),'imported_count':sum(x['status']=='imported' for x in items),'cache_count':sum(x.get('cache_price') is not None for x in items)}
    a.output.write_text(json.dumps(output,indent=2),encoding='utf-8');print(json.dumps(output,indent=2));print('REPORT:',a.output.resolve())
if __name__=='__main__':main()
