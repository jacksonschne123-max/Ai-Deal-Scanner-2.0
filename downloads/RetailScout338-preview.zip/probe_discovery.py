"""Live, read-only source check. No Gemini, eBay, credentials or database writes."""
import sys
import activity,dealwatch,providers
activity.HOOK=None
ok=0;total=0
for url in dealwatch.FEEDS:
    name=dealwatch.source_name(url)
    try:
        items=dealwatch.rss(url);total+=len(items);ok+=1
        print(f'{name}: {len(items)} fresh candidate products',flush=True)
        for item in items[:3]:print('  '+item['name']+f" | ${item['cost']:.2f}",flush=True)
    except providers.ProviderError as exc:print(f'{name}: {exc}',flush=True)
    except Exception as exc:print(f'{name}: {type(exc).__name__}',flush=True)
print(f'Live discovery: {ok}/{len(dealwatch.FEEDS)} feeds responded; {total} candidate products. No resale or stock verification performed.',flush=True)
sys.exit(0 if total else 1)
