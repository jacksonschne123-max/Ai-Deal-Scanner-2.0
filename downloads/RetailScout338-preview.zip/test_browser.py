"""Real Chromium with intercepted synthetic pages, never public provider traffic."""
import os,sys,time,unittest,tempfile,subprocess,socket,json
from datetime import datetime,timezone,timedelta
from pathlib import Path
from unittest.mock import patch,Mock
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright
import ebay_sales as e
from test_33 import product_html
from test_server import UPC

def chromium(p):
    path=os.getenv('SCOUT_TEST_CHROMIUM')
    if not path and not Path(p.chromium.executable_path).exists() and Path('/usr/bin/chromium').exists():path='/usr/bin/chromium'
    if path:return p.chromium.launch(headless=True,executable_path=path)
    return p.chromium.launch(headless=True)

def item(n,price=50,age=1,condition='New',sold=True):
    date=(datetime.now(timezone.utc)-timedelta(days=age)).strftime('%b %d, %Y')
    return f'<li class="s-item"><a href="https://www.ebay.com/itm/{n}"><span class="s-item__title">Acme ABC123 {UPC}</span></a><span class="s-item__price">${price:.2f}</span><span class="SECONDARY_INFO">{condition}</span><span class="s-item__title--tag">{"Sold "+date if sold else ""}</span></li>'
class FixturePage:
    """Render real DOM without network navigation in a restricted test environment."""
    def __init__(self,page,load):self.page=page;self.load=load;self.url=''
    def goto(self,url,**kw):
        self.url=url;status,body=self.load(url);self.page.set_content(body);return Mock(status=status)
    def __getattr__(self,key):return getattr(self.page,key)

class BrowserFixtures(unittest.TestCase):
 def setUp(self):
    self.p=sync_playwright().start();self.addCleanup(self.p.stop);self.b=chromium(self.p);self.addCleanup(self.b.close);self.page=self.b.new_page()
 def test_pagination_and_active(self):
    calls=[]
    def route(url):
        q=parse_qs(urlparse(url).query);calls.append(q)
        if 'LH_Sold' not in q:html=item(99,42,sold=False)+item(100,10,condition='Used',sold=False)
        elif q.get('_pgn')==['2']:html=item(2,60)+item(3,70)+'<a class="pagination__next" href="/sch/i.html?LH_Sold=1&_pgn=3">Next</a>'
        elif q.get('_pgn')==['3']:html=item(4,90,age=40)+'<button class="pagination__next" disabled>Next</button>'
        else:html=item(1,50)+'<a class="pagination__next" href="/sch/i.html?LH_Sold=1&_pgn=2">Next</a>'
        return 200,'<html><title>Fixture</title><body>'+html+'</body></html>'
    cards,complete,active=e.crawl(FixturePage(self.page,route),UPC,delay=lambda _:None,max_pages=10);r=e.summarize(e.parse_cards(cards,UPC),complete);self.assertEqual(len(calls),4);self.assertEqual(r['median'],60);self.assertEqual(r['sample'],3);self.assertTrue(complete);self.assertEqual(active,42)
 def test_page_limit_partial(self):
    page=FixturePage(self.page,lambda u:(200,'<html><title>Fixture</title><body>'+item(1)+'<a class="pagination__next" href="/sch/i.html?LH_Sold=1&_pgn=2">Next</a></body></html>'))
    _,complete,_=e.crawl(page,UPC,delay=lambda _:None,max_pages=1);self.assertFalse(complete)
 def test_challenge_stop(self):
    page=FixturePage(self.page,lambda u:(403,'<html><title>Access denied</title><body>Access denied</body></html>'))
    with self.assertRaises(PermissionError):e.crawl(page,UPC,delay=lambda _:None)
 def test_rendered_structured_offer(self):
    import intelligence as i
    self.page.set_content('<html><body><h1>Widget</h1>'+product_html()+'</body></html>');self.assertEqual(i.retail_offer(self.page.content(),{'upc':UPC})['cost'],25)
 def test_ui_desktop_and_phone(self):
    import server as s
    from fastapi.testclient import TestClient
    with tempfile.TemporaryDirectory() as tmp,patch.object(s,'DB',tmp+'/test.db'),patch.object(s,'TOKEN','fixture-token'),patch.dict(os.environ,{'SCOUT_RSS':'0','SCOUT_EBAY_BROWSER':'0','SCOUT_GROUNDING':'0','SCOUT_BROWSER_HOSTS':''}):
        s.init();client=TestClient(s.app);errors=[];self.page.on('pageerror',lambda exc:errors.append(str(exc)))
        def api(path,options):
            res=client.request(options.get('method','GET'),path,headers=options.get('headers',{}),content=options.get('body') or None)
            return {'status':res.status_code,'text':res.text}
        self.page.expose_function('fixtureFetch',api)
        inject="<script>window.fetch=async(path,options)=>{let r=await fixtureFetch(path,options);return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>JSON.parse(r.text),text:async()=>r.text}};</script>"
        html=(Path(__file__).parent/'index.html').read_text(encoding='utf-8').replace('<script>',inject+'<script>',1)
        self.page.set_content(html);self.page.locator('#token').fill('fixture-token');self.page.get_by_role('button',name='Connect',exact=True).click();self.page.wait_for_function("document.querySelector('#status').textContent.includes('Connected')")
        self.page.get_by_role('button',name='DealWatch',exact=True).click();self.page.get_by_text('No results yet.').wait_for();self.page.get_by_text('DealWatch live progress',exact=True).wait_for();self.page.get_by_role('button',name='Pause',exact=True).click();self.page.get_by_text('paused · paused',exact=True).wait_for();self.page.get_by_role('button',name='Resume',exact=True).click();self.page.get_by_text('running · idle',exact=True).wait_for();self.page.get_by_role('button',name='Activity',exact=True).click();self.page.get_by_text('Live activity · newest first',exact=True).wait_for();self.page.set_viewport_size({'width':390,'height':844});self.page.wait_for_selector('#livecontent .metric');self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),391);self.page.get_by_role('button',name='Local Auctions',exact=True).click();self.page.get_by_role('button',name='Source directory',exact=True).click();self.page.get_by_text('ATX Knoxville · Knoxville area').wait_for();self.page.get_by_role('button',name='Find local opportunities',exact=True).click();self.page.get_by_text('Research #1',exact=False).first.wait_for();self.page.set_viewport_size({'width':390,'height':844});self.page.get_by_role('button',name='Browser Debug',exact=True).click();self.page.get_by_text('Browser mode: headless',exact=True).wait_for();self.page.get_by_role('button',name='eBay & Browser Settings',exact=True).click();self.page.get_by_text('eBay completed-sale research',exact=True).wait_for();self.page.get_by_role('button',name='Amazon Research',exact=True).click();self.page.get_by_text('Amazon pricing research',exact=True).wait_for();self.page.get_by_role('button',name='Scanner',exact=True).click();self.page.get_by_text('Manual product research',exact=True).wait_for();self.assertLessEqual(self.page.evaluate('document.documentElement.scrollWidth'),391);self.assertEqual(errors,[])
if __name__=='__main__':unittest.main()
