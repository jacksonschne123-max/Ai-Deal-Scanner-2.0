"""User-entered comparable sales, separate from verified automatic valuations."""
import csv,io,re,math
from datetime import datetime,timezone
from urllib.parse import urlsplit

def parse(text):
    if len(text)>100000:raise ValueError('CSV too large')
    reader=csv.DictReader(io.StringIO(text));required={'title','price','date','url','condition'}
    if not reader.fieldnames or not required.issubset(reader.fieldnames):raise ValueError('CSV headers: title,price,date,url,condition')
    out={}
    for row in reader:
        if len(out)>=500:raise ValueError('Maximum 500 unique sales')
        title=row['title'].strip();price=float(row['price']);date=datetime.strptime(row['date'],'%Y-%m-%d').replace(tzinfo=timezone.utc).timestamp();u=urlsplit(row['url']);m=re.fullmatch(r'/itm/(?:[^/]+/)?(\d+)',u.path)
        if not title or len(title)>500 or not math.isfinite(price) or price<=0 or not 0<=datetime.now(timezone.utc).timestamp()-date<=30*86400 or u.scheme!='https' or u.netloc not in ('www.ebay.com','ebay.com') or not m or row['condition'].strip().lower()!='new':raise ValueError('Each row needs a new item, positive USD price, date within 30 days, and eBay item URL')
        out[m[1]]={'id':m[1],'title':title,'price':price,'date':date,'url':'https://www.ebay.com/itm/'+m[1]}
    if not out:raise ValueError('No sales provided')
    return list(out.values())
