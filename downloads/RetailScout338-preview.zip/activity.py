"""Bounded, credential-scrubbed operational telemetry. No raw HTTP or terminal output."""
import os,re,time,threading,sqlite3,contextlib
LOCAL=threading.local()
HOOK=None

def emit(stage,**fields):
    if HOOK:
        try: HOOK(stage,**fields)
        except Exception: pass # telemetry must never stop research

@contextlib.contextmanager
def scope(engine):
    old=getattr(LOCAL,'engine',None);LOCAL.engine=engine
    try:yield
    finally:LOCAL.engine=old

def scrub(value):
    s=str(value or '')[:20000]
    for k,v in os.environ.items():
        if v and len(v)>=4 and any(x in k.upper() for x in ('KEY','TOKEN','SECRET','PASSWORD')):s=s.replace(v,'[redacted]')
    s=re.sub(r'https?://\S+','[URL omitted]',s)
    s=re.sub(r'(?i)(bearer\s+|(?:api[_-]?key|token|password|secret)\s*[:=]\s*)\S+',r'\1[redacted]',s)
    return s[:200]

class Monitor:
    def __init__(self,db):
        self.db=db;self.lock=threading.RLock();self.mode='running';self.priority='scanner';self.state={};self.reset();self.cpu=None;self.state.update(active=False,stage='idle',finished=time.time())
    @contextlib.contextmanager
    def connect(self):
        with contextlib.closing(sqlite3.connect(self.db(),timeout=5)) as c,c:yield c
    def init(self):
        with self.connect() as c:c.executescript('CREATE TABLE IF NOT EXISTS activity_log(id INTEGER PRIMARY KEY,stamp REAL,engine TEXT,stage TEXT,source TEXT,product TEXT,message TEXT); CREATE TABLE IF NOT EXISTS activity_counts(day TEXT,source TEXT,kind TEXT,n INTEGER,PRIMARY KEY(day,source,kind)); CREATE TABLE IF NOT EXISTS activity_settings(k TEXT PRIMARY KEY,v TEXT);')
        with self.connect() as c:d=dict(c.execute('SELECT k,v FROM activity_settings'))
        self.mode=d.get('mode','running');self.priority=d.get('priority','scanner')
        with self.lock:self.state.update(active=False,stage='idle' if self.mode=='running' else self.mode,finished=time.time())
    def reset(self):
        with self.lock:self.state=dict(started=time.time(),stage='starting',stage_started=time.time(),blockers={},source='',product='',discovered=0,scheduled=0,processed=0,positive=0,rejected=0,unverified=0,errors=0,skipped=0,sources_total=0,sources_done=0,discovery_complete=False,next_cycle=None,active=True)
    def event(self,stage,source='',product='',message='',**fields):
        parent=getattr(LOCAL,'engine',None);engine=fields.get('engine') or parent or 'system';source=scrub(source);product=scrub(product);message=scrub(message);stage=scrub(stage)
        with self.lock:
            if stage=='provider error':self.state['provider_errors']=self.state.get('provider_errors',0)+1
            if engine=='dealwatch' or parent=='dealwatch':
                self.state.update(stage=stage,stage_started=time.time())
                if source:self.state['source']=source
                if stage in ('discovering source','analyzing product','stock watch','scheduled rechecks'):
                    self.state['product']=product;self.state.pop('page',None)
                elif product:self.state['product']=product
                if fields.get('page') is not None:self.state['page']=fields['page']
                source=source or self.state.get('source','');product=product or self.state.get('product','')
            with self.connect() as c:
                c.execute('INSERT INTO activity_log(stamp,engine,stage,source,product,message) VALUES(?,?,?,?,?,?)',(time.time(),engine,stage,source,product,message))
                c.execute('DELETE FROM activity_log WHERE id <= (SELECT max(id)-10000 FROM activity_log)')
    def bump(self,kind,n=1,source=''):
        with self.lock:
            self.state[kind]=self.state.get(kind,0)+n
            if kind in ('discovered','scheduled','processed','positive','rejected','unverified','errors','skipped','source_ok','source_error'):
                with self.connect() as c:c.execute('INSERT INTO activity_counts VALUES(?,?,?,?) ON CONFLICT(day,source,kind) DO UPDATE SET n=n+excluded.n',(time.strftime('%Y-%m-%d'),scrub(source),kind,n))
    def reason(self,reason,source):
        with self.lock:
            b=self.state['blockers'];b[reason]=b.get(reason,0)+1
            with self.connect() as c:c.execute('INSERT INTO activity_counts VALUES(?,?,?,1) ON CONFLICT(day,source,kind) DO UPDATE SET n=n+1',(time.strftime('%Y-%m-%d'),scrub(source),'reason:'+reason))
    def control(self,action):
        with self.lock:
            if action in ('start','resume'):self.mode='running'
            elif action in ('pause','stop'):self.mode={'pause':'paused','stop':'stopped'}[action]
            elif action in ('scanner','balanced'):self.priority=action
            else:raise ValueError('Invalid action')
            with self.connect() as c:c.executemany('INSERT OR REPLACE INTO activity_settings VALUES(?,?)',[('mode',self.mode),('priority',self.priority)])
            if not self.state['active']:self.state['stage']='idle' if self.mode=='running' else self.mode
            self.event('control',message=action)
    def checkpoint(self,stop):
        while not stop.is_set() and self.mode=='paused':
            with self.lock:
                if self.state['stage']!='paused at checkpoint':self.state.update(stage='paused at checkpoint',stage_started=time.time())
            stop.wait(.5)
        return not stop.is_set() and self.mode!='stopped'
    def snapshot(self):
        with self.lock:s=dict(self.state,blockers=dict(self.state['blockers']));mode=self.mode;priority=self.priority
        elapsed=max(0,(time.time() if s['active'] else s.get('finished',time.time()))-s['started']);done=s['processed']+s['skipped']+s['errors'];total=s['scheduled'];rate=s['processed']*60/max(elapsed,1)
        s.update(mode=mode,priority=priority,elapsed=round(elapsed),rate=round(rate,2),percent=round(min(100,100*done/total),1) if total and s['discovery_complete'] else None,eta=round(max(0,total-done)*elapsed/done) if done and s['discovery_complete'] and s['active'] else None,heartbeat=time.time(),stage_seconds=round(max(0,time.time()-s['stage_started'])) if s['active'] else 0)
        if not s['active'] or mode!='running':s['eta']=None
        try:
            import psutil
            p=psutil.Process();children=p.children(recursive=True);now=psutil.cpu_times();total=sum(now)-getattr(now,'guest',0)-getattr(now,'guest_nice',0);idle=now.idle+getattr(now,'iowait',0)
            with self.lock:
                prev=self.cpu;self.cpu=(total,idle);cpu=round(max(0,min(100,100*(1-(idle-prev[1])/(total-prev[0])))),1) if prev and total>prev[0] else None
            s['resources']={'system_cpu_pct':cpu,'system_ram_pct':psutil.virtual_memory().percent,'backend_ram_mb':round(p.memory_info().rss/1048576,1),'child_processes':len(children),'browser_processes':sum(any(x in q.name().lower() for x in ('chrome','chromium','headless')) for q in children)}
        except Exception:s['resources']=None
        return s
    def history(self,limit=100):
        with self.connect() as c:
            c.row_factory=sqlite3.Row;return [dict(x) for x in c.execute('SELECT * FROM activity_log ORDER BY id DESC LIMIT ?',(max(1,min(10000,limit)),))]
    def totals(self):
        with self.connect() as c:
            result={}
            for name,query,args in [('daily','SELECT kind,sum(n) FROM activity_counts WHERE day=? GROUP BY kind',(time.strftime('%Y-%m-%d'),)),('lifetime','SELECT kind,sum(n) FROM activity_counts GROUP BY kind',())]:result[name]=dict(c.execute(query,args))
            sources={}
            for source,kind,n in c.execute('SELECT source,kind,sum(n) FROM activity_counts GROUP BY source,kind'):sources.setdefault(source,{})[kind]=n
            result['sources']=sources;return result
