"""Use the integrated engine on the user's PC; no credentials, no purchases."""
import argparse,json,os,tempfile,time
from pathlib import Path
import amazon_research as ar
PRODUCTS=[{'name':'Bosch GT3000 8 piece','url':'https://www.amazon.com/dp/B001GNC8RS'},{'name':'Hollyland LARK A2','url':'https://www.amazon.com/dp/B0F3D55D5R'},{'name':'Anker Nano Neo 65W','url':'https://www.amazon.com/dp/B0H7BYWCNG'},{'name':'Beatbot AquaSense 2 Ultra'},{'name':'Garmin Striker 4'}]
def main():
    p=argparse.ArgumentParser();p.add_argument('--authorized',action='store_true');p.add_argument('--output',default='amazon-371-results.json');a=p.parse_args()
    if not a.authorized: p.error('Automated navigation requires authorization; otherwise use manual observations in the app.')
    os.environ['SCOUT_AMAZON_AUTHORIZED']='1';os.environ.setdefault('SCOUT_AMAZON_VISIBLE','1');results=[]
    existing=Path(os.getenv('SCOUT_DB',str(Path(__file__).resolve().parent/'scout.db')))
    if existing.exists() and ar.blocked(str(existing)):
        report={'status':'existing suspension preserved','reason':ar.blocked(str(existing)),'network_attempted':False,'results':[]}
        Path(a.output).write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2));return 2
    with tempfile.TemporaryDirectory() as d:
        db=d+'/probe.db'
        for product in PRODUCTS:
            r=ar.research(product,db);r['requested']=product['name'];results.append(r);print(json.dumps(r,ensure_ascii=False,indent=2),flush=True)
            Path(a.output).write_text(json.dumps({'results':results,'price_candidates':sum(bool(x.get('amazon_price')) for x in results),'independently_verified_sales':0},indent=2),encoding='utf-8')
            if ar.blocked(db):
                if existing.exists():ar.suspend(str(existing),ar.blocked(db))
                break
            time.sleep(5)
    print('Report:',Path(a.output).resolve());return 0 if sum(bool(x.get('amazon_price')) for x in results)>=3 else 2
if __name__=='__main__':raise SystemExit(main())
