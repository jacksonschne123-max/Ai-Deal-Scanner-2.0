"""Local-only authorized browser tests. Never exports credentials or cookies."""
import os,sys,sqlite3,json,re,time,argparse
from pathlib import Path
from contextlib import closing
from urllib.parse import urlencode,urlsplit

ENGINES={'chromium':{},'chrome':{'channel':'chrome'},'msedge':{'channel':'msedge'}}
def root():return Path(os.getenv('LOCALAPPDATA',str(Path.home()/'.local/share')))/'RetailScout'
def settings():
    try:
        d=json.loads((root()/'browser-settings.json').read_text());return d['engine'] if d['engine'] in ENGINES else 'chromium'
    except (OSError,ValueError,KeyError,TypeError):return 'chromium'
def set_engine(engine):
    if engine not in ENGINES:raise ValueError('Unknown browser engine')
    root().mkdir(parents=True,exist_ok=True);p=root()/'browser-settings.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps({'engine':engine}));os.replace(tmp,p)
def suspend(db,reason):
    with closing(sqlite3.connect(db,timeout=30)) as c,c:
        c.execute('CREATE TABLE IF NOT EXISTS ebay_control(id INTEGER PRIMARY KEY,reason TEXT)');c.execute('INSERT OR REPLACE INTO ebay_control VALUES(1,?)',(reason,))
def profile(engine=None):
    engine=engine or settings()
    if engine not in ENGINES:raise ValueError('Unknown browser engine')
    return root()/('ebay-profile' if engine=='chromium' else 'ebay-profile-'+engine)
def configured():return (profile()/'Default').is_dir()
def launch(p,engine=None,headless=False):
    engine=engine or settings();return p.chromium.launch_persistent_context(str(profile(engine)),headless=headless,accept_downloads=False,**ENGINES[engine])
def url_for(sold=False):
    q={'_nkw':'Garmin Striker 4'}
    if sold:q.update(LH_Sold=1,LH_Complete=1)
    return 'https://www.ebay.com/sch/i.html?'+urlencode(q)
def classify(url,status,title='',body=''):
    u=urlsplit(url);s=title+' '+body[:4000]
    if status in (401,403,429) or re.search(r'captcha|verify you are human|access denied|pardon our interruption|security measure|this browser or app may not be secure',s,re.I):return 'restricted'
    if u.hostname=='signin.ebay.com' or u.hostname=='accounts.google.com':return 'authentication_error' if re.search(r'something went wrong|error page',s,re.I) else 'authentication_required'
    if status is not None and status>=400:return 'http_error'
    if u.hostname!='www.ebay.com' or not u.path.startswith('/sch/'):return 'unexpected_page'
    return 'search_page'
def inspect(page,sold=False,status=None):
    from ebay_sales import parse_cards,extract_cards
    title=page.title();body=page.locator('body').inner_text(timeout=8000);state=classify(page.url,status,title,body)
    d={'state':state,'http_status':status,'destination':urlsplit(page.url).hostname or '', 'cards':0,'sales':0}
    if state=='search_page':
        cards=extract_cards(page);d['cards']=len(cards);d['sales']=len(parse_cards(cards,'Garmin Striker 4')) if sold else 0
        d['state']='passed' if (d['sales'] if sold else d['cards']) else 'no_matching_evidence'
    return d

def test_navigation(page,sold=False):
    try:
        r=page.goto(url_for(sold),wait_until='domcontentloaded',timeout=30000)
        return inspect(page,sold,r.status if r else None)
    except Exception as e:
        # A concurrent sign-in redirect may interrupt goto. Do not retry or bypass it.
        try:d=inspect(page,sold)
        except Exception:d={'state':'navigation_error','destination':urlsplit(page.url).hostname or '', 'cards':0,'sales':0,'http_status':None}
        if d['state']=='passed':d['state']='navigation_interrupted'
        d['error']=type(e).__name__;return d

def save_report(report):
    root().mkdir(parents=True,exist_ok=True);p=root()/'ebay-session-report.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(report));os.replace(tmp,p)
def report():
    try:return json.loads((root()/'ebay-session-report.json').read_text())
    except (OSError,ValueError):return {}
def main():
    from playwright.sync_api import sync_playwright
    from install_update import ensure_stopped
    parser=argparse.ArgumentParser();parser.add_argument('--browser',choices=ENGINES);args=parser.parse_args();ensure_stopped()
    db=Path(os.getenv('SCOUT_DB',str(Path(__file__).parent/'scout.db')))
    if args.browser and args.browser!=settings():
        suspend(db,'Browser changed; authorized access test required');set_engine(args.browser)
    engine=settings()
    print('Browser:',engine,'| Use automated tests only with eBay authorization. No password is stored by Retail Scout.')
    result={'engine':engine,'timestamp':time.time(),'authentication':'unverified'}
    with sync_playwright() as p:
        try:ctx=launch(p,engine)
        except Exception as e:
            result['launch']={'state':'failed','error':type(e).__name__};save_report(result);print('Browser launch failed. Verify selected browser is installed.');return 1
        try:
            result['launch']={'state':'passed'};page=ctx.pages[0] if ctx.pages else ctx.new_page()
            try:page.goto('https://www.ebay.com/',wait_until='domcontentloaded',timeout=45000)
            except Exception:print('Homepage navigation interrupted; inspect browser manually.')
            input('Sign in manually if needed. Wait until sign-in finishes. Press Enter to continue: ')
            if urlsplit(page.url).hostname in ('signin.ebay.com','accounts.google.com'):
                result['authentication']='sign-in incomplete or failed';suspend(db,'Authentication incomplete; authorized test required');print('Sign-in has not completed. Automated tests skipped.');return 1
            if input('Do you have authorization for automated eBay research? Type YES to test: ')!='YES':return 1
            result['standard']=test_navigation(page);result['authentication']='search accessible; account login not independently verified' if result['standard']['state']=='passed' else result['standard']['state'];print('Standard search:',result['standard'])
            if result['standard']['state']!='passed':
                suspend(db,'Standard search test did not confirm access');return 1
            result['completed']=test_navigation(page,True);print('Completed search:',result['completed'])
            if result['completed']['state']!='passed':
                suspend(db,'Completed-listings test did not confirm access');return 1
            if input('Confirm authorized access and resume automatic research? Type YES: ')!='YES':return 1
            with closing(sqlite3.connect(db)) as c,c:
                c.execute('CREATE TABLE IF NOT EXISTS ebay_control(id INTEGER PRIMARY KEY,reason TEXT)');c.execute('DELETE FROM ebay_control WHERE id=1')
            result['resume_confirmed']=True;print('Authorized test passed; restart Retail Scout. Full 30-day coverage remains unverified.');return 0
        except (KeyboardInterrupt,EOFError):return 1
        except Exception as e:
            result['error']=type(e).__name__;print('Session test interrupted:',type(e).__name__);suspend(db,'Session test interrupted; authorized access test required');return 1
        finally:
            save_report(result)
            try:input('Test ended. Inspect the browser; press Enter to close it: ')
            except (KeyboardInterrupt,EOFError):pass
            ctx.close()
if __name__=='__main__':sys.exit(main())
