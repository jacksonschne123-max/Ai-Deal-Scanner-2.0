"""Offline replay of authorized, locally saved HTML. Never opens Amazon or resets suspension."""
import argparse,json,re
from pathlib import Path
from html.parser import HTMLParser
import amazon_research as ar

class SafeHTML(HTMLParser):
    """Keep only inert structural markup and selector attributes. No network resources or scripts."""
    tags={'div','span','h1','h2','h3','p','section','main','ul','li','table','tbody','tr','td','th','a','form','input','b','strong','small','label','title'}
    def __init__(self):super().__init__(convert_charrefs=True);self.out=[];self.skip=0
    def handle_starttag(self,tag,attrs):
        from html import escape
        if tag in ('script','style','iframe','object','template'):self.skip+=1;return
        if self.skip or tag not in self.tags:return
        keep=[]
        for k,v in attrs:
            if v is None:continue
            if k in ('id','class','data-component-type','data-asin') or (tag=='a' and k=='href' and (ar.canonical(v) or (v.startswith('/') and not v.startswith('//') and ar.canonical('https://www.amazon.com'+v)))) or (tag=='form' and k=='action' and 'validateCaptcha' in v):keep.append(f' {k}="{escape(v,quote=True)}"')
        self.out.append('<'+tag+''.join(keep)+'>')
    def handle_endtag(self,tag):
        if tag in ('script','style','iframe','object','template') and self.skip:self.skip-=1;return
        if not self.skip and tag in self.tags and tag!='input':self.out.append('</'+tag+'>')
    def handle_data(self,data):
        from html import escape
        if not self.skip:self.out.append(escape(data))

def replay(page,html,product,url):
    clean=SafeHTML();clean.feed(html);page.set_content('<base href="https://www.amazon.com/">'+''.join(clean.out))
    raw=page.evaluate(ar.SNAP);cards=page.evaluate(ar.CARDS)
    result=ar.evaluate(raw,product,url)
    return {'requested':product['name'],'url':ar.canonical(url),'extraction':raw,'raw_card_count':len(cards),'matching_candidates':ar.candidates(cards,product)[:10],'result':result,'source':'offline saved HTML; not live or independently verified'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--input',required=True,type=Path);p.add_argument('--output',default='amazon-371-offline-results.json',type=Path);a=p.parse_args()
    from playwright.sync_api import sync_playwright
    entries=json.loads(a.input.read_text(encoding='utf-8-sig'));results=[]
    with sync_playwright() as pw:
        browser=pw.chromium.launch(channel='chrome',headless=True,chromium_sandbox=True)
        try:
            ctx=browser.new_context(service_workers='block',accept_downloads=False);ctx.route('**/*',lambda route:route.abort());page=ctx.new_page()
            for item in entries:
                path=Path(item['file']);path=path if path.is_absolute() else a.input.parent/path
                try:
                    if path.stat().st_size>30_000_000:raise ValueError('File too large')
                    row=replay(page,path.read_text(encoding='utf-8',errors='replace'),{'name':item['name']},item['url'])
                except Exception as e:row={'requested':item['name'],'error':type(e).__name__}
                results.append(row);print(json.dumps(row,indent=2,ensure_ascii=False),flush=True)
                a.output.write_text(json.dumps({'mode':'offline replay; zero Amazon requests','results':results},indent=2,ensure_ascii=False),encoding='utf-8')
        finally:browser.close()
    print('REPORT:',a.output.resolve())
if __name__=='__main__':main()
