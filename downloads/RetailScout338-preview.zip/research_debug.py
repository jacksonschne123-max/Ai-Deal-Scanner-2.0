"""Opt-in browser observation; no remote shell or authenticated browser profile."""
import time, threading, os, re, base64
from collections import deque
from urllib.parse import urlsplit
import activity
LOCK=threading.RLock(); MODE='headless'; EVENTS=deque(maxlen=200); SHOT=None; LAST_SHOT=0; ACTIVE=0

def mode(value=None):
    global MODE,SHOT,LAST_SHOT
    with LOCK:
        if value is not None:
            if value not in ('headless','visible','remote'):raise ValueError('Invalid mode')
            MODE=value;SHOT=None;LAST_SHOT=0
        return MODE

def safe_url(url):
    try:
        u=urlsplit(url);return activity.scrub(u.hostname or '')+' '+activity.scrub(u.path or '/')
    except ValueError:return ''

def event(stage,url='',**kw):
    row={'stamp':time.time(),'stage':stage,'url':safe_url(url),**kw}
    with LOCK:EVENTS.appendleft(row)
    activity.emit(stage,engine='browser',message=str(row['url'])+' '+str(kw.get('status','')))

def capture(page):
    global SHOT,LAST_SHOT
    with LOCK:
        if MODE!='remote' or time.monotonic()-LAST_SHOT<5:return
        LAST_SHOT=time.monotonic()
    try:
        # Public, anonymous browser only. Never capture challenges or login forms.
        if page.locator('input[type=password]').count():return
        if re.search(r'captcha|verify you are human|sign in|access denied',page.title(),re.I):return
        data=page.screenshot(type='jpeg',quality=55,timeout=5000)
        if len(data)<2_000_000:
            with LOCK:
                if MODE=='remote':SHOT={'stamp':time.time(),'url':safe_url(page.url),'image':'data:image/jpeg;base64,'+base64.b64encode(data).decode()}
    except Exception:pass

def snapshot():
    with LOCK:return {'mode':MODE,'events':list(EVENTS),'screenshot':SHOT}
