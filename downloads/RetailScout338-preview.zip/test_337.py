import unittest,tempfile,os,time
from unittest.mock import patch
import amazon_research as a,server as s
class AmazonTests(unittest.TestCase):
 def test_bosch(self):
    r=a.evaluate({'title':'BOSCH GT3000 8 pc. Glass & Tile Bit Set','price':'$25.99','demand':'100+ bought in past month'},{'name':'Bosch GT3000 8 piece'},'https://www.amazon.com/dp/B001GNC8RS');self.assertEqual(r['amazon_price'],25.99);self.assertEqual(r['amazon_monthly_lower_bound'],100)
 def test_hollyland(self):
    r=a.evaluate({'title':'Hollyland LARK A2(2TX+1RX+Charging Case) Wireless Microphone, AI Auto-Limit','price':'$35.99','availability':'In Stock {"test":true}','demand':'5K+ bought in past month'},{'name':'Hollyland LARK A2'},'https://www.amazon.com/dp/B0F3D55D5R');self.assertEqual(r['amazon_stock'],'In Stock');self.assertEqual(r['amazon_monthly_lower_bound'],5000)
 def test_missing_title(self):
    self.assertNotIn('amazon_price',a.evaluate({'price':'$15.99','availability':'In Stock'},{'name':'Anker Nano Neo 65W'},'https://www.amazon.com/dp/B0H7BYWCNG'))
 def test_accessory(self):
    p={'name':'Beatbot AquaSense 2 Ultra'};c=a.candidates([{'url':'https://www.amazon.com/dp/B0HD764RKJ','title':'Beatbot AquaSense 2 Ultra Robotic Pool Cleaner'},{'url':'https://www.amazon.com/dp/B0FW3TYMJT','title':'Beatbot Genuine Dual Filter Basket for AquaSense 2 Ultra'}],p);self.assertEqual(len(c),1)
 def test_wrong_variant(self):
    self.assertFalse(a.matches('Bosch GT3000 4 pc set',{'name':'Bosch GT3000 8 piece','brand':'Bosch','model':'GT3000'}))
 def test_history(self):
    with tempfile.TemporaryDirectory() as d:
        db=d+'/db';p={'name':'Bosch GT3000'};r=a.evaluate({'title':'Bosch GT3000','price':'$25.99'},p,'https://www.amazon.com/dp/B001GNC8RS');a.store(db,p,r);self.assertEqual(a.cached(db,p)['amazon_price'],25.99);r['amazon_price']=20;a.store(db,p,r);self.assertLess(r['amazon_price_change_pct'],0);self.assertEqual(len(a.history(db)),2)
 def test_suspension(self):
    with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'SCOUT_AMAZON_AUTHORIZED':'1'}):
        a.suspend(d+'/db','restricted');self.assertIn('suspended',a.research({'name':'Bosch GT3000'},d+'/db')['amazon_status'])
 def test_opt_in(self):
    with tempfile.TemporaryDirectory() as d,patch.dict(os.environ,{'SCOUT_AMAZON_AUTHORIZED':'0'}):self.assertIn('not enabled',a.research({'name':'Bosch GT3000'},d+'/db')['amazon_status'])
 def test_profit_separation(self):
    with patch.object(s,'pricing',return_value={'resale':None,'amazon_price':100,'amazon_status':'price candidate'}):
        p=s.process({'name':'Bosch GT3000','cost':25},prepared=True);self.assertIsNone(p['profit']);self.assertGreater(p['amazon_estimated_profit'],0)
 def test_dom(self):
    from playwright.sync_api import sync_playwright
    from test_browser import chromium
    with sync_playwright() as pw:
        b=chromium(pw)
        try:
            page=b.new_page();page.set_content('<h1 id="productTitle">Bosch GT3000 8 pc set</h1><div id="corePrice_feature_div"><span class="a-price"><span class="a-offscreen">$25.99</span></span></div><div id="availability"><span>In Stock</span></div>');raw=page.evaluate(a.SNAP);self.assertEqual(raw['price'],'$25.99');self.assertEqual(raw['title'],'Bosch GT3000 8 pc set')
        finally:b.close()
 def test_primary_route(self):
    with patch.dict(os.environ,{'SCOUT_PRICING_MODE':'amazon'}),patch.object(a,'research',return_value={'amazon_price':25.99,'amazon_status':'price candidate'}),patch.object(s.ebay_sales,'lookup') as e:
        r=s.pricing({'name':'Bosch GT3000'});self.assertEqual(r['amazon_price'],25.99);self.assertIsNone(r['resale']);e.assert_not_called()
 def test_manual_api(self):
    from fastapi.testclient import TestClient
    with tempfile.TemporaryDirectory() as d,patch.object(s,'DB',d+'/db'),patch.object(s,'TOKEN','fixture'):
        s.init();client=TestClient(s.app);h={'x-scout-token':'fixture'};r=client.post('/api/amazon-manual',headers=h,json={'name':'Bosch GT3000','title':'Bosch GT3000 8 piece','url':'https://www.amazon.com/dp/B001GNC8RS','price':'$25.99'});self.assertEqual(r.status_code,200);self.assertIn('User-entered',r.json()['amazon_evidence']);self.assertEqual(len(client.get('/api/amazon-research',headers=h).json()['history']),1)
