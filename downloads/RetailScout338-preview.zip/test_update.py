import tempfile,unittest,sqlite3
from pathlib import Path
from contextlib import closing
import install_update as u
class Updater(unittest.TestCase):
 def test_preserve_and_rollback(self):
    with tempfile.TemporaryDirectory() as t:
        root=Path(t);stage=root/'stage';target=root/'target';stage.mkdir();target.mkdir()
        for n in u.FILES:(stage/n).write_text('new '+n)
        (target/'server.py').write_text('old');(target/'config.bat').write_text('private');(target/'start.bat').write_text('launcher');(target/'.venv').mkdir()
        with closing(sqlite3.connect(target/'scout.db')) as c,c:c.execute('CREATE TABLE history(x)');c.execute('INSERT INTO history VALUES(1)')
        backup=u.apply(stage,target);self.assertEqual((target/'server.py').read_text(),'new server.py');self.assertEqual((target/'config.bat').read_text(),'private');self.assertEqual((target/'start.bat').read_text(),'launcher');self.assertTrue((target/'.venv').is_dir());self.assertTrue((backup/'scout.db').exists())
        with closing(sqlite3.connect(backup/'scout.db')) as c:self.assertEqual(c.execute('SELECT x FROM history').fetchone()[0],1)
        u.rollback(target,backup);self.assertEqual((target/'server.py').read_text(),'old');self.assertFalse((target/'auctions.py').exists());self.assertEqual((target/'config.bat').read_text(),'private')
 def test_missing_file_aborts_before_mutation(self):
    with tempfile.TemporaryDirectory() as t:
        root=Path(t);stage=root/'stage';target=root/'target';stage.mkdir();target.mkdir()
        for n in ('server.py','config.bat','start.bat'):(target/n).write_text('old')
        with self.assertRaises(FileNotFoundError):u.apply(stage,target)
        self.assertEqual((target/'server.py').read_text(),'old');self.assertFalse((target/'backups').exists())
