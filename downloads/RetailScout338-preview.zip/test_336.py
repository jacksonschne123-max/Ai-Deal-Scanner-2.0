import unittest,tempfile,os
from unittest.mock import patch,Mock
from datetime import datetime,timezone,timedelta
import ebay_session as e,manual_sales as m,ebay_sales as sales
class BrowserRepair(unittest.TestCase):
 def test_engines(self):
    with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'LOCALAPPDATA':t}):
        old=e.profile();e.set_engine('chrome');self.assertNotEqual(old,e.profile());p=Mock();e.launch(p);self.assertEqual(p.chromium.launch_persistent_context.call_args.kwargs['channel'],'chrome');e.set_engine('msedge');self.assertEqual(e.settings(),'msedge');self.assertRaises(ValueError,e.set_engine,'invalid')
 def test_redirect(self):
    p=Mock();p.url='https://signin.ebay.com/signin/s';p.goto.side_effect=RuntimeError('interrupted');p.title.return_value='Error Page | eBay';p.locator.return_value.inner_text.return_value='Something went wrong on our end';self.assertEqual(e.test_navigation(p)['state'],'authentication_error')
    with self.assertRaises(PermissionError):sales.crawl(p,'Garmin Striker 4',delay=lambda _:None)
 def test_classification(self):
    self.assertEqual(e.classify('https://www.ebay.com/sch/i.html',403),'restricted');self.assertEqual(e.classify('https://accounts.google.com/signin',200),'authentication_required');self.assertEqual(e.classify('https://www.ebay.com/',200),'unexpected_page')
 def test_report(self):
    with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'LOCALAPPDATA':t}):
        e.save_report({'standard':{'state':'passed'}});self.assertEqual(e.report()['standard']['state'],'passed')
 def test_manual(self):
    day=(datetime.now(timezone.utc)-timedelta(days=1)).strftime('%Y-%m-%d');text=f'title,price,date,url,condition\nGarmin Striker 4,45,{day},https://www.ebay.com/itm/123,New\n';self.assertEqual(len(m.parse(text)),1);self.assertRaises(ValueError,m.parse,text.replace('45','nan'));self.assertRaises(ValueError,m.parse,text.replace('www.ebay.com','evil.com'))
 def test_api_manual_and_settings(self):
    import server as s
    from fastapi.testclient import TestClient
    with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'LOCALAPPDATA':t}),patch.object(s,'DB',t+'/db'),patch.object(s,'TOKEN','test'):
        s.init();client=TestClient(s.app);h={'x-scout-token':'test'};self.assertEqual(client.post('/api/browser-settings',json={'engine':'chrome'}).status_code,401);self.assertEqual(client.post('/api/browser-settings',headers=h,json={'engine':'chrome'}).status_code,200)
        day=(datetime.now(timezone.utc)-timedelta(days=1)).strftime('%Y-%m-%d');csv=f'title,price,date,url,condition\nGarmin Striker 4,45,{day},https://www.ebay.com/itm/123,New\n';r=client.post('/api/manual-comps',headers=h,json={'query':'Garmin Striker 4','csv':csv});self.assertEqual(r.status_code,200);self.assertIsNone(r.json()['resale']);self.assertFalse(r.json()['complete']);d=client.get('/api/ebay-research',headers=h).json();self.assertEqual(d['browser_engine'],'chrome');self.assertTrue(d['suspended']);self.assertEqual(len(d['manual_comps']),1)
