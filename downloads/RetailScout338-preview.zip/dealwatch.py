import os,re,hashlib,xml.etree.ElementTree as ET
from urllib.parse import urlparse
from html.parser import HTMLParser
from email.utils import parsedate_to_datetime
from datetime import datetime,timezone
from html import unescape
import time,requests
import providers,activity
FEEDS=['https://feeds.feedburner.com/SlickdealsnetFP','https://feeds.feedburner.com/SlickdealsnetUP','https://9to5toys.com/feed/','https://bensbargains.net/rss/']
NAMES={FEEDS[0]:'Slickdeals RSS main',FEEDS[1]:'Slickdeals RSS popular',FEEDS[2]:'9to5Toys RSS',FEEDS[3]:"Ben's Bargains RSS"}
HOSTS={'feeds.feedburner.com':('slickdeals.net','www.slickdeals.net','feedproxy.google.com'),'slickdeals.net':('www.slickdeals.net','feeds.feedburner.com','feedproxy.google.com'),'9to5toys.com':('www.9to5toys.com',),'bensbargains.net':('bensbargains.com','www.bensbargains.com','www.bensbargains.net')}
def source_name(url):return NAMES.get(url,'RSS '+str(urlparse(url).hostname or 'custom'))
class Links(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.urls=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.urls.extend(v for k,v in attrs if k=='href' and v)
def parse_rss(data,source='Slickdeals community lead',stats=None):
    if stats is None:stats={}
    if isinstance(data,bytes) and re.search(br'<!DOCTYPE|<!ENTITY',data,re.I) or isinstance(data,str) and re.search(r'<!DOCTYPE|<!ENTITY',data,re.I):raise ValueError('Unsupported XML declaration')
    root=ET.fromstring(data)
    for el in root.iter():el.tag=el.tag.rsplit('}',1)[-1]
    if root.tag not in ('rss','feed','RDF'):raise ValueError('Response is not an RSS or Atom feed')
    entries=root.findall('.//item')+root.findall('.//entry');stats['entries']=len(entries);stats['filtered']=0;seen=set()
    for x in entries:
        title=unescape(x.findtext('title') or '');url=x.findtext('link') or '';date=x.findtext('pubDate') or x.findtext('published') or x.findtext('updated') or x.findtext('date')
        if not url:url=next((a.get('href','') for a in x.findall('link') if a.get('rel','alternate')=='alternate'),'')
        if source.startswith('Slickdeals'):
            original=x.findtext('origLink') or ''
            if urlparse(original).hostname in ('slickdeals.net','www.slickdeals.net'):url=original
        # Legacy publisher links may use HTTP; open the equivalent HTTPS link only on known hosts.
        if urlparse(url).scheme=='http' and urlparse(url).hostname in ('slickdeals.net','www.slickdeals.net','bensbargains.net','www.bensbargains.net','bensbargains.com','www.bensbargains.com','9to5toys.com','www.9to5toys.com'):url='https://'+url[7:]
        price_title=re.sub(r'\(\s*(?:reg(?:ular)?\.?|was|MSRP|list price)\s*:?\s*\$[\d,.]+\s*\)', '',title,flags=re.I)
        prices=re.findall(r'(?<![A-Za-z])\$\s*(\d[\d,]*(?:\.\d{1,2})?)(?![\d.])',price_title)
        if len(prices)!=1 or re.search(r'\b(?:from|starting|cashback|gift card|subscription|after rebate|statement credit|up to|each|select|ymmv|refurbished|used|open.box)\b|\d+\s*%',title,re.I):stats['filtered']+=1;continue
        if not providers.public_url(url):stats['filtered']+=1;continue
        try:
            try:dt=parsedate_to_datetime(date)
            except (ValueError,TypeError):dt=datetime.fromisoformat(date.replace('Z','+00:00'))
            if dt.tzinfo is None:raise ValueError('Missing timezone')
            posted=dt.timestamp()
        except (ValueError,TypeError,AttributeError,OverflowError):stats['filtered']+=1;continue
        if not -300<=time.time()-posted<=259200:stats['filtered']+=1;continue
        cost=float(prices[0].replace(',',''));name=re.sub(r'\s*\$\s*[\d,.]+.*$','',price_title).strip(' -:')
        if not name:name=re.sub(r'^\s*\$\s*[\d,.]+\s*(?:for\s+|[-:]\s*)?','',price_title,flags=re.I).strip(' -:')
        if cost<=0 or not name or url in seen:stats['filtered']+=1;continue
        seen.add(url);direct=[];parser=Links()
        description=' '.join(x.findtext(k) or '' for k in ('description','content','summary','encoded'))
        parser.feed(description)
        for u in parser.urls+re.findall(r'https://[^\s"<>]+',description):
            u=unescape(u);host=urlparse(u).hostname or ''
            if retailer_link(u) and host not in {urlparse(url).hostname,'slickdeals.net','www.slickdeals.net','9to5toys.com','bensbargains.com'} and u not in direct:direct.append(u)
        retailer_url=direct[0] if len(direct)==1 else None
        yield dict(retailer_url=retailer_url,name=name,cost=cost,url=url,lead_url=url,store=source,stock='Unverified',posted=posted,deal_id=x.findtext('guid') or x.findtext('id') or url,price_verified=False)
def retailer_link(url):
    from urllib.parse import urlsplit
    if not providers.public_url(url):return False
    u=urlsplit(url);host=u.hostname or '';path=u.path.lower()
    return not (host.endswith('slickdealscdn.com') or re.search(r'\.(?:jpg|jpeg|png|webp|gif|thumb|svg|pdf)$',path) or path.rstrip('/') in ('','/blackfriday','/black-friday','/deals','/s'))

def article_retailer(page,product):
    """Choose only an unambiguous retail link; never use an image as a product."""
    from identity_research import query
    from ebay_sales import matches
    q=query(product); candidates=[]; strong=[]
    source_host=urlparse(page.get('url') or '').hostname
    for link in page.get('links',[]):
        u=link.get('url',''); host=urlparse(u).hostname or ''; path=urlparse(u).path
        if not retailer_link(u) or host==source_host or host.endswith(('.slickdeals.net','.9to5toys.com')):continue
        if not (host in ('www.amazon.com','amazon.com','link.amazon','amzn.to','www.bestbuy.com','www.walmart.com','www.target.com','www.homedepot.com','www.lowes.com') or q and matches(link.get('title',''),q)):continue
        if host in ('amazon.com','www.amazon.com') and not re.search(r'/(?:dp|gp/product)/[A-Z0-9]{10}(?:/|$)',path,re.I):continue
        if u not in candidates:candidates.append(u)
        if q and matches(link.get('title',''),q) and u not in strong:strong.append(u)
    if len(strong)==1:return strong[0]
    if not strong and len(candidates)==1:return candidates[0]
    return None

def rss(url):
    name=source_name(url);key='RSS: '+name;stats={}
    data=providers.request_text(url,key,redirect_hosts=HOSTS.get(urlparse(url).hostname,()),headers={'User-Agent':'RetailScout/3.3.2 RSS reader','Accept':'application/rss+xml, application/atom+xml, application/xml, text/xml'})
    try:items=list(parse_rss(data,name,stats))
    except (ET.ParseError,ValueError):
        providers.GATE.fail(key,'Invalid RSS/Atom response',60);raise providers.ProviderError('Invalid RSS/Atom response') from None
    activity.emit('feed parsed',source=name,message=f"{stats['entries']} raw entries; {stats['filtered']} filtered; {len(items)} product leads")
    return items
def bestbuy(key):
    data=providers.request_json('GET','https://api.bestbuy.com/v1/products(onSale=true&onlineAvailability=true)','Best Buy API',params={'apiKey':key,'format':'json','show':'sku,name,upc,salePrice,url,onlineAvailability','pageSize':50})
    for x in data.get('products',[]):
        if x.get('onlineAvailability') is True and x.get('salePrice') is not None:
            yield dict(name=x['name'],upc=x.get('upc'),cost=x['salePrice'],url=x['url'],store='Best Buy',stock='Online available',posted=time.time(),deal_id=str(x['sku']),price_verified=True)
def classify(item):
    if item.get('profit') is None: return 'Needs resale evidence'
    if item.get('profit')<=0: return 'Not profitable at estimated costs'
    if not item.get('price_verified'): return 'Potential lead — verify retail offer'
    if item.get('source') not in ('eBay sold (provider)','eBay sold (browser)') or item.get('sample',0)<3: return 'Potential lead — insufficient sold evidence'
    return 'Positive estimate — verify eligibility, stock and condition'
def fingerprint(p):
    return hashlib.sha256((str(p.get('store'))+'|'+str(p.get('deal_id') or p.get('url') or p.get('name'))).encode()).hexdigest()

def product_candidates(page,store,limit=25):
    """Discover structured products on an explicitly configured retailer page."""
    from intelligence import JsonLD,walk
    from providers import public_url,allowed
    parser=JsonLD();parser.feed(page.get('html',''));seen=set();out=[]
    for x in walk(parser.items):
        t=x.get('@type');types=[t] if isinstance(t,str) else t or []
        if 'Product' not in types or not isinstance(x.get('name'),str):continue
        brand=x.get('brand');brand=brand.get('name') if isinstance(brand,dict) else brand
        url=x.get('url') or page.get('url')
        if not public_url(url) or not allowed(url) or url in seen:continue
        seen.add(url);out.append(dict(name=x['name'],brand=brand,model=x.get('mpn') or x.get('model'),upc=x.get('gtin12') or x.get('gtin13') or x.get('gtin14'),url=url,store=store,posted=time.time(),deal_id=url))
        if len(out)>=limit:break
    return out
