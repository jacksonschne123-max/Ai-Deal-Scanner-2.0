import os,tempfile,threading,unittest,time
from unittest.mock import patch
from pathlib import Path
from fastapi.testclient import TestClient
import activity,server as s

class ActivityTests(unittest.TestCase):
 def setUp(self):
    self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
    self.db=patch.object(s,'DB',str(Path(self.tmp.name)/'test.db'));self.db.start();self.addCleanup(self.db.stop)
    self.env=patch.dict(os.environ,{'SCOUT_RSS':'0','BESTBUY_API_KEY':'','SCOUT_TOKEN':'secret-token-example'});self.env.start();self.addCleanup(self.env.stop)
    s.STOP.clear();s.init();s.LIVE.reset();self.addCleanup(lambda:setattr(s.LIVE,'mode','running'))
 def test_progress_and_counts(self):
    m=s.LIVE;m.bump('discovered',8,'test');m.bump('scheduled',4,'test');m.bump('processed',1,'test');m.bump('skipped',1,'test');self.assertIsNone(m.snapshot()['percent']);m.state['discovery_complete']=True;self.assertEqual(m.snapshot()['percent'],50);self.assertEqual(m.totals()['daily']['discovered'],8);self.assertEqual(m.totals()['sources']['test']['processed'],1)
 def test_persist_control_and_logs(self):
    s.LIVE.control('pause');s.LIVE.control('balanced');m=activity.Monitor(lambda:s.DB);m.init();self.assertEqual(m.mode,'paused');self.assertEqual(m.priority,'balanced');self.assertEqual(m.history()[0]['message'],'balanced');m.control('stop');self.assertFalse(m.checkpoint(threading.Event()))
 def test_redaction(self):
    with activity.scope('dealwatch'):activity.emit('test',product='secret-token-example',message='https://example.com/?key=secret-token-example')
    x=s.LIVE.history()[0];self.assertEqual(x['engine'],'dealwatch');self.assertNotIn('secret-token-example',str(x));self.assertNotIn('https://',str(x))
 def test_scope_isolation(self):
    with activity.scope('dealwatch'):activity.emit('current',product='Example',page=3)
    activity.emit('scan event',engine='scanner');self.assertEqual(s.LIVE.snapshot()['stage'],'current');self.assertEqual(s.LIVE.snapshot()['page'],3)
 def test_cycle_actual(self):
    s.save('source',{'name':'Fixture','url':'https://example.com','category':'feed'})
    items=[{'name':'A'},{'name':'B','posted':time.time()-80*3600},{'name':'C'}]
    with patch.object(s,'fetch_json',return_value={'products':items}),patch.object(s,'evaluate_deal',side_effect=[{'fingerprint':'a','name':'A','assessment':'Rejected — economics'},RuntimeError('test')]):s.monitor_once()
    p=s.LIVE.snapshot();self.assertEqual((p['discovered'],p['scheduled'],p['processed'],p['rejected'],p['errors'],p['skipped'],p['percent']),(3,3,1,1,1,1,100));self.assertFalse(p['active']);self.assertTrue(any('economics' in x['message'] for x in s.LIVE.history()))
 def test_stopped_no_source_calls(self):
    s.LIVE.control('stop');s.save('source',{'name':'Fixture','url':'https://example.com','category':'feed'})
    with patch.object(s,'fetch_json') as f:s.monitor_once();f.assert_not_called()
 def test_auth_report_and_actions(self):
    with patch.object(s,'TOKEN','secret-token-example'):
        c=TestClient(s.app);self.assertEqual(c.get('/api/activity').status_code,401);h={'x-scout-token':'secret-token-example'};self.assertEqual(c.post('/api/activity/pause',headers=h).json()['mode'],'paused');self.assertEqual(c.post('/api/activity/invalid',headers=h).status_code,400);r=c.get('/api/activity/report',headers=h);self.assertEqual(r.status_code,200);self.assertIn('attachment',r.headers['content-disposition']);self.assertNotIn('secret-token-example',r.text)
 def test_pause_resume_and_stop_real_checkpoint(self):
    m=s.LIVE;stop=threading.Event();m.control('pause');completed=threading.Event();result=[]
    def run():result.append(m.checkpoint(stop));completed.set()
    t=threading.Thread(target=run);t.start();self.assertFalse(completed.wait(.05));m.control('resume');self.assertTrue(completed.wait(2));t.join();self.assertEqual(result,[True]);m.control('stop');self.assertFalse(m.checkpoint(stop))
 def test_blocker_counts(self):
    p={'identity_method':'Unknown','assessment':'Potential lead — verify retail offer','deferred':True}
    reasons=s.blocker_reasons(p);self.assertIn('Exact product identity missing',reasons);self.assertIn('Resale research deferred',reasons)
    for r in reasons:s.LIVE.reason(r,'Fixture')
    self.assertEqual(s.LIVE.snapshot()['blockers']['Exact product identity missing'],1);self.assertEqual(s.LIVE.totals()['sources']['Fixture']['reason:Exact product identity missing'],1)
 def test_provider_cooldown_in_activity(self):
    import providers
    g=providers.Gate()
    with activity.scope('dealwatch'):
        g.check('Fixture');g.fail('Fixture','HTTP 503',60)
        with self.assertRaises(providers.Deferred):g.check('Fixture')
    self.assertEqual(s.LIVE.history()[0]['stage'],'provider cooldown');self.assertTrue(g.snapshot()['Fixture']['next']>time.time())
 def test_legacy_preview_data_still_valid(self):
    s.save('scan',{'version':'3.3.0-preview','name':'Prior scan','resale':50});self.assertEqual(s.records('scan')[0]['resale'],50)
