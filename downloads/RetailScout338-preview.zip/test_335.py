import os, unittest, tempfile
from unittest.mock import patch
import dealwatch as d, auctions as a, identity_research as i, ebay_session as session, server as s, providers as p, ebay_sales as e
from test_discovery import feed
class RepairTests(unittest.TestCase):
 def test_image_rejection(self):
    self.assertFalse(d.retailer_link('https://static.slickdealscdn.com/attachment/123.thumb'))
    self.assertFalse(d.retailer_link('https://www.amazon.com/blackfriday'))
    self.assertTrue(d.retailer_link('https://www.amazon.com/dp/B012345678'))
 def test_feed_image_not_retailer(self):
    xml=feed().decode().replace('</item>','<description><![CDATA[<a href="https://static.slickdealscdn.com/attachment/123.thumb">image</a><a href="https://retail.example/product/1">buy</a>]]></description></item>')
    self.assertEqual(list(d.parse_rss(xml))[0]['retailer_url'],'https://retail.example/product/1')
 def test_auction_filters(self):
    for url in ['https://hibid.com/auctions/past','https://hibid.com/catalog/1/estate-vehicle-sale-ending-nov-29','https://hibid.com/catalog/2/wilmington-nc-3br','https://example.com/events/fall-ammo-auction']:
        self.assertTrue(a.unsuitable(url),url)
    self.assertFalse(a.unsuitable('https://atxknoxville.hibid.com/catalog/1/electronics'))
 def test_slug(self):
    self.assertEqual(i.slug_candidate('https://9to5toys.com/2026/11/24/aothia-63-x-24-pu-leather-desk-mat/'),'aothia 63 x 24 pu leather desk mat')
    self.assertEqual(i.slug_candidate('https://example.com/whatever-product-name'),'')
 def test_session_path(self):
    with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'LOCALAPPDATA':t}):
        self.assertFalse(session.configured());(session.profile()/'Default').mkdir(parents=True);self.assertTrue(session.configured())
 def test_suspension_stays(self):
    with tempfile.TemporaryDirectory() as t,patch.dict(os.environ,{'SCOUT_EBAY_BROWSER':'1'}),patch.object(e,'last',0),patch.object(e,'browse',side_effect=PermissionError('restricted')) as b:
        e.lookup({'name':'Garmin Striker 4'},t+'/db');e.lookup({'name':'Garmin Striker 4'},t+'/db');self.assertEqual(b.call_count,1)
 def test_gemini_cooldown(self):
    gate=p.Gate();gate.check('Gemini');gate.fail('Gemini','HTTP 429',300)
    with patch.object(p,'GATE',gate),patch.dict(os.environ,{'SCOUT_GROUNDING':'1','GEMINI_API_KEY':'fixture'}),patch.object(s,'gemini') as g:
        self.assertEqual(s.grounded({'name':'Unknown'})['grounding_error'],'Cooldown');g.assert_not_called()
 def test_amazon_nonproduct(self):
    self.assertEqual(i.amazon_reference({'name':'Garmin Striker 4','url':'https://www.amazon.com/dp/B012345678'},lambda _:{'url':'https://www.amazon.com/blackfriday','html':''}),{})

 def test_article_links(self):
    page={'url':'https://9to5toys.com/2026/11/24/garmin-striker-4/','links':[{'url':'https://static.slickdealscdn.com/attachment/1.thumb','title':'Garmin Striker 4'},{'url':'https://www.amazon.com/blackfriday','title':'Garmin Striker 4'},{'url':'https://www.amazon.com/dp/B012345678','title':'Garmin Striker 4'}]}
    self.assertEqual(d.article_retailer(page,{'name':'Garmin Striker 4'}),'https://www.amazon.com/dp/B012345678')
    page['links'].append({'url':'https://www.amazon.com/dp/B012345679','title':'Garmin Striker 4'})
    self.assertIsNone(d.article_retailer(page,{'name':'Garmin Striker 4'}))
