import os,time,tempfile,unittest
from pathlib import Path
from unittest.mock import patch,Mock
from email.utils import formatdate
import providers as p,dealwatch as d,server as s

def response(status,body=b'',location=None):
    r=Mock(status_code=status,headers={'Location':location} if location else {});r.__enter__=Mock(return_value=r);r.__exit__=Mock(return_value=False);r.iter_content.return_value=[body];return r

def feed(title='Acme ABC123 $25.99',url='https://example.com/item',date=None):
    return f'<rss><channel><item><title>{title}</title><link>{url}</link><pubDate>{date or formatdate(time.time(),usegmt=True)}</pubDate></item></channel></rss>'.encode()
class Discovery(unittest.TestCase):
 def setUp(self):
    self.g=patch.object(p,'GATE',p.Gate());self.g.start();self.addCleanup(self.g.stop)
 def test_redirect(self):
    with patch.object(p.requests,'get',side_effect=[response(301,location='https://slickdeals.net/rss.php'),response(200,feed())]) as f:
        items=d.rss(d.FEEDS[0]);self.assertEqual(items[0]['cost'],25.99);self.assertFalse(items[0]['price_verified']);self.assertEqual(f.call_count,2);self.assertFalse(f.call_args.kwargs['allow_redirects'])
 def test_relative_redirect(self):
    with patch.object(p.requests,'get',side_effect=[response(308,location='/new'),response(200,feed())]) as f:
        self.assertEqual(p.request_text('https://example.com/feed','a'),feed());self.assertEqual(f.call_args.args[0],'https://example.com/new')
 def test_unsafe_redirect(self):
    for url in ('http://example.com/feed','https://127.0.0.1/test','https://evil.example/feed','https://user:pass@example.com/feed'):
        with patch.object(p.requests,'get',return_value=response(302,location=url)) as f:
            with self.assertRaises(p.ProviderError):p.request_text('https://example.com/feed',url)
            self.assertEqual(f.call_count,1)
 def test_loop(self):
    with patch.object(p.requests,'get',return_value=response(307,location='/feed')) as f:
        with self.assertRaises(p.ProviderError):p.request_text('https://example.com/feed','loop')
        self.assertEqual(f.call_count,1)
 def test_independent(self):
    with patch.object(p.requests,'get',side_effect=[response(503),response(200,feed())]):
        with self.assertRaises(p.ProviderError):d.rss(d.FEEDS[0])
        self.assertEqual(len(d.rss(d.FEEDS[1])),1)
 def test_access_denied(self):
    with patch.object(p.requests,'get',return_value=response(403)) as f:
        with self.assertRaises(p.Deferred):d.rss(d.FEEDS[0])
        with self.assertRaises(p.Deferred):d.rss(d.FEEDS[0])
        self.assertEqual(f.call_count,1)
 def test_invalid_html(self):
    with patch.object(p.requests,'get',return_value=response(200,b'<html>Blocked</html>')):
        with self.assertRaises(p.ProviderError):d.rss(d.FEEDS[0])
        self.assertEqual(p.GATE.snapshot()['RSS: '+d.source_name(d.FEEDS[0])]['error'],'Invalid RSS/Atom response')
 def test_atom(self):
    xml=f'<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Acme ABC123 $25.9</title><link href="https://example.com/item"/><updated>{time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}</updated></entry></feed>'
    self.assertEqual(list(d.parse_rss(xml))[0]['cost'],25.9)
 def test_stale_and_ambiguous(self):
    self.assertEqual(list(d.parse_rss(feed(date=formatdate(time.time()-4*86400,usegmt=True)))),[])
    self.assertEqual(list(d.parse_rss(feed(title='Acme from $25'))),[])
    self.assertEqual(list(d.parse_rss(feed(title='Acme $25 vs $40'))),[])
 def test_xml_entity(self):
    with self.assertRaises(ValueError):list(d.parse_rss(b'<!DOCTYPE rss [<!ENTITY x "test">]><rss/>'))
 def test_cycle_recovery(self):
    with tempfile.TemporaryDirectory() as t,patch.object(s,'DB',str(Path(t)/'test.db')),patch.dict(os.environ,{'SCOUT_RSS':'1','BESTBUY_API_KEY':'','SCOUT_GROUNDING':'0','SCOUT_EBAY_BROWSER':'0'}),patch.object(d,'FEEDS',d.FEEDS[:2]),patch.object(p.requests,'get',side_effect=[response(503),response(301,location='/alternate'),response(200,feed())]),patch.object(s,'pricing',return_value={}):
        s.init();s.monitor_once();v=s.LIVE.snapshot();self.assertEqual(v['discovered'],1);self.assertEqual(v['processed'],1);self.assertEqual(v['source_error'],1);self.assertEqual(len(s.rows('deal')),1);self.assertFalse(s.rows('deal')[0]['price_verified']);self.assertNotIn('Positive',s.rows('deal')[0]['assessment'])
 def test_all_failed(self):
    with tempfile.TemporaryDirectory() as t,patch.object(s,'DB',str(Path(t)/'test.db')),patch.dict(os.environ,{'SCOUT_RSS':'1','BESTBUY_API_KEY':''}),patch.object(d,'FEEDS',d.FEEDS[:2]),patch.object(p.requests,'get',return_value=response(503)):
        s.init();s.monitor_once();self.assertEqual(s.LIVE.snapshot()['stage'],'discovery failed');self.assertEqual(s.LIVE.snapshot()['discovered'],0)
 def test_persistent_queue_and_raw_lead(self):
    with tempfile.TemporaryDirectory() as t,patch.object(s,'DB',str(Path(t)/'test.db')),patch.dict(os.environ,{'SCOUT_RSS':'0','BESTBUY_API_KEY':''}),patch.object(s,'pricing',return_value={}):
        s.init();item={'name':'Acme ABC123','cost':25,'url':'https://example.com/product','lead_url':'https://example.com/product','store':'fixture','profit':999,'price_verified':True,'stock':'Online available'};s.queue_discovery('Fixture',[item]);s.init();self.assertEqual(len(s.pending_discovery()),1);self.assertFalse(s.rows('deal')[0]['price_verified']);self.assertNotIn('profit',s.rows('deal')[0]);s.monitor_once();self.assertEqual(len(s.pending_discovery()),0);self.assertEqual(s.LIVE.snapshot()['processed'],1);self.assertEqual(len(s.rows('deal')),1)
 def test_dedup_cross_feed(self):
    with tempfile.TemporaryDirectory() as t,patch.object(s,'DB',str(Path(t)/'test.db')),patch.dict(os.environ,{'SCOUT_RSS':'1','BESTBUY_API_KEY':''}),patch.object(d,'FEEDS',d.FEEDS[:2]),patch.object(p.requests,'get',side_effect=[response(200,feed()),response(200,feed())]),patch.object(s,'pricing',return_value={}):
        s.init();s.monitor_once();v=s.LIVE.snapshot();self.assertEqual(v['discovered'],2);self.assertEqual(v['scheduled'],1);self.assertEqual(v['processed'],1)
 def test_no_credential_forwarding(self):
    with patch.object(p.requests,'get') as f:
        with self.assertRaises(p.ProviderError):p.request_text('https://example.com/feed','private',headers={'Authorization':'secret'})
        f.assert_not_called()
 def test_feedburner_original_link(self):
    xml=f'<rss xmlns:feedburner="http://rssnamespace.org/feedburner/ext/1.0"><channel><item><title>Acme $25 (Reg. $40)</title><link>http://feedproxy.google.com/x</link><feedburner:origLink>http://slickdeals.net/f/123</feedburner:origLink><pubDate>{formatdate(time.time(),usegmt=True)}</pubDate></item></channel></rss>'
    item=list(d.parse_rss(xml,'Slickdeals RSS main'))[0];self.assertEqual(item['url'],'https://slickdeals.net/f/123');self.assertEqual(item['cost'],25)
 def test_leading_price(self):
    self.assertEqual(list(d.parse_rss(feed(title='$25 for Acme ABC123')))[0]['name'],'Acme ABC123')
