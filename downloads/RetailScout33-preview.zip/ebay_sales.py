"""Authorized opt-in browser research. No challenge or rate-limit bypass."""
import os,re,time,sqlite3,json,threading,statistics
import providers
from contextlib import closing
from urllib.parse import urlencode,urljoin,urlparse
from datetime import datetime,timezone
LOCK=threading.Lock(); last=0

def valid_upc(u):
    return bool(re.fullmatch(r"\d{8}|\d{12,14}",u)) and sum(int(x)*(3 if i%2 else 1) for i,x in enumerate(reversed(u)))%10==0

def identity(p):
    u=str(p.get('upc') or '')
    if valid_upc(u): return u
    m=str(p.get('model') or '').strip()
    b=str(p.get('brand') or '').strip()
    return b+' '+m if b and len(m)>=4 and any(c.isdigit() for c in m) and len(b)<=80 and len(m)<=80 else ''

def matches(title,query):
    return bool(query) and all(re.search(r'(?<![\w])'+re.escape(t)+r'(?![\w])',title,re.I) for t in query.split())

def parse_cards(cards,query):
    out=[]; seen=set()
    for c in cards:
        title=c.get('title',''); link=c.get('link',''); price=c.get('price',''); date=c.get('date','')+' '+c.get('details',''); condition=c.get('condition','')
        if not matches(title+' '+c.get('details',''),query): continue
        if not re.fullmatch(r'New(?: with tags| in box)?',condition.strip(),re.I): continue
        if re.search(r'\b(?:lot|bundle|parts|broken|empty box|best offer|compatible with|case only|box only|for parts|refurbished)\b',title+' '+c.get('details',''),re.I): continue
        m=re.search(r'/itm/(?:[^/?]+/)?(\d+)',link); p=re.fullmatch(r'\$([\d,]+\.\d{2})',price.strip()); d=re.search(r'\bSold\s+([A-Za-z]{3} \d{1,2}, \d{4})',date,re.I)
        if not (m and p and d) or m[1] in seen: continue
        try: stamp=datetime.strptime(d[1],'%b %d, %Y').replace(tzinfo=timezone.utc).timestamp()
        except ValueError: continue
        if not 0<=time.time()-stamp<=30*86400: continue
        value=float(p[1].replace(',',''))
        if value<=0: continue
        seen.add(m[1]);out.append(dict(id=m[1],price=value,date=stamp,url='https://www.ebay.com/itm/'+m[1],title=title))
    return out

def summarize(sales,complete=False):
    now=time.time(); unique={str(s['id']):s for s in sales if 0<=now-s['date']<=30*86400 and s['price']>0}; sales=list(unique.values()); recent=sorted(s['price'] for s in sales); week=[s['price'] for s in sales if now-s['date']<=7*86400]; older=[s['price'] for s in sales if now-s['date']>7*86400]
    med=statistics.median(recent) if recent else None; q=None
    if recent:
        pos=(len(recent)-1)*.25; lo=int(pos); q=round(recent[lo]+(recent[min(lo+1,len(recent)-1)]-recent[lo])*(pos-lo),2)
    return dict(resale=round(med,2) if len(recent)>=3 else None,median=med,mean=round(statistics.mean(recent),2) if recent else None,p25=q,sample=len(recent),source='eBay sold (browser)',observed_7d=len(week),observed_30d=len(recent),median_7d=statistics.median(week) if week else None,trend_pct=round((statistics.median(week)/statistics.median(older)-1)*100,2) if week and older else None,sales=sales,complete=complete,coverage=('Date cutoff or end reached' if complete else 'Partial search')+'; observed listings only; shipping excluded')

def crawl(page,query,delay=time.sleep,max_pages=None):
    url='https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':query,'LH_Sold':1,'LH_Complete':1,'LH_ItemCondition':1000,'_sop':13})
    all_cards=[]; complete=False; active=None
    def visit(url):
        response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
        if not response or response.status in (401,403,429) or re.search(r'captcha|security measure|verify you are human|access denied|pardon our interruption',page.title()+' '+page.locator('body').inner_text()[:3000],re.I): raise PermissionError('eBay access restricted; browser research suspended')
        if response.status>=400: raise RuntimeError('eBay HTTP '+str(response.status))
        if not page.url.startswith('https://www.ebay.com/sch/'): raise PermissionError('Unexpected eBay redirect; research suspended')
        return page.locator('li.s-item, li.s-card').evaluate_all('''els=>els.map(e=>{const t=s=>e.querySelector(s)?.innerText||'';return {title:t('.s-item__title,.s-card__title'),price:t('.s-item__price,.s-card__price'),date:t('.s-item__title--tag,.s-item__caption,.s-card__caption'),condition:t('.SECONDARY_INFO,.s-card__subtitle'),details:e.innerText,link:e.querySelector('a[href*="/itm/"]')?.href||''}})''')
    visited=set()
    for _ in range(max_pages or max(1,min(30,int(os.getenv('SCOUT_EBAY_MAX_PAGES','10'))))):
        if url in visited: break
        visited.add(url); cards=visit(url); all_cards+=cards
        dates=[]
        for card in cards:
            d=re.search(r'Sold\s+([A-Za-z]{3} \d{1,2}, \d{4})',card['date']+' '+card.get('details',''))
            if d:
                try: dates.append(datetime.strptime(d[1],'%b %d, %Y').replace(tzinfo=timezone.utc).timestamp())
                except ValueError: pass
        if dates and max(dates)<time.time()-30*86400: complete=True; break
        nxt=page.locator('a.pagination__next').first
        if not nxt.count():
            complete=bool(cards and dates) and bool(page.locator('.pagination__next[aria-disabled=true],button.pagination__next[disabled]').count()); break
        url=urljoin(page.url,nxt.get_attribute('href') or '')
        if not url.startswith('https://www.ebay.com/sch/'): break
        delay(3)
    delay(3)
    cards=visit('https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':query,'LH_ItemCondition':1000,'_sop':15}))
    vals=[]
    for c in cards:
        m=re.fullmatch(r'\$([\d,]+\.\d{2})',c['price'].strip())
        if m and matches(c['title'],query) and re.fullmatch(r'New(?: with tags| in box)?',c['condition'].strip(),re.I) and not re.search(r'\b(bundle|lot|parts|compatible|only)\b',c['title'],re.I): vals.append(float(m[1].replace(',','')))
    if vals: active=min(vals)
    return all_cards,complete,active

def browse(query):
    from playwright.sync_api import sync_playwright
    with providers.BROWSER,sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        try:return crawl(browser.new_page(),query)
        finally:browser.close()

def lookup(product,db):
    global last
    if os.getenv('SCOUT_EBAY_BROWSER')!='1': return None
    q=identity(product)
    if not q: return None
    with LOCK:
        with closing(sqlite3.connect(db,timeout=30)) as c, c:
            c.execute('CREATE TABLE IF NOT EXISTS ebay_cache (upc TEXT PRIMARY KEY, stamp REAL, data TEXT)');c.execute('CREATE TABLE IF NOT EXISTS ebay_control (id INTEGER PRIMARY KEY, reason TEXT)')
            if c.execute('SELECT reason FROM ebay_control WHERE id=1').fetchone(): return None
            row=c.execute('SELECT stamp,data FROM ebay_cache WHERE upc=?',('33:'+q,)).fetchone()
            if row:
                data=json.loads(row[1]); ttl=900 if data.get('resale') else 120
                if time.time()-row[0]<ttl: return data
        if time.monotonic()-last<60: return {'resale':None,'source':'eBay rate-limited; retry later','deferred':True,'retry_after':60,'sample':0,'complete':False}
        last=time.monotonic()
        try:
            raw=browse(q); cards,complete,active=raw if isinstance(raw,tuple) else (raw,False,None)
            result=summarize(parse_cards(cards,q),complete);result['active_low']=active;result['query']=q;result['researched_at']=time.time()
        except PermissionError as e:
            with closing(sqlite3.connect(db,timeout=30)) as c,c: c.execute('INSERT OR REPLACE INTO ebay_control VALUES(1,?)',(str(e),))
            return None
        except Exception as e: result={'resale':None,'source':'eBay browser error','error':type(e).__name__,'deferred':True,'retry_after':120,'researched_at':time.time()}
        with closing(sqlite3.connect(db,timeout=30)) as c,c: c.execute('INSERT OR REPLACE INTO ebay_cache VALUES(?,?,?)',('33:'+q,time.time(),json.dumps(result)))
        return result
