"""Shared transport, conservative backoff, and public-page browser access.
Only enable browser access to sites for which automated access is authorized.
"""
import os,re,time,threading,json,ipaddress,socket
from contextlib import contextmanager
from urllib.parse import urlparse
from email.utils import parsedate_to_datetime
import requests

class ProviderError(RuntimeError):pass
class Deferred(ProviderError):pass
class Gate:
    def __init__(self):self.lock=threading.Lock();self.states={}
    def check(self,name,interval=0):
        with self.lock:
            s=self.states.setdefault(name,{'calls':0,'failures':0,'next':0,'last_ok':None,'error':None})
            if time.time()<s['next']:raise Deferred(name+' cooling down')
            s['calls']+=1;s['next']=time.time()+interval
    def good(self,name):
        with self.lock:self.states[name].update(last_ok=time.time(),failures=0,error=None)
    def fail(self,name,reason,retry_after=0):
        with self.lock:
            s=self.states[name];s['failures']+=1;s['error']=reason;s['next']=max(s['next'],time.time()+max(retry_after,min(900,2**min(s['failures'],9))))
    def snapshot(self):
        with self.lock:return {k:dict(v) for k,v in self.states.items()}
GATE=Gate()

def retry_after(value):
    try:return max(0,float(value))
    except (TypeError,ValueError):
        try:return max(0,parsedate_to_datetime(value).timestamp()-time.time())
        except Exception:return 0

def request_json(method,url,provider,**kwargs):
    """Do not leak secrets in exception messages or retry access restrictions."""
    for i in range(3):
        GATE.check(provider)
        try:r=requests.request(method,url,timeout=(10,60),allow_redirects=False,**kwargs)
        except requests.RequestException as e:
            GATE.fail(provider,type(e).__name__)
            if i==2:raise ProviderError(provider+' transport error') from None
            time.sleep(2**(i+1));continue
        if r.status_code in (401,403,429):
            GATE.fail(provider,'HTTP '+str(r.status_code),max(60,retry_after(r.headers.get('Retry-After'))));raise Deferred(provider+' HTTP '+str(r.status_code))
        if r.status_code in (500,502,503,504):
            delay=max(2**(i+1),retry_after(r.headers.get('Retry-After')));GATE.fail(provider,'HTTP '+str(r.status_code),delay)
            if i==2 or delay>10:raise Deferred(provider+' HTTP '+str(r.status_code))
            time.sleep(delay);continue
        if not 200<=r.status_code<300:GATE.fail(provider,'HTTP '+str(r.status_code));raise ProviderError(provider+' HTTP '+str(r.status_code))
        try:data=r.json()
        except ValueError:GATE.fail(provider,'Invalid JSON');raise ProviderError(provider+' invalid JSON') from None
        GATE.good(provider);return data

# One general browser slot, separate from eBay's own serialized session.
# Scanner waiting takes precedence over background tasks at page boundaries.
BROWSER=threading.Lock()

def allowed(url):
    try:
        u=urlparse(str(url));host=u.hostname or ''
        return public_url(url) and host.lower() in {x.strip().lower() for x in os.getenv('SCOUT_BROWSER_HOSTS','').split(',') if x.strip()}
    except ValueError:return False

def public_url(url):
    try:
        u=urlparse(str(url));host=u.hostname or '';return u.scheme=='https' and '.' in host and host not in ('localhost','localhost.localdomain') and not host.endswith(('.local','.internal','.localhost','.ts.net')) and not re.fullmatch(r'[\d.]+',host) and not u.username and not u.password and u.port in (443,None)
    except ValueError:return False

def browser_page(url):
    if not allowed(url):raise ProviderError('Browser host not explicitly authorized')
    from playwright.sync_api import sync_playwright
    host=urlparse(url).hostname
    with BROWSER:
        GATE.check('browser:'+host,3)
        try:
            with sync_playwright() as p:
                browser=p.chromium.launch(headless=True)
                try:
                    page=browser.new_page()
                    def route_handler(route):
                        req=route.request
                        if req.is_navigation_request() and not allowed(req.url):route.abort()
                        elif req.resource_type in ('image','media','font'):route.abort()
                        else:route.continue_()
                    page.route('**/*',route_handler)
                    response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
                    if not response or not allowed(page.url):raise ProviderError('Unexpected redirect')
                    body=page.locator('body').inner_text(timeout=8000)
                    if response.status in (401,403,429) or re.search(r'captcha|verify you are human|access denied|pardon our interruption',page.title()+' '+body[:2000],re.I):raise Deferred('Access restricted; stop and review authorization')
                    if response.status>=400:raise ProviderError('HTTP '+str(response.status))
                    result={'url':page.url,'title':page.title(),'html':page.content(),'text':body[:100000],'links':page.locator('a[href]').evaluate_all('els=>els.slice(0,5000).map(e=>({url:e.href,title:(e.innerText||e.title||"").trim().slice(0,250)}))')}
                finally:browser.close()
            GATE.good('browser:'+host);return result
        except Exception as e:
            GATE.fail('browser:'+host,type(e).__name__,3600 if isinstance(e,Deferred) else 30);raise ProviderError('Browser '+host+' failed: '+type(e).__name__) from None

def request_text(url,provider,**kw):
    GATE.check(provider)
    try:r=requests.get(url,timeout=(10,30),allow_redirects=False,**kw)
    except requests.RequestException as e:
        GATE.fail(provider,type(e).__name__);raise ProviderError(provider+' transport error') from None
    if not 200<=r.status_code<300:
        GATE.fail(provider,'HTTP '+str(r.status_code),max(60 if r.status_code in (401,403,429) else 0,retry_after(r.headers.get('Retry-After'))));raise ProviderError(provider+' HTTP '+str(r.status_code))
    GATE.good(provider);return r.content
