"""Local update installer. Does not modify config.bat, start.bat, or the venv."""
import argparse,contextlib,datetime,os,shutil,socket,sqlite3,subprocess,sys
from pathlib import Path
FILES=('server.py','dealwatch.py','ebay_sales.py','intelligence.py','providers.py','auctions.py','learning.py','index.html','requirements.txt','requirements-test.txt','config.3.3.example.bat','README.md','FEATURES.md','TEST-RESULTS.txt','test_server.py','test_dealwatch.py','test_ebay_sales.py','test_33.py','test_browser.py','test_update.py','install_update.py')

def ensure_stopped():
    with socket.socket() as s:
        s.settimeout(.5)
        if s.connect_ex(('127.0.0.1',8765))==0:raise RuntimeError('Stop Retail Scout (Ctrl+C) before updating or rolling back')

def replace(src,dst):
    tmp=dst.with_name(dst.name+'.scout-update-tmp')
    try:shutil.copy2(src,tmp);os.replace(tmp,dst)
    finally:
        if tmp.exists():tmp.unlink()

def backup_db(target,backup):
    db=target/'scout.db'
    if db.exists():
        with contextlib.closing(sqlite3.connect(db,timeout=5)) as src,contextlib.closing(sqlite3.connect(backup/'scout.db')) as dest:src.backup(dest)

def apply(stage,target):
    if stage.resolve()==target.resolve():raise ValueError('Stage the update in a different folder')
    for n in ('server.py','config.bat','start.bat'):
        if not (target/n).is_file():raise FileNotFoundError('Target missing '+n)
    for n in FILES:
        if not (stage/n).is_file():raise FileNotFoundError('Update missing '+n)
    backup=target/'backups'/('pre-3.3-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'));backup.mkdir(parents=True);backup_db(target,backup)
    for n in FILES:
        if (target/n).is_file():shutil.copy2(target/n,backup/n)
    (backup/'absent.txt').write_text('\n'.join(n for n in FILES if not (target/n).exists()),encoding='utf-8')
    changed=[]
    try:
        for n in FILES:replace(stage/n,target/n);changed.append(n)
    except Exception:
        for n in reversed(changed):
            if (backup/n).is_file():replace(backup/n,target/n)
            elif (target/n).exists():(target/n).unlink()
        raise
    return backup

def rollback(target,backup):
    if not backup.is_dir() or backup.resolve().parent!=(target/'backups').resolve():raise ValueError('Choose a backup under the target backups folder')
    absent=(backup/'absent.txt').read_text(encoding='utf-8').splitlines()
    if any(n not in FILES for n in absent):raise ValueError('Invalid backup manifest')
    for n in FILES:
        if (backup/n).is_file():replace(backup/n,target/n)
        elif n in absent and (target/n).is_file():(target/n).unlink()
    # Deliberately never replace a live or newer database during code rollback.

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--target',required=True,type=Path);p.add_argument('--rollback',type=Path);args=p.parse_args();target=args.target.resolve();ensure_stopped()
    if args.rollback:
        rollback(target,args.rollback.resolve());print('Code restored. Database left unchanged.');sys.exit(0)
    stage=Path(__file__).resolve().parent
    print('Running offline and browser fixture tests before changing your installation...',flush=True)
    subprocess.run([sys.executable,'-m','unittest','discover','-v'],cwd=stage,check=True)
    backup=apply(stage,target);print('Update installed. Backup:',backup);print('Your config.bat, start.bat, virtual environment and database were not replaced. Double-click start.bat to launch.')
