import unittest,tempfile,time,os
from unittest.mock import patch
import amazon_import as imp,amazon_research as a,server as s
class Pipeline(unittest.TestCase):
 def test_import_cache_and_suspension(self):
    with tempfile.TemporaryDirectory() as d:
        db=d+'/db';a.suspend(db,'existing restriction');p={'name':'Bosch GT3000 8 piece'};url='https://www.amazon.com/dp/B001GNC8RS';raw={'title':'Bosch GT3000 8 pc set','price':'$25.99'};r=a.evaluate(raw,p,url);report={'mode':'offline replay; zero Amazon requests','results':[{'requested':p['name'],'url':url,'extraction':raw,'result':r}]};self.assertEqual(imp.import_report(db,report)[0]['status'],'imported');imp.import_report(db,report);self.assertEqual(len(a.history(db)),1);self.assertEqual(a.blocked(db),'existing restriction');self.assertEqual(a.research(p,db)['amazon_price'],25.99);self.assertEqual(a.research(p,db)['amazon_origin'],'offline_import');self.assertEqual(a.cached(db,dict(name='Bosch GT3000',url=url))['amazon_price'],25.99)
        with patch.object(s,'DB',db),patch.dict(os.environ,{'SCOUT_PRICING_MODE':'amazon','SCOUT_DEAL_MODE':'amazon'}):
            self.assertEqual(s.pricing(p)['amazon_price'],25.99)
 def test_old_observation(self):
    with tempfile.TemporaryDirectory() as d:
        p={'name':'Bosch GT3000'};r=a.evaluate({'title':'Bosch GT3000','price':'$25.99'},p,'https://www.amazon.com/dp/B001GNC8RS');r['amazon_checked_at']=time.time()-90000;a.store(d+'/db',p,r);self.assertIsNone(a.cached(d+'/db',p))
 def test_bad_import(self):
    with tempfile.TemporaryDirectory() as d:
        self.assertEqual(imp.import_report(d+'/db',{'mode':'offline replay; zero Amazon requests','results':[{}]})[0]['status'],'rejected')
 def test_official_offer(self):
    import amazon_spapi as api
    asin='B001GNC8RS';d={'payload':{'status':'Success','ASIN':asin,'Identifier':{'MarketplaceId':api.MARKET,'ItemCondition':'New'},'Offers':[{'SubCondition':'New','ListingPrice':{'CurrencyCode':'USD','Amount':25.99},'Shipping':{'CurrencyCode':'USD','Amount':0}},{'SubCondition':'Used','ListingPrice':{'CurrencyCode':'USD','Amount':1},'Shipping':{'CurrencyCode':'USD','Amount':0}}]}}
    self.assertEqual(api.offer_price(d,asin),25.99);self.assertIsNone(api.offer_price(d,'B000000000'))
 def test_official_catalog(self):
    import amazon_spapi as api
    items=[{'asin':'B001GNC8RS','summaries':[{'marketplaceId':api.MARKET,'itemName':'Bosch GT3000 8 pc set'}]}];self.assertEqual(api.select(items,{'name':'Bosch GT3000 8 piece'})[0],'B001GNC8RS');self.assertIsNone(api.select(items,{'name':'Bosch GT3000 4 piece'}))
 def test_official_opt_in(self):
    import amazon_spapi as api
    with patch.dict(os.environ,{'SCOUT_SPAPI_AUTHORIZED':'0'}),patch.object(api.requests,'request') as req:
        self.assertFalse(api.enabled());self.assertIn('not configured',api.research({'name':'Bosch GT3000'})['amazon_status']);req.assert_not_called()
 def test_circular_acquisition(self):
    self.assertTrue(s.amazon_acquisition({'lead_url':'https://slickdeals.net/f/product-at-amazon-25'}));self.assertTrue(s.amazon_acquisition({'retailer_url':'https://amzn.to/example'}));self.assertFalse(s.amazon_acquisition({'url':'https://www.target.com/p/example'}))

 def test_paused_queue(self):
    with tempfile.TemporaryDirectory() as d,patch.object(s,'DB',d+'/db'),patch.dict(os.environ,{'SCOUT_PRICING_MODE':'amazon','SCOUT_DEAL_MODE':'amazon','SCOUT_SPAPI_AUTHORIZED':'0','SCOUT_AMAZON_AUTHORIZED':'1','SCOUT_RSS':'0','BESTBUY_API_KEY':''}):
        s.init();a.suspend(s.DB,'review');s.LIVE.mode='running';s.save('source',{'name':'Fixture','url':'https://example.com','category':'feed'})
        with patch.object(s,'fetch_json',return_value={'products':[{'name':'Test Widget','cost':20,'url':'https://example.com/p/widget'}]}),patch.object(s,'evaluate_deal') as e,patch.object(s,'watch_once'):
            s.monitor_once();e.assert_not_called();self.assertEqual(len(s.pending_discovery()),1);self.assertEqual(s.LIVE.snapshot()['pricing_deferred'],1)
