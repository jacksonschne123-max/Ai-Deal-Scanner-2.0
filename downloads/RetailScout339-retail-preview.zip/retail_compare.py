"""Retail price comparison, not resale valuation. Only configured data APIs; no browser scraping.
Search observations are candidates, not inventory verification. Local quota is conservative.
"""
import os,re,time,json,sqlite3,math,threading,datetime
from contextlib import closing
from pathlib import Path
from urllib.parse import urlencode,urlparse
import requests,providers,ebay_sales,identity_research as ids,activity
LOCK=threading.RLock()
TTL=3600
SHOP='Shopping search API'; BB='Best Buy catalog API'
KEYS={SHOP:'SCOUT_SHOPPING_API_KEY',BB:'BESTBUY_API_KEY'}
SETTINGS=Path(__file__).resolve().parent/'retail_settings.local.json'
BB_CACHE={}
ACCOUNT={}
def configured_key(provider):
    value=os.getenv(KEYS[provider],'')
    if value:return value.strip()
    try:
        d=json.loads(SETTINGS.read_text(encoding='utf-8'));value=d.get(KEYS[provider],'')
        return value.strip() if isinstance(value,str) else ''
    except (OSError,ValueError,AttributeError):return ''

def free_account(key):
    """Only non-sensitive fields are returned; never log the API's echoed key or email."""
    try:
        r=requests.get('https://serpapi.com/account.json',params={'api_key':key},timeout=(5,12),allow_redirects=False)
        if r.status_code!=200:return {'ok':False,'reason':'Account check HTTP '+str(r.status_code)}
        d=r.json();name=str(d.get('plan_name','')).lower();pid=str(d.get('plan_id','')).lower();cost=d.get('plan_monthly_price');left=d.get('plan_searches_left')
        free=(name in ('free','free plan') or pid=='free') and (cost is None or float(cost)==0)
        if not free or isinstance(left,bool) or not isinstance(left,(int,float)) or not math.isfinite(left):return {'ok':False,'reason':'Free plan or remaining quota not confirmed'}
        return {'ok':True,'remaining':max(0,int(left)),'limit':d.get('searches_per_month'),'reason':'Free plan confirmed'}
    except (requests.RequestException,ValueError,TypeError,AttributeError):return {'ok':False,'reason':'Account check failed'}

def free_credit(key):
    # Verify actual account plan and remaining provider quota, not just local counter.
    # Scope cache to the key hash, never expose it. Call within LOCK.
    import hashlib
    h=hashlib.sha256(key.encode()).hexdigest();now=time.time();a=ACCOUNT.get(h)
    if not a or now-a['stamp']>60:
        a=dict(free_account(key),stamp=now);ACCOUNT.clear();ACCOUNT[h]=a
    if not a.get('ok') or a.get('remaining',0)<=0:return False,a.get('reason','No free credits') if not a.get('ok') else 'Provider free quota exhausted'
    a['remaining']-=1;return True,'Free credit reserved'

STOPWORDS=set('the a an and or with w in of for by to on series new free shipping sale deal prime members member only'.split())
BAD=re.compile(r'\b(?:refurbished|renewed|pre[- ]owned|used|open[- ]box|for parts|compatible with|replacement|case only|box only|empty box|screen protector|protective case|replacement filter|monthly payment|installments?)\b',re.I)

def mode():return os.getenv('SCOUT_PRICING_MODE','retail')!='legacy' and os.getenv('SCOUT_DEAL_MODE','retail')=='retail'
def inferred_model(p):
    # Only distinctive printed model codes, not sizes or marketing specs.
    a=re.findall(r'\b[A-Z][A-Z0-9-]{4,24}\b',str(p.get('name') or ''))
    a=[v for v in a if sum(c.isdigit() for c in v)>=3 and sum(c.isalpha() for c in v)>=2 and not re.fullmatch(r'(?:DDR|USB|HDMI|RTX|GTX|RX|PCIE)[-0-9A-Z]+',v)]
    return a[0] if len(a)==1 else ''
def query(p):
    q=ebay_sales.identity(p) or ids.clean(p.get('name',''))
    q=re.sub(r'^(?:Prime(?: Members)?|Members Only)\s*:\s*','',q,flags=re.I)
    q=re.sub(r'\s+(?:free shipping|at amazon|at walmart|at best buy)\s*$','',q,flags=re.I)
    return q.strip()[:180] if len(re.findall(r'\w+',q))>=2 or ebay_sales.valid_upc(q) else ''
def tokens(s):
    s=re.sub(r'\b(\d+)\s*[- ]?\s*(?:pcs?|pieces?|count|ct|pack|pk)\b',r'\1pack',str(s).lower())
    s=re.sub(r'\b(\d+)\s*[- ]?\s*(?:inches|inch|in)\b',r'\1inch',s)
    s=re.sub(r'\b(\d+(?:\.\d+)?)\s*[- ]?\s*(gb|tb|hz|oz|ml|w|qt|cups?)\b',lambda m:m[1].replace('.','p')+m[2].removesuffix('s'),s)
    s=re.sub(r'(\d+)\s*"',r'\1inch',s)
    return set(re.findall(r'[a-z0-9]+',s))-STOPWORDS

def identity_key(p):
    return '|'.join([query(p).casefold(), ' '.join(sorted(tokens(p.get('name','')))),str(p.get('upc') or ''),str(p.get('model') or '').casefold()])
def price(x):
    if isinstance(x,bool):return None
    try:v=float(x);return round(v,2) if math.isfinite(v) and 0<v<1000000 else None
    except (ValueError,TypeError):return None

def match(p,title,upc='',model='',brand=''):
    if not isinstance(title,str) or BAD.search(title):return None
    original=str(p.get('name') or ''); a,b=tokens(original),tokens(title)
    if not a or not b:return None
    u=str(p.get('upc') or '')
    if ebay_sales.valid_upc(u) and ebay_sales.valid_upc(str(upc)):
        if u.zfill(14)!=str(upc).zfill(14):return None
        return 'UPC match'
    m=str(p.get('model') or inferred_model(p)).strip().lower(); br=str(p.get('brand') or '').lower()
    if m and len(m)>=4 and model and re.sub(r'\W','',m)!=re.sub(r'\W','',str(model).lower()):return None
    # Require numeric/variant tokens, and reject explicitly conflicting pack/capacity/size.
    nums={t for t in a if any(c.isdigit() for c in t)}
    modelhit=bool(m and len(m)>=5 and (m in title.lower().split() or re.sub(r'\W','',m)==re.sub(r'\W','',str(model).lower())))
    if not nums<=b and not modelhit:return None
    if re.search(r'\b(?:bundle|lot of|multipack)\b',title,re.I) and not re.search(r'\b(?:bundle|lot of|multipack)\b',original,re.I):return None
    for suffix in ('pack','inch','gb','tb','hz','oz','ml','w','qt','cup'):
        av={t for t in a if re.fullmatch(r'\d+(?:p\d+)?'+suffix,t)};bv={t for t in b if re.fullmatch(r'\d+(?:p\d+)?'+suffix,t)}
        if av and bv and av!=bv:return None
        if suffix=='pack' and bv and not av and any(x!='1pack' for x in bv):return None
    if m and br and model and re.sub(r'\W','',m)==re.sub(r'\W','',str(model).lower()) and tokens(br)<=tokens(title+' '+str(brand)):
        return 'Model match — confirm variant'
    if modelhit and len(a&b)>=2:return 'Model token match — confirm variant'
    if len(a)<3 or len(a&b)/len(a)<.80:return None
    # Title-only comparisons are never treated as confirmed.
    return 'Title candidate — confirm variant'

def url_ok(u):return isinstance(u,str) and providers.public_url(u) and len(u)<=2048 and not re.search(r'\.(?:jpg|jpeg|png|webp|gif|pdf|svg)$',urlparse(u).path,re.I)

def offer(title,merchant,value,url,match_type,source,stock,condition,shipping=None,link_kind='retailer',stamp=None):
    value=price(value)
    if not value or not url_ok(url) or not match_type or not isinstance(merchant,str) or not merchant.strip():return None
    return dict(title=str(title)[:300],merchant=str(merchant)[:100],price=value,url=url,match=match_type,provider=source,stock=stock,condition=condition,shipping=shipping,link_kind=link_kind,checked_at=time.time() if stamp is None else stamp)

def shopping_offers(data,p):
    if not isinstance(data,dict) or data.get('error'):return []
    meta=data.get('search_metadata') or {}
    if meta.get('status')!='Success':return []
    out=[]
    for x in (data.get('shopping_results') or [])[:50]:
        if not isinstance(x,dict):continue
        t=x.get('title','');m=match(p,t);txt=' '.join(str(x.get(k,'')) for k in ('price','second_hand_condition','extensions','delivery','tag'))
        if x.get('second_hand_condition') or x.get('installment') or x.get('alternative_price') or BAD.search(txt) or re.search(r'\b(?:out of stock|sold out|unavailable|per month|\/mo|from \$)\b',txt,re.I):continue
        display=str(x.get('price',''));v=price(x.get('extracted_price'))
        if not re.fullmatch(r'\$\s*[\d,]+(?:\.\d{2})?',display.strip()) or price(display.replace('$','').replace(',','').strip())!=v:continue
        u=x.get('link') or x.get('product_link');
        if not url_ok(u):continue
        host=urlparse(u or '').hostname or ''
        kind='shopping result' if host=='google.com' or host.endswith('.google.com') else 'retailer candidate'
        o=offer(t,x.get('source',''),v,u,m,SHOP,'Stock unconfirmed','Condition unconfirmed',link_kind=kind)
        if o:out.append(o)
    return out

def bestbuy_offers(data,p):
    out=[]
    for x in (data.get('products') or [])[:50]:
        if not isinstance(x,dict) or x.get('onlineAvailability') is not True:continue
        u=x.get('url','');
        if not url_ok(u):continue
        host=urlparse(u).hostname
        if host not in ('bestbuy.com','www.bestbuy.com') or not re.search(r'/site/|/product/',urlparse(u).path):continue
        t=x.get('name','');m=match(p,t,str(x.get('upc') or ''),str(x.get('modelNumber') or ''),str(x.get('manufacturer') or ''))
        if x.get('condition') and str(x['condition']).lower()!='new':continue
        if x.get('type') and str(x['type']).lower()!='hardgood':continue
        o=offer(t,'Best Buy',x.get('salePrice'),u,m,BB,'Online available (API)','New catalog item; confirm condition',link_kind='retailer')
        if o:out.append(o)
    return out

def setup(c):
    c.executescript('''CREATE TABLE IF NOT EXISTS retail_queries(key TEXT,provider TEXT,stamp REAL,data TEXT,PRIMARY KEY(key,provider));CREATE TABLE IF NOT EXISTS retail_usage(id INTEGER PRIMARY KEY,provider TEXT,stamp REAL);CREATE TABLE IF NOT EXISTS retail_holds(provider TEXT PRIMARY KEY,reason TEXT,until REAL);CREATE TABLE IF NOT EXISTS retail_manual(key TEXT,url TEXT,stamp REAL,data TEXT,PRIMARY KEY(key,url));''')
def connect(db):
    c=sqlite3.connect(db,timeout=15);setup(c);return c

def limits():
    def bound(k,default,maximum):
        try:return max(0,min(maximum,int(os.getenv(k,str(default)))))
        except ValueError:return default
    return bound('SCOUT_SHOPPING_MONTHLY',200,250),bound('SCOUT_SHOPPING_DAILY',8,25)
def counts(c):
    now=datetime.datetime.now(datetime.timezone.utc); day=now.replace(hour=0,minute=0,second=0,microsecond=0).timestamp(); month=now.replace(day=1,hour=0,minute=0,second=0,microsecond=0).timestamp()
    return tuple(c.execute('SELECT COUNT(*) FROM retail_usage WHERE provider=? AND stamp>=?',(SHOP,t)).fetchone()[0] for t in (month,day))
def health(db):
    with closing(connect(db)) as c:
        m,d=counts(c);ml,dl=limits();holds={r[0]:{'reason':r[1],'retry_at':r[2] or None} for r in c.execute('SELECT provider,reason,until FROM retail_holds WHERE until=0 OR until>?',(time.time(),))}
        return {'shopping_configured':bool(configured_key(SHOP)),'bestbuy_configured':bool(configured_key(BB)),'monthly_used':m,'monthly_limit':ml,'daily_used':d,'daily_limit':dl,'holds':holds,'mode':'Retail comparison; no Amazon/eBay browser required'}
def available(db):
    h=health(db);return (h['bestbuy_configured'] and BB not in h['holds']) or (h['shopping_configured'] and SHOP not in h['holds'] and h['monthly_used']<h['monthly_limit'] and h['daily_used']<h['daily_limit'])
def hold(c,provider,reason,seconds):
    c.execute('INSERT OR REPLACE INTO retail_holds VALUES(?,?,?)',(provider,reason,time.time()+seconds if seconds else 0));c.commit()

def reserve(c,key):
    # The configured cap counts all attempted calls (even failed ones).
    c.execute('BEGIN IMMEDIATE');m,d=counts(c);ml,dl=limits()
    if m>=ml or d>=dl:c.rollback();return False
    # No provider request while database transaction is open.
    c.execute('INSERT INTO retail_usage(provider,stamp) VALUES(?,?)',(SHOP,time.time()));c.commit();return True

def store_offers(data,p):
    if not isinstance(data,dict) or data.get('error') or (data.get('search_metadata') or {}).get('status')!='Success':return []
    result=data.get('product_results') or {}
    if not isinstance(result,dict):return []
    out=[]
    for x in (result.get('stores') or [])[:30]:
        if not isinstance(x,dict):continue
        t=x.get('title','');m=match(p,t);detail=' '.join(str(y) for y in (x.get('details_and_offers') or []));u=x.get('link','');
        if not isinstance(t,str) or not url_ok(u):continue
        host=urlparse(u or '').hostname or ''
        if not host or len(urlparse(u).path.strip('/'))<3 or host=='google.com' or host.endswith('.google.com') or host=='serpapi.com':continue
        if x.get('second_hand_condition') or x.get('installment') or BAD.search(t+' '+detail) or re.search(r'\b(?:out of stock|sold out|unavailable|preorder|pre-order)\b',detail,re.I):continue
        if not re.search(r'\bin stock online\b',detail,re.I):continue
        v=price(x.get('extracted_price'));display=str(x.get('price','')).strip()
        if not re.fullmatch(r'\$\s*[\d,]+(?:\.\d{2})?',display) or price(display.replace('$','').replace(',','').strip())!=v:continue
        ship=x.get('shipping_extracted');ship=0 if ship==0 or str(x.get('shipping','')).lower()=='free' else price(ship)
        o=offer(t,x.get('name',''),v,u,m,SHOP,'Online in stock (shopping report)','Condition unconfirmed',shipping=ship)
        if o:out.append(o)
    return out

def fetch(c,provider,p):
    key=configured_key(provider);q=query(p)
    if not key or not q:return [],'Not configured or no usable identity'
    row=c.execute('SELECT reason,until FROM retail_holds WHERE provider=?',(provider,)).fetchone()
    if row and (not row[1] or row[1]>time.time()):return [],row[0]
    if provider==SHOP:
        if not reserve(c,key):return [],'Free quota reserved for later; no request made'
        ok,reason=free_credit(key)
        if not ok:hold(c,SHOP,reason,900);return [],reason
        endpoint='https://serpapi.com/search.json';params={'engine':'google_shopping','q':q,'gl':'us','hl':'en','api_key':key,'no_cache':'true'}
        # Reserve before request, including errors. No retry loop, no automatic paid upgrades.
    else:
        if not (ebay_sales.valid_upc(str(p.get('upc') or '')) or re.search(r'\b(?:monitor|laptop|computer|tablet|phone|airpods|headphones|earbuds|camera|television|tv|gaming|speaker|soundbar|sound bar|charger|processor|ryzen|intel|ssd|router|microphone|coffee maker|espresso|air fryer|vacuum|appliance)\b',q,re.I)):return [],'Outside Best Buy catalog focus'
        if ebay_sales.valid_upc(str(p.get('upc') or '')):filter_='upc='+str(p['upc'])
        else:
            terms=re.findall(r'[A-Za-z0-9-]+',q)[:8]
            if not terms:return [],'No usable identity'
            filter_='&'.join('search='+v for v in terms)
        endpoint='https://api.bestbuy.com/v1/products('+filter_+'&onlineAvailability=true)';params={'apiKey':key,'format':'json','show':'sku,name,upc,modelNumber,manufacturer,salePrice,url,onlineAvailability','pageSize':25}
    activity.emit('retail lookup',engine='retail',product=p.get('name'),message=provider)
    try:
        r=requests.get(endpoint,params=params,timeout=(5,15),allow_redirects=False)
        if r.status_code in (401,403):hold(c,provider,'HTTP '+str(r.status_code)+' — review authorization',0);return [],'Authorization review required'
        if r.status_code in (429,500,502,503,504):
            delay=max(900 if r.status_code==429 else 120,providers.retry_after(r.headers.get('Retry-After')));hold(c,provider,'HTTP '+str(r.status_code)+' — cooldown',delay);return [],'Provider cooldown'
        if r.status_code!=200:hold(c,provider,'HTTP '+str(r.status_code),300);return [],'Provider error'
        data=r.json()
        if not isinstance(data,dict) or data.get('error') or (provider==SHOP and (data.get('search_metadata') or {}).get('status')!='Success'):
            hold(c,provider,'API response incomplete or error',900);return [],'API response error'
        offers=shopping_offers(data,p) if provider==SHOP else bestbuy_offers(data,p)
        # Spend a second free credit only for one matching product group with a valid token.
        if provider==SHOP and offers and os.getenv('SCOUT_SHOPPING_DETAILS','1')=='1':
            matches=[x for x in (data.get('shopping_results') or [])[:50] if isinstance(x,dict) and match(p,x.get('title','')) and isinstance(x.get('immersive_product_page_token'),str) and 10<len(x['immersive_product_page_token'])<6000 and not x.get('second_hand_condition')]
            exact=[x for x in matches if tokens(x['title'])==tokens(p.get('name',''))];candidates=exact or matches
            groups={str(x.get('product_id') or x['immersive_product_page_token']):x for x in candidates}
            if len(groups)==1 and reserve(c,key) and free_credit(key)[0]:
                x=next(iter(groups.values()))
                try:detail=requests.get('https://serpapi.com/search.json',params={'engine':'google_immersive_product','page_token':x['immersive_product_page_token'],'more_stores':'true','api_key':key,'no_cache':'true'},timeout=(5,15),allow_redirects=False)
                except (requests.RequestException,ValueError,TypeError):
                    hold(c,SHOP,'Store detail transport error',300);return offers,'Advertised offers; detail unavailable'
                if detail.status_code in (401,403):hold(c,SHOP,'HTTP '+str(detail.status_code)+' — review authorization',0)
                elif detail.status_code in (429,500,502,503,504):hold(c,SHOP,'HTTP '+str(detail.status_code)+' — cooldown',max(900,providers.retry_after(detail.headers.get('Retry-After'))))
                elif detail.status_code==200:
                    try:direct=store_offers(detail.json(),p)
                    except (ValueError,TypeError,AttributeError):direct=[]
                    if direct:offers=direct+offers
        return offers,'Offers returned' if offers else 'No sufficiently matching offers'
    except (requests.RequestException,ValueError,TypeError):hold(c,provider,'Transport or response error',300);return [],'Transport or response error'

def manual(db,p,data):
    if data.get('confirmed') is not True:raise ValueError('Confirm exact variant, new condition and purchasable listing')
    u=data.get('url');host=urlparse(str(u)).hostname or ''
    if not url_ok(u) or host in ('google.com','www.google.com','serpapi.com') or len(urlparse(u).path.strip('/'))<3:raise ValueError('Enter a direct HTTPS retailer product link')
    o=offer(data.get('title') or p.get('name'),data.get('merchant'),data.get('price'),u,'User confirmed exact variant','Manual check','User reported available','User reported new',shipping=price(data.get('shipping')) if data.get('shipping')!=0 else 0)
    if not o:raise ValueError('Enter a merchant, price and direct product link')
    with LOCK,closing(connect(db)) as c,c:c.execute('INSERT OR REPLACE INTO retail_manual VALUES(?,?,?,?)',(identity_key(p),u,o['checked_at'],json.dumps(o)))
    return o

def same_seller(p,o):
    merchant=re.sub(r'[^a-z0-9]','',str(o.get('merchant','')).lower()).removesuffix('com')
    store=re.sub(r'[^a-z0-9]','',str(p.get('store','')).lower()).removesuffix('com')
    host=(urlparse(o.get('url','')).hostname or '').removeprefix('www.')
    for k in ('retailer_url','url'):
        u=p.get(k) or '';h=(urlparse(u).hostname or '').removeprefix('www.')
        if u and (u.split('?')[0]==o.get('url','').split('?')[0] or (h==host and o.get('link_kind')=='retailer')):return True
    return bool(store and merchant and (store==merchant or (len(merchant)>3 and merchant in store)))
def summarize(p,offers,now=None):
    now=time.time() if now is None else now;cost=price(p.get('cost'));fresh=[];seen=set()
    for o in offers:
        if not price(o.get('price')) or not 0<=now-o.get('checked_at',0)<=TTL or same_seller(p,o):continue
        k=(o['merchant'].lower(),o['url'],o['price'])
        if k not in seen:fresh.append(o);seen.add(k)
    fresh.sort(key=lambda o:(o['price'],o['link_kind']!='retailer'));verified=[o for o in fresh if o['match'] in ('UPC match','User confirmed exact variant') and o['stock'] in ('Online available (API)','User reported available')]
    direct=[o for o in fresh if o['link_kind']=='retailer' and o['stock'] in ('Online available (API)','User reported available','Online in stock (shopping report)')];chosen=(direct or fresh or [None])[0];out={'retail_lower_unverified':None,'retail_offers':fresh[:20],'retail_reference_price':None,'retail_reference_merchant':None,'retail_reference_url':None,'retail_reference_checked_at':None,'retail_reference_shipping':None,'retail_reference_stock':None,'retail_reference_match':None,'retail_reference_link_kind':None,'retail_savings':None,'retail_discount_pct':None,'retail_reference_verified':False,'retail_status':'No fresh matching comparison','retail_search_url':'https://www.google.com/search?'+urlencode({'tbm':'shop','q':query(p) or p.get('name','')})}
    if chosen:
        v=chosen['price'];out.update(retail_reference_price=v,retail_reference_merchant=chosen['merchant'],retail_reference_url=chosen['url'],retail_reference_verified=chosen in verified,retail_reference_checked_at=chosen['checked_at'],retail_reference_shipping=chosen.get('shipping'),retail_reference_stock=chosen.get('stock'),retail_reference_match=chosen.get('match'),retail_reference_link_kind=chosen.get('link_kind'),retail_status='Comparable offer reported available' if chosen in verified else 'Reported online stock — verify exact variant and condition' if chosen in direct else 'Advertised candidate — verify variant and stock',retail_savings=round(v-cost,2) if cost else None,retail_discount_pct=round(100*(v-cost)/v,2) if cost else None)
        out['retail_lower_unverified']=fresh[0]['price'] if fresh and fresh[0]['price']<v else None
    return out

def research(db,p,allow_network=True):
    q=query(p);offers=[];statuses={};key=identity_key(p)
    with LOCK,closing(connect(db)) as c:
        c.execute('DELETE FROM retail_queries WHERE stamp<?',(time.time()-TTL,));c.commit()
        offers.extend(json.loads(x[0]) for x in c.execute('SELECT data FROM retail_manual WHERE key=? AND stamp>=?',(key,time.time()-TTL)))
        for provider in (BB,SHOP):
            row=BB_CACHE.get((str(db),key)) if provider==BB else c.execute('SELECT stamp,data FROM retail_queries WHERE key=? AND provider=?',(key,provider)).fetchone()
            if row and 0<=time.time()-row[0]<=TTL:
                offers.extend(json.loads(row[1]));statuses[provider]='Cached comparison';continue
            if not allow_network or not configured_key(provider) or not q:continue
            result,state=fetch(c,provider,p);statuses[provider]=state;offers.extend(result)
            if state in ('Offers returned','No sufficiently matching offers'):
                if provider==BB:
                    for k,v in list(BB_CACHE.items()):
                        if time.time()-v[0]>TTL:BB_CACHE.pop(k,None)
                    BB_CACHE[(str(db),key)]=(time.time(),json.dumps(result))
                else:c.execute('INSERT OR REPLACE INTO retail_queries VALUES(?,?,?,?)',(key,provider,time.time(),json.dumps(result)));c.commit()
    r=summarize(p,offers);r['retail_provider_status']=statuses;return r

def views(db,items):
    """Bulk cache read, no provider network requests and no repeated SQLite calls per card."""
    from collections import defaultdict
    bykey=defaultdict(list);now=time.time()
    with closing(connect(db)) as c:
        for k,raw in c.execute('SELECT key,data FROM retail_queries WHERE stamp>=? AND provider=?',(now-TTL,SHOP)):
            bykey[k].extend(json.loads(raw))
        for k,raw in c.execute('SELECT key,data FROM retail_manual WHERE stamp>=?',(now-TTL,)):
            bykey[k].append(json.loads(raw))
    for (d,k),(stamp,raw) in list(BB_CACHE.items()):
        if now-stamp>TTL:BB_CACHE.pop((d,k),None)
        elif d==str(db):bykey[k].extend(json.loads(raw))
    for p in items:
        p.update(summarize(p,bykey[identity_key(p)],now));p['assessment']=assessment(p)
    return items

def assessment(p):
    if p.get('posted') and time.time()-p['posted']>72*3600:return 'Rejected — stale deal lead'
    if p.get('stock')=='Unavailable':return 'Rejected — deal unavailable'
    if p.get('retail_reference_price') is None:return 'Awaiting retail comparison'
    if not p.get('retail_reference_verified'):return 'Price candidate — verify exact item and availability'
    gap=p.get('retail_savings')
    if gap is None:return 'Deal price unknown'
    if gap<=0:return 'No savings against available comparison'
    return 'Potential savings — verify deal price and checkout' if not p.get('price_verified') else 'Savings indicated — verify checkout'
