"""Contract fixtures, API pipeline and browser UI, with no live provider calls."""
import os,unittest,tempfile,time,json,sqlite3
from unittest.mock import patch,Mock
from pathlib import Path
from contextlib import closing
from fastapi.testclient import TestClient
import retail_compare as r,server as s,amazon_research as ar

P={'name':'Alienware AW2725D 27 inch 280Hz QD-OLED gaming monitor','brand':'Alienware','model':'AW2725D','cost':350,'store':'Slickdeals RSS main','url':'https://slickdeals.net/f/fixture','posted':time.time()}
TITLE=P['name']
DIRECT='https://www.dell.com/en-us/shop/monitors/apd/alienware-aw2725d/aw2725d_monitor/-'

def resp(data=None,status=200,headers=None):
    return Mock(status_code=status,headers=headers or {},json=Mock(return_value=data or {}))
def account(left=250):return resp({'plan_id':'free','plan_name':'Free Plan','plan_monthly_price':0,'plan_searches_left':left,'searches_per_month':250,'api_key':'do-not-print','account_email':'secret@example.com'})
def search(price=349.99,title=TITLE,**extra):
    return {'search_metadata':{'status':'Success'},'shopping_results':[dict(title=title,source='Dell',price='$'+str(price),extracted_price=price,product_id='123',product_link='https://www.google.com/shopping/product/123',**extra)]}
def detail(price=349.99,title=TITLE,**extra):
    x=dict(name='Dell',title=title,link=DIRECT,price='$'+str(price),extracted_price=price,details_and_offers=['In stock online','Free delivery'],shipping='Free');x.update(extra);return {'search_metadata':{'status':'Success'},'product_results':{'stores':[x]}}

class Retail(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.db=self.tmp.name+'/scout.db';self.addCleanup(r.ACCOUNT.clear);self.addCleanup(r.BB_CACHE.clear);r.ACCOUNT.clear();r.BB_CACHE.clear()
        self.env=patch.dict(os.environ,{'SCOUT_DEAL_MODE':'retail','SCOUT_PRICING_MODE':'amazon','SCOUT_SHOPPING_API_KEY':'','BESTBUY_API_KEY':'','SCOUT_SHOPPING_MONTHLY':'200','SCOUT_SHOPPING_DAILY':'8','SCOUT_SHOPPING_DETAILS':'1','SCOUT_RSS':'0','SCOUT_AMAZON_AUTHORIZED':'0','SCOUT_SPAPI_AUTHORIZED':'0'});self.env.start();self.addCleanup(self.env.stop)
        self.settings=patch.object(r,'SETTINGS',Path(self.tmp.name)/'settings.json');self.settings.start();self.addCleanup(self.settings.stop)
    def test_no_keys(self):
        with patch.object(r.requests,'get') as g:
            v=r.research(self.db,P);g.assert_not_called();self.assertIsNone(v['retail_reference_price']);self.assertIn('tbm=shop',v['retail_search_url']);self.assertFalse(r.available(self.db))
    def test_shopping_contract(self):
        o=r.shopping_offers(search(),P);self.assertEqual(len(o),1);self.assertEqual(o[0]['price'],349.99);self.assertEqual(o[0]['link_kind'],'shopping result');self.assertIn('unconfirmed',o[0]['stock'])
    def test_wrong_model(self):self.assertEqual(r.shopping_offers(search(title=TITLE.replace('AW2725D','AW2725Q')),P),[])
    def test_wrong_refresh(self):self.assertEqual(r.shopping_offers(search(title=TITLE.replace('280Hz','240Hz')),P),[])
    def test_wrong_condition(self):
        self.assertEqual(r.shopping_offers(search(title='Refurbished '+TITLE),P),[]);self.assertEqual(r.shopping_offers(search(second_hand_condition='Used'),P),[])
    def test_installment_or_range(self):
        self.assertEqual(r.shopping_offers(search(installment={'months':12}),P),[]);d=search();d['shopping_results'][0]['price']='$300–$500';self.assertEqual(r.shopping_offers(d,P),[])
    def test_missing_currency_or_link(self):
        d=search();d['shopping_results'][0]['price']='€349.99';self.assertEqual(r.shopping_offers(d,P),[]);d=search();d['shopping_results'][0]['product_link']='http://localhost:8765';self.assertEqual(r.shopping_offers(d,P),[])
    def test_store_detail(self):
        offers=r.store_offers(detail(),P);self.assertEqual(len(offers),1);self.assertEqual(offers[0]['shipping'],0);self.assertEqual(offers[0]['url'],DIRECT);self.assertEqual(offers[0]['stock'],'Online in stock (shopping report)')
    def test_unavailable_store(self):self.assertEqual(r.store_offers(detail(details_and_offers=['Out of stock']),P),[])
    def test_pack_variant(self):
        p={'name':'Craftsman 35-Pc steel screwdriver bit set'};self.assertIsNotNone(r.match(p,'Craftsman 35 piece steel screwdriver bit set'));self.assertIsNone(r.match(p,'Craftsman 20 piece steel screwdriver bit set'));self.assertIsNone(r.match({'name':'Craftsman steel screwdriver bit set'},'Craftsman 3 pack steel screwdriver bit set'))
    def test_same_seller_excluded(self):
        o=r.store_offers(detail(),P);self.assertIsNone(r.summarize(dict(P,retailer_url=DIRECT),o)['retail_reference_price']);self.assertIsNone(r.summarize(dict(P,store='Dell'),o)['retail_reference_price'])
    def test_price_difference(self):
        out=r.summarize(P,r.store_offers(detail(),P));self.assertEqual(out['retail_savings'],-.01);self.assertFalse(out['retail_reference_verified']);self.assertIn('Reported online',out['retail_status'])
    def test_lower_candidate_shown(self):
        out=r.summarize(P,r.store_offers(detail(349.99),P)+r.shopping_offers(search(299.99),P));self.assertEqual(out['retail_reference_price'],349.99);self.assertEqual(out['retail_lower_unverified'],299.99)
    def test_manual_roundtrip(self):
        o=r.manual(self.db,P,{'merchant':'Dell','url':DIRECT,'price':399.99,'shipping':0,'confirmed':True});self.assertEqual(o['shipping'],0);v=r.research(self.db,P,False);self.assertEqual(v['retail_savings'],49.99);self.assertTrue(v['retail_reference_verified']);self.assertIn('Potential savings',r.assessment(dict(P,**v)))
    def test_bad_manual(self):
        with self.assertRaises(ValueError):r.manual(self.db,P,{'merchant':'Dell','url':DIRECT,'price':-1,'confirmed':True})
        with self.assertRaises(ValueError):r.manual(self.db,P,{'merchant':'Dell','url':DIRECT,'price':100})
        with self.assertRaises(ValueError):r.manual(self.db,P,{'merchant':None,'url':DIRECT,'price':100,'confirmed':True})
    def test_expiry(self):
        o=r.store_offers(detail(),P);o[0]['checked_at']=time.time()-3601;self.assertIsNone(r.summarize(P,o)['retail_reference_price'])
    def test_api_pipeline_and_cache(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key','SCOUT_SHOPPING_DETAILS':'1'}),patch.object(r.requests,'get',side_effect=[account(),resp(search(349.99,immersive_product_page_token='A'*50)),resp(detail())]) as g:
            a=r.research(self.db,P);self.assertEqual(a['retail_reference_price'],349.99);self.assertEqual(a['retail_reference_url'],DIRECT);self.assertEqual(g.call_count,3);self.assertEqual(r.health(self.db)['monthly_used'],2);self.assertEqual(r.research(self.db,P)['retail_reference_price'],349.99);self.assertEqual(g.call_count,3);self.assertNotIn('test-key',json.dumps(r.health(self.db)))
    def test_account_paid_rejected(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',return_value=resp({'plan_id':'starter','plan_monthly_price':25,'plan_searches_left':1000})) as g:
            self.assertIsNone(r.research(self.db,P)['retail_reference_price']);self.assertEqual(g.call_count,1);self.assertIn(r.SHOP,r.health(self.db)['holds'])
    def test_quota_stop(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key','SCOUT_SHOPPING_DAILY':'1','SCOUT_SHOPPING_DETAILS':'1'}),patch.object(r.requests,'get',side_effect=[account(),resp(search(349.99,immersive_product_page_token='A'*50))]) as g:
            r.research(self.db,P);self.assertEqual(g.call_count,2);self.assertFalse(r.available(self.db));r.research(self.db,dict(P,name=TITLE.replace('AW2725D','AW2726D'),model='AW2726D'));self.assertEqual(g.call_count,2)
    def test_remote_quota_stop(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',return_value=account(0)) as g:
            r.research(self.db,P);self.assertEqual(g.call_count,1);self.assertIn('quota exhausted',r.health(self.db)['holds'][r.SHOP]['reason'])
    def test_rate_limit(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',side_effect=[account(),resp(status=429,headers={'Retry-After':'1800'})]) as g:
            r.research(self.db,P);self.assertGreaterEqual(r.health(self.db)['holds'][r.SHOP]['retry_at']-time.time(),1795);r.research(self.db,P);self.assertEqual(g.call_count,2)
    def test_forbidden_persistent(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',side_effect=[account(),resp(status=403)]) as g:
            r.research(self.db,P);self.assertIsNone(r.health(self.db)['holds'][r.SHOP]['retry_at']);r.research(self.db,P);self.assertEqual(g.call_count,2)
    def test_bestbuy_contract(self):
        upc='012345678905';p=dict(P,upc=upc);data={'products':[{'name':TITLE,'upc':upc,'url':'https://www.bestbuy.com/site/product/123.p','salePrice':349.99,'onlineAvailability':True}]}
        o=r.bestbuy_offers(data,p);self.assertEqual(len(o),1);self.assertEqual(o[0]['match'],'UPC match');self.assertTrue(r.summarize(p,o)['retail_reference_verified']);data['products'][0]['onlineAvailability']=False;self.assertEqual(r.bestbuy_offers(data,p),[])
    def test_bestbuy_memory_only(self):
        p=dict(P,upc='012345678905');data={'products':[{'name':TITLE,'upc':p['upc'],'url':'https://www.bestbuy.com/site/product/123.p','salePrice':349.99,'onlineAvailability':True}]}
        with patch.dict(os.environ,{'BESTBUY_API_KEY':'test-key'}),patch.object(r.requests,'get',return_value=resp(data)):
            self.assertEqual(r.research(self.db,p)['retail_reference_price'],349.99)
            with closing(r.connect(self.db)) as c:self.assertEqual(c.execute('SELECT count(*) FROM retail_queries').fetchone()[0],0)
    def test_suspended_amazon_does_not_block_monitor(self):
        with patch.object(s,'DB',self.db),patch.object(s,'fetch_json',return_value={'products':[P]}),patch.object(s.providers,'browser_page') as b,patch.object(s.ar,'research') as a,patch.object(s.ebay_sales,'lookup') as e,patch.object(s,'gemini') as g:
            s.init();ar.suspend(self.db,'Existing Amazon restriction');s.LIVE.mode='running';s.save('source',{'name':'Fixture','url':'https://example.com/feed','category':'feed'});s.monitor_once();b.assert_not_called();a.assert_not_called();e.assert_not_called();g.assert_not_called();self.assertEqual(len(s.rows('deal')),1);self.assertEqual(s.records('deal')[0]['assessment'],'Awaiting retail comparison');self.assertEqual(len(s.pending_discovery()),0);self.assertEqual(ar.blocked(self.db),'Existing Amazon restriction')
    def test_production_api_dashboard(self):
        with patch.object(s,'DB',self.db),patch.object(s,'TOKEN','fixture'),patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',side_effect=[account(),resp(search(349.99,immersive_product_page_token='A'*50)),resp(detail())]) as g:
            s.init();item=s.evaluate_deal(P);s.upsert_deal(item);client=TestClient(s.app);heads={'x-scout-token':'fixture'};data=client.get('/api/records/deal',headers=heads).json();self.assertEqual(data[0]['retail_reference_price'],349.99);self.assertEqual(data[0]['retail_savings'],-.01);self.assertEqual(data[0]['retail_reference_url'],DIRECT);self.assertEqual(g.call_count,3);self.assertNotIn('retail_offers',s.rows('deal')[0]);health=client.get('/api/retail-health',headers=heads).json();self.assertEqual(health['monthly_used'],2);self.assertEqual(client.get('/api/retail-health').status_code,401)
    def test_manual_endpoint(self):
        with patch.object(s,'DB',self.db),patch.object(s,'TOKEN','fixture'),patch.object(r.requests,'get') as g:
            s.init();s.upsert_deal(s.evaluate_deal(P));rid=s.rows('deal')[0]['id'];client=TestClient(s.app);h={'x-scout-token':'fixture'};res=client.post(f'/api/deals/{rid}/retail-manual',headers=h,json={'merchant':'Dell','url':DIRECT,'price':399.99,'confirmed':True});self.assertEqual(res.status_code,200,res.text);self.assertEqual(client.get('/api/records/deal',headers=h).json()[0]['retail_reference_price'],399.99);g.assert_not_called()
    def test_setup_status_no_key_disclosure(self):
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'secret-key'}):self.assertNotIn('secret-key',json.dumps(r.health(self.db)))

    def test_model_from_feed(self):
        p={'name':'27" Alienware AW2725D QD-OLED 280Hz QHD Gaming Monitor w/ Adjustable Stand'}
        self.assertIsNotNone(r.match(p,'Alienware 27 QD-OLED Gaming Monitor AW2725D'))
        self.assertIsNone(r.match(p,'Alienware AW2725D 27 inch 240Hz QD-OLED Monitor'))
    def test_detail_error_preserves_search(self):
        import requests
        with patch.dict(os.environ,{'SCOUT_SHOPPING_API_KEY':'test-key'}),patch.object(r.requests,'get',side_effect=[account(),resp(search(349.99,immersive_product_page_token='A'*50)),requests.Timeout()]):
            v=r.research(self.db,P);self.assertEqual(v['retail_reference_price'],349.99);self.assertFalse(v['retail_reference_verified'])
    def test_malformed_links(self):
        self.assertEqual(r.shopping_offers(search(link={'not':'url'}),P),[])
        self.assertEqual(r.store_offers(detail(link=123),P),[])
    def test_retail_card_chromium(self):
        from playwright.sync_api import sync_playwright
        from test_browser import chromium
        with patch.object(s,'DB',self.db),patch.object(s,'TOKEN','fixture-token'),patch.object(r.requests,'get') as g:
            s.init();s.upsert_deal(s.evaluate_deal(P));r.manual(self.db,P,{'merchant':'Dell','url':DIRECT,'price':399.99,'shipping':0,'confirmed':True})
            client=TestClient(s.app)
            with sync_playwright() as pw:
                b=chromium(pw)
                try:
                    page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                    def api(path,options):
                        res=client.request(options.get('method','GET'),path,headers=options.get('headers',{}),content=options.get('body') or None);return {'status':res.status_code,'text':res.text}
                    page.expose_function('fixtureFetch',api)
                    inject="<script>window.fetch=async(path,options)=>{let r=await fixtureFetch(path,options);return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>JSON.parse(r.text),text:async()=>r.text}};</script>"
                    page.set_content((Path(__file__).parent/'index.html').read_text(encoding='utf-8').replace('<script>',inject+'<script>',1));page.locator('#token').fill('fixture-token');page.get_by_role('button',name='Connect',exact=True).click();page.wait_for_function("document.querySelector('#status').textContent.includes('Connected')");page.get_by_role('button',name='DealWatch',exact=True).click();page.get_by_text('Current comparison item price',exact=True).first.wait_for();page.get_by_text('$399.99',exact=True).first.wait_for();page.get_by_text('$49.99',exact=True).first.wait_for();page.set_viewport_size({'width':390,'height':844});self.assertLessEqual(page.evaluate('document.documentElement.scrollWidth'),391);self.assertEqual(errors,[]);g.assert_not_called()
                finally:b.close()

if __name__=='__main__':unittest.main()
