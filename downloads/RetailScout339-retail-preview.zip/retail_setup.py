"""One-time local free-provider setup; credentials never printed or uploaded."""
import argparse,json,os,re,sqlite3,sys,time,getpass,webbrowser
from pathlib import Path
from contextlib import closing
import retail_compare as rc
from install_update import ensure_stopped

ROOT=Path(__file__).resolve().parent
DB=os.getenv('SCOUT_DB',str(ROOT/'scout.db'))

def save_settings(d):
    p=rc.SETTINGS;tmp=p.with_suffix('.tmp')
    try:
        with os.fdopen(os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600),'w',encoding='utf-8') as f:json.dump(d,f,indent=2)
        os.replace(tmp,p)
    finally:
        if tmp.exists():tmp.unlink()

def setup():
    ensure_stopped()
    try:d=json.loads(rc.SETTINGS.read_text(encoding='utf-8'))
    except (OSError,ValueError):d={}
    if not isinstance(d,dict):d={}
    print('Retail Scout free price comparison. No Amazon seller subscription is required.')
    print('Use a Free SerpApi account (250 monthly searches at time of release). Do not upgrade or enter payment details.')
    print('The bot reserves at most 200 calls per UTC month and 8 per UTC day by default; it checks your actual plan first.')
    print('Read provider terms and use the APIs only for authorized purposes.')
    if input('Open the free shopping API registration page? [y/N] ').strip().lower()=='y':webbrowser.open('https://serpapi.com/users/sign_up')
    key=getpass.getpass('Paste the FREE shopping API key (Enter to leave unchanged): ').strip()
    if key:
        if not re.fullmatch(r'[A-Za-z0-9_-]{16,256}',key):print('Key format not recognized; not saved.');return 2
        status=rc.free_account(key);print(status['reason'])
        if not status['ok']:print('Nothing saved. Confirm that the key belongs to a free account.');return 2
        d[rc.KEYS[rc.SHOP]]=key;save_settings(d)
        # An account check does not prove authorization for a previously forbidden search.
        # Preserve existing holds; never silently reset a provider restriction.
        print('Free plan validated; provider reports',status['remaining'],'searches remaining. Key saved locally.')
    print('Optional: Best Buy official catalog API, if approved for this use. No additional subscription required.')
    if input('Open Best Buy developer portal? [y/N] ').strip().lower()=='y':webbrowser.open('https://developer.bestbuy.com/')
    key=getpass.getpass('Paste authorized Best Buy API key (Enter to skip): ').strip()
    if key:
        if not re.fullmatch(r'[A-Za-z0-9_-]{8,256}',key):print('Key format not recognized; not saved.');return 2
        # Save but do not claim live validation; first catalog request verifies access.
        d[rc.KEYS[rc.BB]]=key;save_settings(d);print('Best Buy key saved; access will be checked on first request.')
    if Path(DB).is_file():
        with closing(sqlite3.connect(DB)) as c,c:
            if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='records'").fetchone():
                c.execute("UPDATE records SET data=json_set(data,'$.next_check',0) WHERE kind='deal' AND COALESCE(json_extract(data,'$.posted'),0)>?",(time.time()-72*3600,))
    print(json.dumps(rc.health(DB),indent=2));print('Setup complete. Run start.bat or the optional retail probe.')
    return 0

def probe():
    ensure_stopped()
    if not rc.available(DB):print('No free provider available. Use setup or the manual comparison buttons.');return 2
    # Use the real database so the existing budget and provider holds remain enforced.
    products=[{'name':'Alienware AW2725D 27 inch 280Hz QD-OLED gaming monitor','brand':'Alienware','model':'AW2725D','cost':350}, {'name':'DEWALT DW08302CG 120 ft green 3 spot laser level','brand':'DEWALT','model':'DW08302CG','cost':90}, {'name':'Cuisinart DCC-3200P1 14 cup programmable coffee maker stainless steel','brand':'Cuisinart','model':'DCC-3200P1','cost':56.95}]
    report={'created':time.time(),'mode':'actual provider requests subject to free plan and saved restrictions','results':[]}
    for p in products:
        r=rc.research(DB,p);report['results'].append({'product':p['name'],'deal_price_example':p['cost'],**r});print(p['name'],':',r['retail_status'],r['retail_reference_price'],r.get('retail_reference_merchant',''))
        time.sleep(.5)
    report['health']=rc.health(DB);report['prices_found']=sum(x['retail_reference_price'] is not None for x in report['results']);report['reported_online_offers']=sum(x.get('retail_reference_stock') in ('Online available (API)','Online in stock (shopping report)') for x in report['results']);out=ROOT/'retail-339-probe-results.json';out.write_text(json.dumps(report,indent=2),encoding='utf-8');print('REPORT:',out)
    return 0 if report['prices_found'] else 2

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--probe',action='store_true');p.add_argument('--status',action='store_true');args=p.parse_args()
    if args.status:print(json.dumps(rc.health(DB),indent=2));sys.exit(0)
    try:sys.exit(probe() if args.probe else setup())
    except RuntimeError as e:print(str(e));sys.exit(2)
    except (KeyboardInterrupt,EOFError):print('\nCancelled. No secrets printed.');sys.exit(2)
