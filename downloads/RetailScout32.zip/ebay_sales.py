"""Opt-in authorized browser research; no challenge bypass."""
import os,re,time,sqlite3,json,threading,statistics
from urllib.parse import urlencode
from datetime import datetime,timezone
LOCK=threading.Lock(); last=0

def parse_cards(cards,upc):
    out=[]; seen=set()
    for c in cards:
        title=c.get('title',''); link=c.get('link',''); price=c.get('price',''); date=c.get('date',''); condition=c.get('condition','')
        # Only explicit exact UPC evidence; search query alone is not proof.
        if not re.search(r'(?<!\d)'+re.escape(upc)+r'(?!\d)',title+' '+c.get('details','')): continue
        if not re.fullmatch(r'New(?: with tags| in box)?',condition.strip(),re.I): continue
        if re.search(r'\b(?:lot|bundle|parts|broken|empty box|best offer)\b',title+' '+c.get('details',''),re.I): continue
        m=re.search(r'/itm/(?:[^/?]+/)?(\d+)',link); p=re.fullmatch(r'\$([\d,]+\.\d{2})',price.strip()); d=re.search(r'\bSold\s+([A-Za-z]{3} \d{1,2}, \d{4})',date,re.I)
        if not (m and p and d) or m[1] in seen: continue
        try: stamp=datetime.strptime(d[1],'%b %d, %Y').replace(tzinfo=timezone.utc).timestamp()
        except ValueError: continue
        age=(time.time()-stamp)/86400
        if not 0<=age<=90: continue
        value=float(p[1].replace(',',''))
        if value<=0: continue
        seen.add(m[1]);out.append(dict(id=m[1],price=value,date=stamp,url='https://www.ebay.com/itm/'+m[1]))
    return out

def summarize(sales):
    recent=[s['price'] for s in sales if time.time()-s['date']<=30*86400]
    return dict(resale=round(statistics.median(recent),2) if len(recent)>=3 else None,median=statistics.median(recent) if recent else None,sample=len(recent),source='eBay sold (browser)',observed_7d=sum(time.time()-s['date']<=7*86400 for s in sales),observed_30d=len(recent),observed_90d=len(sales),sales=sales,coverage='One search page; observed counts only; shipping excluded')

def browse(upc):
    from playwright.sync_api import sync_playwright
    url='https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':upc,'LH_Sold':1,'LH_Complete':1,'LH_ItemCondition':1000})
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        try:
            page=browser.new_page(); response=page.goto(url,wait_until='domcontentloaded',timeout=30000)
            if not response or response.status in (401,403,429) or re.search(r'captcha|security measure|verify you are human|access denied|pardon our interruption',page.title()+' '+page.locator('body').inner_text()[:3000],re.I): raise PermissionError('eBay access restricted; browser research suspended')
            if response.status>=400: raise RuntimeError('eBay HTTP '+str(response.status))
            if not page.url.startswith('https://www.ebay.com/sch/'): raise PermissionError('Unexpected eBay redirect; research suspended')
            return page.locator('li.s-item, li.s-card').evaluate_all('''els=>els.map(e=>{const t=s=>e.querySelector(s)?.innerText||'';return {title:t('.s-item__title,.s-card__title'),price:t('.s-item__price,.s-card__price'),date:t('.s-item__title--tag,.s-item__caption,.s-card__caption'),condition:t('.SECONDARY_INFO,.s-card__subtitle'),details:e.innerText,link:e.querySelector('a[href*="/itm/"]')?.href||''}})''')
        finally: browser.close()

def lookup(product,db):
    global last
    if os.getenv('SCOUT_EBAY_BROWSER')!='1': return None
    upc=str(product.get('upc') or '')
    if not re.fullmatch(r'\d{8}|\d{12,14}',upc): return None
    with LOCK,sqlite3.connect(db,timeout=30) as c:
        c.execute('CREATE TABLE IF NOT EXISTS ebay_cache (upc TEXT PRIMARY KEY, stamp REAL, data TEXT)');c.execute('CREATE TABLE IF NOT EXISTS ebay_control (id INTEGER PRIMARY KEY, reason TEXT)')
        if c.execute('SELECT reason FROM ebay_control WHERE id=1').fetchone(): return None
        row=c.execute('SELECT stamp,data FROM ebay_cache WHERE upc=?',(upc,)).fetchone()
        if row and time.time()-row[0]<86400: return json.loads(row[1])
        if time.monotonic()-last<60: return None
        last=time.monotonic()
        try: result=summarize(parse_cards(browse(upc),upc))
        except PermissionError as e:
            c.execute('INSERT OR REPLACE INTO ebay_control VALUES(1,?)',(str(e),));return None
        except Exception as e:
            result={'resale':None,'source':'eBay browser error','error':str(e)[:200]}
        c.execute('INSERT OR REPLACE INTO ebay_cache VALUES(?,?,?)',(upc,time.time(),json.dumps(result)));return result
