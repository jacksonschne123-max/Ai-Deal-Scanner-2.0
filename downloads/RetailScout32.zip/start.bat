@echo off
cd /d "%~dp0"
if not exist .venv py -3 -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
if exist config.bat call config.bat
if "%SCOUT_EBAY_BROWSER%"=="1" (
 python -m playwright install chromium
 if errorlevel 1 exit /b 1
)
if not defined SCOUT_TOKEN set /p SCOUT_TOKEN=Choose a long private access token: 
if not defined GEMINI_API_KEY set /p GEMINI_API_KEY=Gemini API key: 
python -m uvicorn server:app --host 127.0.0.1 --port 8765
pause
