import os, json, sqlite3, time, threading, secrets, statistics, re, base64
from pathlib import Path
from contextlib import asynccontextmanager, contextmanager
import requests
import dealwatch, ebay_sales
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel
ROOT=Path(__file__).parent
DB=os.getenv('SCOUT_DB',str(ROOT/'scout.db'))
TOKEN=os.getenv('SCOUT_TOKEN','')
LOCK=threading.Lock()
@contextmanager
def conn():
    c=sqlite3.connect(DB,timeout=30); c.row_factory=sqlite3.Row
    try:
        with c: yield c
    finally: c.close()

def init():
    with conn() as c:
        c.executescript('''CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY, kind TEXT, data TEXT, created REAL); CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY, image TEXT, status TEXT, error TEXT, created REAL);''')
        c.execute("UPDATE jobs SET status='queued' WHERE status='running'")
def save(kind,data):
    with conn() as c: return c.execute('INSERT INTO records(kind,data,created) VALUES(?,?,?)',(kind,json.dumps(data),time.time())).lastrowid
def rows(kind):
    with conn() as c: return [dict(json.loads(r['data']),id=r['id'],created=r['created']) for r in c.execute('SELECT * FROM records WHERE kind=? ORDER BY id DESC',(kind,))]
def number(x):
    try:
        v=float(x); return v if 0<=v<1e8 else None
    except (TypeError,ValueError): return None

def economics(cost,price,fee=.15,shipping=6,cashback=0,tax=0,coupon=0):
    cost,price=number(cost),number(price)
    if cost is None or price is None: return {'profit':None,'roi':None,'color':'red'}
    paid=max(0,cost-min(cost,coupon))*(1+tax); net=price*(1-fee)-shipping-paid+paid*cashback
    return {'profit':round(net,2),'roi':round(100*net/paid,2) if paid else None,'color':'green' if net>0 else 'yellow'}
def fetch_json(url,**kw):
    for i in range(3):
        try:
            r=requests.get(url,timeout=20,**kw); r.raise_for_status(); return r.json()
        except requests.RequestException:
            if i==2: raise
            time.sleep(2**i)
def pricing(p):
    # Configured authorized provider must return exact-match, completed sales in USD.
    url=os.getenv('SCOUT_SOLD_URL'); fallback=os.getenv('SCOUT_AMAZON_URL'); params={'upc':p.get('upc',''),'query':p.get('name','')}
    headers={'Authorization':'Bearer '+os.getenv('SCOUT_PROVIDER_KEY','')}
    if url:
        try:
            data=fetch_json(url,params=params,headers=headers); vals=[number(x.get('price')) for x in data.get('sales',[]) if x.get('exact_match') is True and x.get('sold') is True and x.get('currency')=='USD']; vals=[x for x in vals if x is not None and x>0]
            if vals: return {'resale':round(statistics.mean(vals),2),'median':statistics.median(vals),'sample':len(vals),'source':'eBay sold (provider)'}
        except Exception: pass
    browser=ebay_sales.lookup(p,DB)
    if browser and browser.get("resale") is not None: return browser
    if fallback:
        try:
            d=fetch_json(fallback,params=params,headers=headers); v=number(d.get('price'))
            if d.get('exact_match') is True and d.get('currency')=='USD' and v: return {'resale':v,'source':'Amazon asking price'}
        except Exception: pass
    return browser or {'resale':None,'source':'Unavailable'}
def identify(image):
    key=os.getenv('GEMINI_API_KEY'); model=os.getenv('GEMINI_MODEL','gemini-2.5-flash')
    if not key: raise RuntimeError('Set GEMINI_API_KEY on PC')
    mime,encoded=image.split(',',1); mime=mime.split(':')[1].split(';')[0]
    prompt='Identify every distinct retail product visible. Return JSON array only. Fields name (short exact brand model variant size), upc (visible digits only or null), cost (visible associated USD price only or null), box (normalized [ymin,xmin,ymax,xmax] 0-1000), evidence (short), confidence (0-1). Never guess prices or barcodes. Do not merge different variants.'
    body={'contents':[{'parts':[{'text':prompt},{'inline_data':{'mime_type':mime,'data':encoded}}]}],'generationConfig':{'responseMimeType':'application/json'}}
    for i in range(3):
        r=requests.post(f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',headers={'x-goog-api-key':key},json=body,timeout=60)
        if r.status_code not in (429,500,502,503,504): break
        time.sleep(2**i)
    r.raise_for_status(); out=json.loads(r.json()['candidates'][0]['content']['parts'][0]['text']); return out if isinstance(out,list) else []
def process(p):
    p=dict(p); p['name']=str(p.get('name') or 'Unknown product')[:200]; p['cost']=number(p.get('cost')); upc=str(p.get('upc') or '')
    if upc:
        matches=[x for x in rows('correction') if x.get('upc')==upc]
        if matches: p['name']=matches[0]['name']; p['evidence']='User-confirmed UPC identity'
    p.update(pricing(p)); p.update(economics(p['cost'],p['resale'],cashback=float(os.getenv('SCOUT_CASHBACK','0')),tax=float(os.getenv('SCOUT_TAX','0.0925')))); return p

def worker(stop):
    while not stop.is_set():
        with conn() as c:
            job=c.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY id LIMIT 1").fetchone()
            if job: c.execute("UPDATE jobs SET status='running' WHERE id=?",(job['id'],))
        if not job: stop.wait(1); continue
        try:
            for p in identify(job['image']): save('scan',dict(process(p),job_id=job['id']))
            with conn() as c: c.execute("UPDATE jobs SET status='done',image='' WHERE id=?",(job['id'],))
        except Exception as e:
            with conn() as c: c.execute("UPDATE jobs SET status='failed',error=? WHERE id=?",(str(e)[:300],job['id']))
def monitor_once():
    sources=[('Slickdeals RSS',lambda u=u:dealwatch.rss(u)) for u in dealwatch.FEEDS] if os.getenv('SCOUT_RSS','1')=='1' else []
    if os.getenv('BESTBUY_API_KEY'): sources.append(('Best Buy',lambda:dealwatch.bestbuy(os.environ['BESTBUY_API_KEY'])))
    for s in rows('source'):
        sources.append((s.get('name'),lambda s=s:[dict(p,store=s.get('name'),price_verified=False) for p in fetch_json(s['url']).get('products',[]) if isinstance(p,dict)]))
    for name,load in sources:
        try:
            count=0
            for p in load():
                item=process(p); item.update({k:p.get(k) for k in ('store','url','stock','price_verified','posted','deal_id')}); item['assessment']=dealwatch.classify(item); key=dealwatch.fingerprint(p); item['fingerprint']=key
                with conn() as c:
                    old=c.execute("SELECT id FROM records WHERE kind='deal' AND json_extract(data,'$.fingerprint')=?",(key,)).fetchone()
                    if old: c.execute('UPDATE records SET data=?,created=? WHERE id=?',(json.dumps(item),time.time(),old['id']))
                    else: c.execute("INSERT INTO records(kind,data,created) VALUES('deal',?,?)",(json.dumps(item),time.time()))
                count+=1
            save('event',{'source':name,'processed':count})
        except Exception as e: save('event',{'source':name,'error':str(e)[:200]})
def monitor(stop):
    while not stop.is_set():
        monitor_once(); stop.wait(max(60,int(os.getenv('SCOUT_INTERVAL','900'))))
@asynccontextmanager
async def lifespan(app):
    init(); stop=threading.Event(); threads=[threading.Thread(target=f,args=(stop,),daemon=True) for f in (worker,monitor)]; [t.start() for t in threads]; yield; stop.set()
app=FastAPI(lifespan=lifespan)
@app.middleware('http')
async def auth(req:Request,call_next):
    if req.url.path.startswith('/api/') and (not TOKEN or not secrets.compare_digest(req.headers.get('x-scout-token',''),TOKEN)): return JSONResponse({'detail':'Invalid or missing access token'},401)
    return await call_next(req)
@app.get('/')
def home(): return FileResponse(ROOT/'index.html')
@app.get('/api/status')
def status(): return {'gemini':bool(os.getenv('GEMINI_API_KEY')),'sold_provider':bool(os.getenv('SCOUT_SOLD_URL')),'amazon_provider':bool(os.getenv('SCOUT_AMAZON_URL')),'ebay_browser':os.getenv('SCOUT_EBAY_BROWSER')=='1'}
class Upload(BaseModel): image:str
@app.post('/api/scan')
def scan(x:Upload):
    if len(x.image)>15_000_000 or not re.match(r'^data:image/(jpeg|png|webp);base64,',x.image): raise HTTPException(400,'Invalid or oversized image')
    try: base64.b64decode(x.image.split(',',1)[1],validate=True)
    except Exception: raise HTTPException(400,'Invalid image encoding')
    with conn() as c: id=c.execute("INSERT INTO jobs(image,status,created) VALUES(?,'queued',?)",(x.image,time.time())).lastrowid
    return {'id':id}
@app.get('/api/jobs')
def jobs():
    with conn() as c: return [dict(r) for r in c.execute('SELECT id,status,error,created FROM jobs ORDER BY id DESC LIMIT 100')]
@app.post('/api/retry/{id}')
def retry(id:int):
    with conn() as c: c.execute("UPDATE jobs SET status='queued',error=NULL WHERE id=? AND status='failed'",(id,))
    return {'ok':True}
KINDS={'scan','deal','watch','inventory','sale','source','correction','event','wholesale','discount'}
@app.get('/api/records/{kind}')
def records(kind:str):
    if kind not in KINDS: raise HTTPException(404)
    return rows(kind)
@app.post('/api/records/{kind}')
def add(kind:str,data:dict):
    if kind not in KINDS-{'event','scan','deal'}: raise HTTPException(404)
    if kind=='source' and not str(data.get('url','')).startswith('https://'): raise HTTPException(400,'HTTPS feed required')
    return {'id':save(kind,data)}
@app.post('/api/evaluate')
def evaluate(data:dict): return process(data)
