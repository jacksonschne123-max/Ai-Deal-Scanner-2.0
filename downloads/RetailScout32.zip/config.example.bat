@echo off
set "SCOUT_TOKEN=replace-with-long-random-secret"
set "GEMINI_API_KEY=replace-with-your-key"
set "GEMINI_MODEL=gemini-2.5-flash"
set "SCOUT_CASHBACK=0.02"
rem set "SCOUT_SOLD_URL=https://your-authorized-provider.example/sold"
rem set "SCOUT_AMAZON_URL=https://your-authorized-provider.example/amazon"

set "SCOUT_RSS=1"
set "BESTBUY_API_KEY="
set "SCOUT_TAX=0.0925"

rem Enable only with authorization covering automated searches:
set "SCOUT_EBAY_BROWSER=0"
