import os,re,hashlib,xml.etree.ElementTree as ET
from urllib.parse import urlparse
from email.utils import parsedate_to_datetime
import time,requests
FEEDS=['https://slickdeals.net/rss.php','https://slickdeals.net/newsearch.php?mode=popdeals&searcharea=deals&searchin=first&rss=1']
def parse_rss(data):
    for x in ET.fromstring(data).findall('.//item'):
        title=x.findtext('title') or ''; url=x.findtext('link') or ''; date=x.findtext('pubDate')
        prices=re.findall(r'\$\s*(\d[\d,]*(?:\.\d{2})?)(?![\d.])',title)
        if len(prices)!=1 or re.search(r'\b(?:from|starting|cashback|gift card|subscription|after rebate|statement credit|up to|each|select| ymmv)\b|\d+\s*%',title,re.I): continue
        if urlparse(url).scheme!='https': continue
        try: posted=parsedate_to_datetime(date).timestamp()
        except (ValueError,TypeError,AttributeError): continue
        if not 0<=time.time()-posted<=172800: continue
        cost=float(prices[0].replace(',','')); name=re.sub(r'\s*\$\s*[\d,.]+.*$','',title).strip(' -:')
        if cost<=0 or not name: continue
        yield dict(name=name,cost=cost,url=url,store='Slickdeals community lead',stock='Unverified',posted=posted,deal_id=x.findtext('guid') or url,price_verified=False)
def rss(url):
    r=requests.get(url,timeout=20,headers={'User-Agent':'RetailScout/3.1 RSS reader'});r.raise_for_status();return list(parse_rss(r.content))
def bestbuy(key):
    r=requests.get('https://api.bestbuy.com/v1/products(onSale=true&onlineAvailability=true)',params={'apiKey':key,'format':'json','show':'sku,name,upc,salePrice,url,onlineAvailability','pageSize':50},timeout=20);r.raise_for_status()
    for x in r.json().get('products',[]):
        if x.get('onlineAvailability') is True and x.get('salePrice') is not None:
            yield dict(name=x['name'],upc=x.get('upc'),cost=x['salePrice'],url=x['url'],store='Best Buy',stock='Online available',deal_id=str(x['sku']),price_verified=True)
def classify(item):
    if item.get('profit') is None: return 'Needs resale evidence'
    if item.get('profit')<=0: return 'Not profitable at estimated costs'
    if not item.get('price_verified'): return 'Potential lead — verify retail offer'
    if item.get('source') not in ('eBay sold (provider)','eBay sold (browser)') or item.get('sample',0)<3: return 'Potential lead — insufficient sold evidence'
    return 'Positive estimate — verify eligibility, stock and condition'
def fingerprint(p):
    return hashlib.sha256((str(p.get('store'))+'|'+str(p.get('deal_id') or p.get('url') or p.get('name'))).encode()).hexdigest()
