import os,tempfile,unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
import server as s
class Tests(unittest.TestCase):
 def test_profit(self):
  self.assertEqual(s.economics(10,30)['profit'],9.5)
  self.assertEqual(s.economics(10,5)['color'],'yellow')
  self.assertEqual(s.economics(None,30)['color'],'red')
 def test_priority(self):
  with patch.dict(os.environ,{'SCOUT_SOLD_URL':'https://sold','SCOUT_AMAZON_URL':'https://amazon'}),patch.object(s,'fetch_json',return_value={'sales':[{'price':20,'sold':True,'exact_match':True,'currency':'USD'},{'price':100,'sold':False,'exact_match':True,'currency':'USD'}]}) as f:
   self.assertEqual(s.pricing({})['resale'],20);self.assertEqual(f.call_count,1)
 def test_fallback(self):
  with patch.dict(os.environ,{'SCOUT_SOLD_URL':'https://sold','SCOUT_AMAZON_URL':'https://amazon'}),patch.object(s,'fetch_json',side_effect=[{'sales':[]},{'price':12,'exact_match':True,'currency':'USD'}]): self.assertEqual(s.pricing({})['source'],'Amazon asking price')
 def test_api(self):
  with tempfile.TemporaryDirectory() as d,patch.object(s,'DB',d+'/test.db'),patch.object(s,'TOKEN','secret'):
   s.init(); c=TestClient(s.app); h={'x-scout-token':'secret'}
   self.assertEqual(c.get('/api/status').status_code,401)
   self.assertEqual(c.get('/api/status',headers=h).status_code,200)
   self.assertEqual(c.post('/api/scan',headers=h,json={'image':'bad'}).status_code,400)
   self.assertEqual(c.post('/api/scan',headers=h,json={'image':'data:image/jpeg;base64,YQ=='}).status_code,200)
   self.assertEqual(c.get('/api/jobs',headers=h).json()[0]['status'],'queued')
   c.post('/api/records/correction',headers=h,json={'upc':'123','name':'Verified'})
   with patch.object(s,'pricing',return_value={'resale':None,'source':'Unavailable'}): self.assertEqual(s.process({'upc':'123','name':'Wrong'})['name'],'Verified')
if __name__=='__main__':unittest.main()
