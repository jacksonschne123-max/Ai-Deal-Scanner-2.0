import unittest,time,tempfile,os
from unittest.mock import patch
from email.utils import formatdate
import dealwatch,server
class DealWatch(unittest.TestCase):
 def test_feed(self):
  xml=f'<rss><channel><item><title>Example model ABC123 $25.00</title><link>https://example.com/deal</link><pubDate>{formatdate(time.time(),usegmt=True)}</pubDate></item><item><title>Other from $5</title></item></channel></rss>'
  p=list(dealwatch.parse_rss(xml));self.assertEqual(len(p),1);self.assertEqual(p[0]['cost'],25);self.assertFalse(p[0]['price_verified'])
 def test_classification(self):
  self.assertIn('insufficient',dealwatch.classify(dict(profit=10,price_verified=True,source='Amazon asking price')))
  self.assertIn('verify retail',dealwatch.classify(dict(profit=10,price_verified=False)))
 def test_pipeline(self):
  with tempfile.TemporaryDirectory() as t,patch.object(server,'DB',os.path.join(t,'test.db')),patch.object(dealwatch,'FEEDS',['fixture']),patch.object(dealwatch,'rss',return_value=[dict(name='Synthetic ABC123',cost=25,store='Fixture',url='https://example.com',price_verified=True)]),patch.object(server,'pricing',return_value=dict(resale=60,source='eBay sold (provider)',sample=5)),patch.dict(os.environ,{'SCOUT_RSS':'1','BESTBUY_API_KEY':''}):
   server.init();server.monitor_once();server.monitor_once();r=server.rows('deal');self.assertEqual(len(r),1);self.assertGreater(r[0]['profit'],0);self.assertIn('Positive estimate',r[0]['assessment'])
if __name__=='__main__':unittest.main()
