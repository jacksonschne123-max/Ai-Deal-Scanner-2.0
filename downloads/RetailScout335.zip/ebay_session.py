"""Local-only sign-in and explicit authorized access test. Never exports cookies."""
import os, sys, sqlite3, time
from pathlib import Path
from contextlib import closing
from urllib.parse import urlencode

def profile():
    return Path(os.getenv('LOCALAPPDATA',str(Path.home()/'.local/share')))/'RetailScout'/'ebay-profile'

def configured(): return (profile()/'Default').is_dir()

def main():
    from playwright.sync_api import sync_playwright
    from install_update import ensure_stopped
    ensure_stopped()
    db=Path(os.getenv('SCOUT_DB',str(Path(__file__).parent/'scout.db')))
    print('Stop Retail Scout first. Use only if authorized for automated eBay research.')
    with sync_playwright() as p:
        ctx=p.chromium.launch_persistent_context(str(profile()),headless=False,accept_downloads=False)
        try:
            page=ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto('https://www.ebay.com/',wait_until='domcontentloaded',timeout=45000)
            input('Sign in manually in Chrome if needed. Press Enter here to test completed listings, or Ctrl+C to cancel: ')
            q='Garmin Striker 4';u='https://www.ebay.com/sch/i.html?'+urlencode({'_nkw':q,'LH_Sold':1,'LH_Complete':1})
            r=page.goto(u,wait_until='domcontentloaded',timeout=30000)
            body=page.locator('body').inner_text(timeout=10000)
            import re
            if not r or r.status!=200 or not page.url.startswith('https://www.ebay.com/sch/') or re.search(r'captcha|verify you are human|access denied|pardon our interruption|security measure',page.title()+' '+body[:3000],re.I):
                print('Access not confirmed; suspension unchanged. Contact eBay for authorized access.');return 1
            if not page.locator('li.s-item,li.s-card').count():print('No listing cards found; suspension unchanged.');return 1
            if input('Listings visible? Confirm authorized automated access and reset suspension? Type YES: ')!='YES':return 1
            with closing(sqlite3.connect(db)) as c,c:
                c.execute('CREATE TABLE IF NOT EXISTS ebay_control(id INTEGER PRIMARY KEY,reason TEXT)');c.execute('DELETE FROM ebay_control WHERE id=1')
            print('Session saved; access test passed. Restart Retail Scout. This is not proof of sold-price extraction.')
            return 0
        finally:ctx.close()
if __name__=='__main__':sys.exit(main())
